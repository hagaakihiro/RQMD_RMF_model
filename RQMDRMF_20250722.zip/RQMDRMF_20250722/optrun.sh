#!/bin/sh


rm recorder.csv
echo "i,L,Rpn,Rpp,Rnn,ca,cb,mT,dt,benv,E,VE,Zp,Ap,Zt,At,mdl,date" > recorder.csv

N=1
while read nuclpara;do
    unlink QMD_nuclpara.csv
    ln -s Models/${nuclpara}.csv QMD_nuclpara.csv

    rm model_name.csv
    echo ${nuclpara} > model_name.csv

    while read proj;do
        rm QMD_input.csv
        echo "$proj" > QMD_input.csv

        for i in `seq 1 $N`; do
            rm i.csv
            echo $i > i.csv

            python setting_parameters_use-opt-prm_dt_opt.py

            while read para;do
                rm QMD_parameter.csv
                echo "$para" > QMD_parameter.csv

                start_time=`date +%s`
                ./pencil_ion
                end_time=`date +%s`
                time=`expr $end_time - $start_time`
                echo $time
                rm time.csv
                echo $time > time.csv
                
                rm date.csv
                now=`date +%Y%m%d%H%M%S%3N` #for linux
                #now=`gdate +%Y%m%d%H%M%S%3N` #for mac
                echo $now > date.csv

                rm filename.txt
                python filename_change_y.py > filename.txt

                read filename < filename.txt
                mv crosssection.csv $filename
                mv CS_* /mnt/qnap02/Carbon/NS2/
                cp recorder.csv /mnt/qnap02/Carbon/NS2/recorder_R_optimize_107_colltime_50_Ti.csv
            done < ./parameters.txt
        done
    done < ./projectile.txt
done < ./models.txt
#done
