#!/usr/bin/python3
# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import os
import sys
import datetime



model_name_data = pd.read_csv("model_name.csv",    header=None, encoding="SHIFT-JIS")
para_data       = pd.read_csv("QMD_parameter.csv", header=None, encoding="SHIFT-JIS")
input_data      = pd.read_csv("QMD_input.csv",     header=None, encoding="SHIFT-JIS")
i_data          = pd.read_csv("i.csv",             header=None, encoding="SHIFT-JIS")
time_data       = pd.read_csv("time.csv",          header=None, encoding="SHIFT-JIS")
date_data       = pd.read_csv("date.csv",          header=None, encoding="SHIFT-JIS")
#bmax0_data      = pd.read_csv("bmax_0.csv",        header=None, encoding="SHIFT-JIS")




L    = para_data.iloc[0,0]
Rpn  = para_data.iloc[0,1]
Rpp  = para_data.iloc[0,2]
Rnn  = para_data.iloc[0,3]
ca   = para_data.iloc[0,4]
cb   = para_data.iloc[0,5]
mT   = para_data.iloc[0,6]
dt   = para_data.iloc[0,7]
benv = para_data.iloc[0,8]
E    = input_data.iloc[0,0]
VE   = input_data.iloc[0,1]
Zp   = input_data.iloc[0,2]
Ap   = input_data.iloc[0,3]
Zt   = input_data.iloc[0,4]
At   = input_data.iloc[0,5]
mdl  = model_name_data.iloc[0, 0]
i    = i_data.iloc[0,0]
time = time_data.iloc[0,0]
date = date_data.iloc[0,0]
#bm0  = bmax0_data.iloc[0,0]


with open('recorder.csv', 'a') as f:
    #rec = (i,L,Rpn,Rpp,Rnn,ca,cb,mT,dt,benv,E,VE,Zp,Ap,Zt,At,bm0,mdl,time,date)
    rec = (i,L,Rpn,Rpp,Rnn,ca,cb,mT,dt,benv,E,VE,Zp,Ap,Zt,At,mdl,date)
    print('%d,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%d,%d,%d,%d,%s,%s' % rec, file=f)

filename  = 'CS_%s.csv' % date
print(filename)
sys.exit()
