
#include "DetectorConstruction.hh"
//#include "NestedPhantomParameterisation.hh"
#include "PSEnergyDeposit.hh"

#include "G4Material.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Cons.hh"
#include "G4Tubs.hh"
#include "G4UnionSolid.hh"
#include "G4SubtractionSolid.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4PVReplica.hh"
#include "G4UniformMagField.hh"
#include "G4GeometryManager.hh"
#include "G4PhysicalVolumeStore.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4SolidStore.hh"
#include "G4PVParameterised.hh"
#include "G4SDManager.hh"
#include "G4MultiFunctionalDetector.hh"
#include "G4Region.hh"
#include "G4ProductionCuts.hh"

#include "G4VisAttributes.hh"
#include "G4Colour.hh"

using namespace CLHEP;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

DetectorConstruction::DetectorConstruction()
				:defaultMaterial           (0),
				solidWorld                 (0),logicWorld            (0),physiWorld            (0),
                /*
				solidTarget                (0),logicTarget           (0),physiTarget           (0),
				solidTargetFilm            (0),logicTargetFilm       (0),physiTargetFilm       (0),
				solidTargetMount1          (0),logicTargetMount1     (0),physiTargetMount1     (0),
				solidTargetMount2          (0),logicTargetMount2     (0),physiTargetMount2     (0),
				solidTargetBase            (0),logicTargetBase       (0),physiTargetBase       (0),
				solidConeFilter            (0),logicConeFilter       (0),physiConeFilter       (0),
				solidFilter1               (0),logicFilter1          (0),physiFilter1          (0),
				solidFilter2               (0),logicFilter2          (0),physiFilter2          (0),
				solidFilter3               (0),logicFilter3          (0),physiFilter3          (0),
				solidLCone1                (0),
				solidLCone2                (0),
				solidLCone3                (0),
				solidLCone4                (0),
				solidLConeWindow           (0),
				solidLConeBase             (0),
				solidLCone                 (0),logicLCone            (0),physiLCone            (0),
				solidClampRingWindow       (0),
				solidClampRingBase         (0),
				solidClampRing             (0),logicClampRing        (0),physiClampRing        (0),
				solidPrimColWindow         (0),
				solidPrimColBase           (0),
				solidPrimCol               (0),logicPrimCol          (0),physiPrimCol          (0),
				solidCollimeter            (0),logicCollimeter       (0),physiCollimeter       (0),
				solidShieldingLeadWindow   (0),
				solidShieldingLeadBase     (0),
				solidShieldingLead         (0),logicShieldingLead    (0),physiShieldingLead    (0),
				solidShieldingBracketWindow(0),
				solidShieldingBracketBase  (0),
				solidShieldingBracket      (0),logicShieldingBracket (0),physiShieldingBracket (0),
				solidLeadCollimeterWindow  (0),
				solidLeadCollimeterBase    (0),
				solidLeadCollimeter        (0),logicLeadCollimeter   (0),physiLeadCollimeter   (0),
				solidCassettleWindow1      (0),logicCassettleWindow1 (0),physiCassettleWindow1 (0),
				solidCassettleWindow2      (0),logicCassettleWindow2 (0),physiCassettleWindow2 (0),
				solidCassettleWindow3      (0),logicCassettleWindow3 (0),physiCassettleWindow3 (0),
				solidCassettleWindow4      (0),logicCassettleWindow4 (0),physiCassettleWindow4 (0),
				solidBowtieFilter          (0),logicBowtieFilter     (0),physiBowtieFilter     (0),
                */
				solidVirtualDetector       (0),logicVirtualDetector  (0),physiVirtualDetector  (0),
				solidWaterPhantom          (0),logicWaterPhantom     (0),physiWaterPhantom     (0),
				//solidsubWaterPhantom       (0),logicsubWaterPhantom  (0),physisubWaterPhantom  (0),


				magField(0)
{

    // materials
    DefineMaterials();
    /*
    SetTargetFilmMaterial      ("Target");
    SetTargetMountMaterial     ("TZM");
    SetTargetBaseMaterial      ("Graphite");
    SetLeadConeMaterial        ("LeadAntimony");
    SetFilter1Material         ("Cupper");
    SetFilter2Material         ("Aluminium");
    SetFilter3Material         ("Aluminium");
    SetClampRingMaterial       ("Aluminium");
    SetPrimColMaterial         ("pureLead");
    SetShieldingLeadMaterial   ("pureLead");
    SetShieldingBracketMaterial("Aluminium");
    SetLeadCollimeterMaterial  ("pureLead");
    SetCassettleWindowMaterial ("G4_POLYETHYLENE");
    SetBowtieFilterMaterial    ("ENAW2017A");
    */
    SetDetectorMaterial        ("Air");
    SetPhantomMaterial         ("G4_WATER");
}

DetectorConstruction::~DetectorConstruction()
{ 
}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
    return ConstructCalorimeter();
}

void DetectorConstruction::DefineMaterials()
{ 
    //This function illustrates the possible ways to define materials
    G4String symbol;             //a=mass of a mole;
    G4double a, z, density;      //z=mean number of protons;
    G4int ncomponents, natoms; G4double fractionmass;
    // define Elements---------------------------------------------------------------
    //G4Element* H  = new G4Element("Hydrogen"  ,symbol="H" , z=  1., a=  1.01 *g/mole);
    //G4Element* C  = new G4Element("Carbon"    ,symbol="C" , z=  6., a= 12.01 *g/mole);
    G4Element* N  = new G4Element("Nitrogen"  ,symbol="N" , z=  7., a= 14.01 *g/mole);
    G4Element* O  = new G4Element("Oxygen"    ,symbol="O" , z=  8., a= 16.00 *g/mole);
    /*
    G4Element* Mg = new G4Element("Magnesium" ,symbol="Mg", z= 12., a= 24.305*g/mole);
    G4Element* Al = new G4Element("Aluminium" ,symbol="Al", z= 13., a= 26.982*g/mole);
    G4Element* Si = new G4Element("Silicon"   ,symbol="Si", z= 14., a= 28.086*g/mole);
    G4Element* Ti = new G4Element("Titanium"  ,symbol="Ti", z= 22., a= 47.867*g/mole);
    G4Element* Cr = new G4Element("Chromium"  ,symbol="Cr", z= 24., a= 51.996*g/mole);
    G4Element* Mn = new G4Element("Manganese" ,symbol="Mn", z= 25., a= 54.938*g/mole);
    G4Element* Fe = new G4Element("Iron"      ,symbol="Fe", z= 26., a= 55.845*g/mole);
    G4Element* Cu = new G4Element("Cupper"    ,symbol="Cu", z= 29., a= 63.546*g/mole);
    G4Element* Zn = new G4Element("Zinc"      ,symbol="Zn", z= 30., a= 65.38 *g/mole);
    G4Element* Zr = new G4Element("Zirconium" ,symbol="Zr", z= 40., a= 91.224*g/mole);
    G4Element* Mo = new G4Element("Morybdenum",symbol="Mo", z= 42., a= 95.96 *g/mole);
    G4Element* W  = new G4Element("Tangsten"  ,symbol="W" , z= 74., a=183.84 *g/mole);
    G4Element* Sb = new G4Element("Antimony"  ,symbol="Sb", z= 51., a=121.760*g/mole);
    G4Element* Re = new G4Element("Rhenium"   ,symbol="Re", z= 75., a=186.207*g/mole);
    G4Element* Pb = new G4Element("Lead"      ,symbol="Pb", z= 82., a=207.19 *g/mole);
    // define simple materials-------------------------------------------------------
    new G4Material("Aluminium"  , z=13., a=  26.98  *g/mole, density= 2.700*g/cm3);
    new G4Material("Cupper"     , z=29., a=  63.546 *g/mole, density= 8.940*g/cm3);
    new G4Material("Graphite"   , z= 6., a=  12.017 *g/mole, density= 2.260*g/cm3);
    */

    // define a material from elements.   case 1: chemical molecule==================
    //G4Material* H2O =
    //				new G4Material("Water", density= 1.000*g/cm3, ncomponents=2);
    //H2O->AddElement(H, natoms=2);
    //H2O->AddElement(O, natoms=1);
    //// overwrite computed meanExcitationEnergy with ICRU recommended value
    //H2O->GetIonisation()->SetMeanExcitationEnergy(78.0*eV);

    G4Material* Air = new G4Material("Air"  , density= 1.290*mg/cm3, ncomponents=2);
                Air->AddElement(N, fractionmass=0.7);
                Air->AddElement(O, fractionmass=0.3);
    /*
    G4Material* Target = new G4Material("Target", density= 19.4*g/cm3, ncomponents=2);
				Target->AddElement (W   , fractionmass= 95*perCent);
				Target->AddElement (Re  , fractionmass=  5*perCent);

    G4Material* TZM = new G4Material("TZM", density= 10.22*g/cm3, ncomponents=4);
				TZM->AddElement (Ti  , fractionmass= 0.475*perCent);
				TZM->AddElement (Zr  , fractionmass= 0.07 *perCent);
				TZM->AddElement (Mo  , fractionmass= (100-0.483)*perCent);
				TZM->AddElement (C   , fractionmass= 0.01*perCent);

    G4Material* LeadAntimony =
        new G4Material("LeadAntimony", density= (11.34*0.88+6.697*0.12)*g/cm3, ncomponents=2);
				LeadAntimony->AddElement (Pb  , fractionmass= 88*perCent);
				LeadAntimony->AddElement (Sb  , fractionmass= 12*perCent);

    G4Material* Lead =
        new G4Material("pureLead", density= (11.34)*g/cm3, ncomponents=1);
				Lead->AddElement (Pb  , fractionmass= 100*perCent);

    G4Material* ENAW2017A =
        new G4Material("ENAW2017A", density= 2.790*g/cm3, ncomponents=8);
				ENAW2017A->AddElement(Si, fractionmass= 0.5 *perCent);
				ENAW2017A->AddElement(Fe, fractionmass= 0.7 *perCent);
				ENAW2017A->AddElement(Cu, fractionmass= 4.0 *perCent);
				ENAW2017A->AddElement(Mn, fractionmass= 0.7 *perCent);
				ENAW2017A->AddElement(Mg, fractionmass= 0.7 *perCent);
				ENAW2017A->AddElement(Cr, fractionmass= 0.1 *perCent);
				ENAW2017A->AddElement(Zn, fractionmass= 0.25*perCent);
				ENAW2017A->AddElement(Al, fractionmass=93.05*perCent);
    */

    G4NistManager* man = G4NistManager::Instance();
				//man->FindOrBuildMaterial("G4_POLYETHYLENE");
				man->FindOrBuildMaterial("G4_WATER");

    // Material for World
    G4Material* Vacuum =
        new G4Material("Galactic", z=1., a=1.01*g/mole,density= universe_mean_density,
																kStateGas, 2.73*kelvin, 3.e-18*pascal);
    // print table
    //G4cout << *(G4Material::GetMaterialTable()) << G4endl;

    //default materials of the World
    defaultMaterial  = Vacuum;
}

G4VPhysicalVolume* DetectorConstruction::ConstructCalorimeter()
{
    G4double pi = 3.14159265358979323846;

    // Clean old geometry, if any
    G4GeometryManager::GetInstance()->OpenGeometry();
    G4PhysicalVolumeStore::GetInstance()->Clean();
    G4LogicalVolumeStore::GetInstance()->Clean();
    G4SolidStore::GetInstance()->Clean();

    //====================================================================================
    // World
    //====================================================================================
    WorldSizeZX = 60*cm; WorldSizeY = 400*cm;
    solidWorld = new G4Box("World",WorldSizeZX/2,WorldSizeY/2,WorldSizeZX/2);   //its name
    logicWorld = new G4LogicalVolume(solidWorld,defaultMaterial,"World");       //its solid
    physiWorld = new G4PVPlacement(0,G4ThreeVector(),			                //no rotation at (0,0,0)
												logicWorld,		                              //its logical volume				 
												"World",0,false,0);		                      //its name
    /*
    //====================================================================================
    // Target
    //====================================================================================
    //-------------------Geometries---------------
    G4double TargetSizeXY  = 110.    *mm;
    G4double TargetSizeZ   =  50.    *mm;
    G4double FilmR1        =  60.4/2.*mm;
    G4double FilmR2        = 100.0/2.*mm;
    G4double FilmThickness =   1.    *mm;
    G4double TargetAngle   =  14.    *deg;
    G4double FilmHeight    = (FilmR2-FilmR1)*tan(TargetAngle);
    G4double Mount1R       =   4.    *mm;
    G4double Mount2Height  =   1.    *mm;
    G4double BeamPosition  =  40.4   *mm;
    G4double TargetOffsetX =  -FilmHeight/2.+(BeamPosition-FilmR1)*tan(TargetAngle);
    //------------------TargetBase--------------
    solidTarget = new G4Box("Target",TargetSizeXY/2,TargetSizeXY/2,TargetSizeZ/2);
    logicTarget = new G4LogicalVolume(solidTarget,defaultMaterial,"Target");
    G4RotationMatrix* rotTarget = new G4RotationMatrix;
    rotTarget->rotateY(90.*deg);
    G4ThreeVector xyzTarget(-TargetOffsetX,BeamPosition,0);
    physiTarget = new G4PVPlacement(G4Transform3D(*rotTarget,xyzTarget),
                                    logicTarget,"Target",logicWorld,false,0);
    //------------------Target--------------
    solidTargetFilm   = new G4Cons("TargetFilm",
                                    FilmR1-FilmThickness/sin(TargetAngle),FilmR1,
                                    FilmR2-FilmThickness/sin(TargetAngle),FilmR2,
                                    FilmHeight/2.,0,2*pi);
    logicTargetFilm   = new G4LogicalVolume(solidTargetFilm,
                                            TargetFilmMaterial,TargetFilmMaterial->GetName());
    physiTargetFilm   = new G4PVPlacement(0,G4ThreeVector(0,0,0),
                                            logicTargetFilm,TargetFilmMaterial->GetName(),
                                            logicTarget,false,0);
    //------------------Mount--------------
    solidTargetMount1 = new G4Cons("TargetMount1",
                                            Mount1R,FilmR1-FilmThickness/sin(TargetAngle),
                                            Mount1R,FilmR2-FilmThickness/sin(TargetAngle),
                                            FilmHeight/2.,0,2*pi);
    logicTargetMount1 = new G4LogicalVolume(solidTargetMount1,TargetMountMaterial,TargetMountMaterial->GetName());
    physiTargetMount1 = new G4PVPlacement(0,G4ThreeVector(0,0,0),logicTargetMount1,
                                            TargetMountMaterial->GetName(),logicTarget,false,0);

    solidTargetMount2 = new G4Tubs("TargetMount1",2*Mount1R,FilmR2,Mount2Height,0,2*pi);
    logicTargetMount2 = new G4LogicalVolume(solidTargetMount2,TargetMountMaterial,
                                            TargetMountMaterial->GetName());
    physiTargetMount2 = new G4PVPlacement(0,G4ThreeVector(0,0,FilmHeight/2.+Mount2Height/2.),
                        logicTargetMount2,TargetMountMaterial->GetName(),logicTarget,false,0);

    solidTargetBase   = new G4Tubs("TargetBase",2*Mount1R,FilmR2,FilmHeight+Mount2Height,0,2*pi);
    logicTargetBase   = new G4LogicalVolume(solidTargetBase,TargetBaseMaterial,
                                            TargetBaseMaterial->GetName());
    physiTargetBase   = new G4PVPlacement(0,G4ThreeVector(0,0,
                                            FilmHeight+Mount2Height+(FilmHeight+Mount2Height)),
                                            logicTargetBase,TargetBaseMaterial->GetName(),
                                            logicTarget,false,0);

    //====================================================================================
    // Cone Filter
    //====================================================================================
    //-------------------Geometries---------------
    G4double CFSizeXY             = 80.    *mm;
    G4double CFSizeZ              = 50.    *mm;
    G4double filter1R             = 35. /2.*mm;
    G4double filter2R             = 35. /2.*mm;
    G4double filter3R             = 30.7/2.*mm;
    G4double filter1thickness     =  0.1   *mm;
    G4double filter2thickness     =  2.    *mm;
    G4double filter3thickness     =  0.6   *mm;
    G4double Oringoffset          =  5.0   *mm;
    G4double lconeangle           =  23.   *deg;
    G4double lcone1R1min          =(34.9/2.-2.5/cos(lconeangle))*mm;
    G4double lcone1R1max          = 34.9/2.*mm;
    G4double lcone1R2min          =lcone1R1min+19.*tan(lconeangle)*mm;
    G4double lcone1R2max          =lcone1R1max+19.*tan(lconeangle)*mm;
    G4double lconethickness       =(19.1+3.5)*mm;
    G4double lcone2R1             =  0.    *mm;
    G4double lcone2R2             =(30.7+2.5)/2.*mm;
    G4double lcone2thickness      =  2.4   *mm;
    G4double lconewindowsize      = 21./2. *mm;
    G4double lcone3R1             = 34.6/2.*mm;
    G4double lcone3R2             = 55./2. *mm;
    G4double lcone3thickness      =  2.5   *mm;
    G4double lconeposition        = 60.5*mm+lconethickness/2.+lcone3thickness;
    
    //------------------LeadConeBase--------------
    solidConeFilter = new G4Box("ConeFilter",CFSizeXY/2,CFSizeXY/2,CFSizeZ/2);
    logicConeFilter = new G4LogicalVolume(solidConeFilter,defaultMaterial,"ConeFilter");
    G4RotationMatrix* rotCF = new G4RotationMatrix;
    rotCF->rotateX(90.*deg);
    G4ThreeVector xyzConeFilter(0,-lconeposition,0);
    physiConeFilter = new G4PVPlacement(G4Transform3D(*rotCF,xyzConeFilter),
                                    logicConeFilter,"ConeFilter",logicWorld,false,0);

    //------------------Filters-------------------
    solidFilter1 = new G4Tubs("Filter1",0,filter1R,filter1thickness/2.,0,2*pi);
    logicFilter1 = new G4LogicalVolume(solidFilter1,Filter1Material,Filter1Material->GetName());
    physiFilter1 = new G4PVPlacement(0,G4ThreeVector(0,0,
                        -lconethickness/2.-Oringoffset-filter1thickness/2.-filter2thickness),
                        logicFilter1,Filter1Material->GetName(),logicConeFilter,false,0);

    solidFilter2 = new G4Tubs("Filter2",0,filter2R,filter2thickness/2.,0,2*pi);
    logicFilter2 = new G4LogicalVolume(solidFilter2,Filter2Material,Filter2Material->GetName());
    physiFilter2 = new G4PVPlacement(0,G4ThreeVector(0,0,
                        -lconethickness/2.-Oringoffset-filter2thickness/2.),
                        logicFilter2,Filter2Material->GetName(),logicConeFilter,false,0);
    solidFilter3 = new G4Tubs("Filter3",0,filter3R,filter3thickness/2.,0,2*pi);
    logicFilter3 = new G4LogicalVolume(solidFilter3,Filter3Material,Filter3Material->GetName());
    physiFilter3 = new G4PVPlacement(0,G4ThreeVector(0,0,-lconethickness/2.),
                        logicFilter3,Filter3Material->GetName(),logicConeFilter,false,0);

    //------------------LeadCone-------------------
    solidLCone1 = new G4Cons("LCone1",lcone1R1min,lcone1R1max,
                                  lcone1R2min,lcone1R2max,lconethickness/2.,0,2*pi);
    solidLConeBase = new G4Tubs("LConeBase",lcone2R1,lcone2R2,lcone2thickness/2.,0,2*pi);
    solidLConeWindow = new G4Box("LConeWindow",lconewindowsize,lconewindowsize,lcone2thickness/2.);
    G4VSolid* solidLCone2 = new G4SubtractionSolid("LCone2", solidLConeBase,
                        solidLConeWindow,0, G4ThreeVector(0.,0.,0.));
    solidLCone3 = new G4Tubs("LCone3",lcone3R1,lcone3R2,lcone3thickness/2.,0,2*pi);
    G4VSolid* solidLCone4 = new G4UnionSolid("LCone4", solidLCone1, solidLCone2,
                    0,G4ThreeVector(0.,0.,-lconethickness/2.+lcone2thickness/2.+1.1*mm));
    G4VSolid* solidLCone  = new G4UnionSolid("LCone", solidLCone4, solidLCone3,
                    0, G4ThreeVector(0.,0.,lconethickness/2.+lcone3thickness/2.));
    logicLCone = new G4LogicalVolume(solidLCone,LeadConeMaterial,LeadConeMaterial->GetName());
    physiLCone = new G4PVPlacement(0,G4ThreeVector(0,0,0),
                    logicLCone,LeadConeMaterial->GetName(),logicConeFilter,false,0);
    //====================================================================================

    //====================================================================================
    // PrimaryColliometer
    //====================================================================================
    //-------------------Geometries---------------
    G4double CRWindowsizeX    = 47.*mm;
    G4double CRWindowsizeY    = 38.*mm;
    G4double CRoffsetX        = (28.-47./2.)/2.*mm;
    G4double CRR              = 77./2.*mm;
    G4double CRThickness      = 3.*mm;
    G4double PCWindowsizeX    = 34.*mm;
    G4double PCWindowsizeY    = 32.*mm;
    G4double PCoffsetX        = (22.-34./2.)/2.*mm;
    G4double PCR              = 76./2.*mm;
    G4double PCThickness      = 3.2*mm;
    //-------------------PrimaryCollimeterBase----
    solidClampRingWindow = new G4Box("ClampRingWindow",CRWindowsizeX/2,CRWindowsizeY/2,CRThickness/2);
    solidClampRingBase   = new G4Tubs("ClampRingBase",0,CRR,CRThickness/2,0,2*pi);
    solidClampRing       = new G4SubtractionSolid("ClampRing", solidClampRingBase, solidClampRingWindow,
                                0, G4ThreeVector(-CRoffsetX,0.,0.));
    logicClampRing       = new G4LogicalVolume(solidClampRing,ClampRingMaterial,ClampRingMaterial->GetName());
    physiClampRing       = new G4PVPlacement(0,G4ThreeVector(0,0,
                            lconethickness/2.+lcone3thickness/2.+CRThickness/2.+5.8*mm),
                            logicClampRing,ClampRingMaterial->GetName(),logicConeFilter,false,0);
    solidPrimColWindow   = new G4Box("PrimColWindow",PCWindowsizeX/2,PCWindowsizeY/2,PCThickness/2);
    solidPrimColBase     = new G4Tubs("PrimColBase",0,PCR,PCThickness/2,0,2*pi);
    solidPrimCol         = new G4SubtractionSolid("PrimCol", solidPrimColBase, solidPrimColWindow,
                                                  0, G4ThreeVector(-PCoffsetX,0.,0.));
    logicPrimCol         = new G4LogicalVolume(solidPrimCol,PrimColMaterial,PrimColMaterial->GetName());
    physiPrimCol         = new G4PVPlacement(0,G4ThreeVector(0,0,
                            lconethickness/2.+lcone3thickness/2.+CRThickness+PCThickness/2.+5.8*mm),
                            logicPrimCol,PrimColMaterial->GetName(),logicConeFilter,false,0);

    //====================================================================================
    // Collimeters
    //====================================================================================
    //-------------------Geometries---------------
    G4double ColSizeXY          = 150*mm;
    G4double ColSizeZ           = 140*mm;
    G4double colposition        = 195.80*mm;

    G4double SLsizeX            = 140.*mm;
    G4double SLsizeY            = 129.*mm;
    G4double SLWindowsizeX      = 85.*mm;
    G4double SLWindowsizeY      = 81.*mm;
    G4double SLoffsetX          = (39.5-(140.-(39.5+85.)))/2.*mm;
    G4double SLThickness        = 2.24*mm;
    G4double SLposition         = 174.26*mm;
    G4double SBThickness        = 2.*mm;
    G4double SBposition         = 176.50*mm;
    G4double LCWindowsizeXY_S20 = 55.339*mm;
    G4double LCsizeXY           = 127.5*mm;
    G4double LCThickness        = 3.2*mm;
    G4double CWsizeXY           = 129.5*mm;
    G4double CWThickness        = 1.*mm;
    G4double BFposition         = 230.50*mm;
    G4double BFsizeXY           = 103*mm;
    G4double BFThickness        = 2.*mm;
    G4double BFTotalThickness   = 31*mm;


    solidCollimeter = new G4Box("Collimeter",ColSizeXY/2.,ColSizeXY/2.,ColSizeZ/2.);
    logicCollimeter = new G4LogicalVolume(solidCollimeter,defaultMaterial,"Collimeter");
    G4RotationMatrix* rotCol = new G4RotationMatrix;
    rotCol->rotateX(90.*deg);
    G4ThreeVector xyzCollimeter(0,-colposition,0);
    physiCollimeter          = new G4PVPlacement(G4Transform3D(*rotCol,xyzCollimeter),
                                    logicCollimeter,"Collimeter",logicWorld,false,0);

    solidShieldingLeadWindow   = new G4Box("ShieldingLeadWindow",
                                           SLWindowsizeX/2,SLWindowsizeY/2,SLThickness/2);
    solidShieldingLeadBase     = new G4Box("ShieldingLeadBase",
                                           SLsizeX/2,SLsizeY/2,SLThickness/2);
    solidShieldingLead         = new G4SubtractionSolid("ShieldingLead",
                                            solidShieldingLeadBase,solidShieldingLeadWindow,
                                            0, G4ThreeVector(SLoffsetX,0.,0.));
    logicShieldingLead         = new G4LogicalVolume(solidShieldingLead,ShieldingLeadMaterial,
                                            ShieldingLeadMaterial->GetName());
    physiShieldingLead         = new G4PVPlacement(0,G4ThreeVector(0,0,
                                            -(colposition-SLposition)-SLThickness/2.),
                        logicShieldingLead,ShieldingLeadMaterial->GetName(),logicCollimeter,false,0);
    solidShieldingBracketWindow   = new G4Box("ShieldingBracketWindow",
                                              SLWindowsizeX/2,SLWindowsizeY/2,SBThickness/2);
    solidShieldingBracketBase     = new G4Box("ShieldingBracketBase",
                                              SLsizeX/2,SLsizeY/2,SBThickness/2);
    solidShieldingBracket         = new G4SubtractionSolid("ShieldingBracket",
                                        solidShieldingBracketBase,solidShieldingBracketWindow,
                                        0, G4ThreeVector(SLoffsetX,0.,0.));
    logicShieldingBracket         = new G4LogicalVolume(solidShieldingBracket,ShieldingBracketMaterial,
                                                        ShieldingBracketMaterial->GetName());
    physiShieldingBracket         = new G4PVPlacement(0,G4ThreeVector(0,0,
                                                        -(colposition-SBposition)-SBThickness/2.),
                        logicShieldingBracket,ShieldingBracketMaterial->GetName(),
                                                      logicCollimeter,false,0);

    solidLeadCollimeterWindow   = new G4Box("LeadCollimeterWindow",
                                        LCWindowsizeXY_S20/2,LCWindowsizeXY_S20/2,LCThickness/2);
    solidLeadCollimeterBase     = new G4Box("LeadCollimeterBase",
                                            LCsizeXY/2,LCsizeXY/2,LCThickness/2);
    solidLeadCollimeter         = new G4SubtractionSolid("LeadCollimeter",
                                            solidLeadCollimeterBase,solidLeadCollimeterWindow,
                                            0, G4ThreeVector(0,0.,0.));
    logicLeadCollimeter         = new G4LogicalVolume(solidLeadCollimeter,
                                    LeadCollimeterMaterial,LeadCollimeterMaterial->GetName());
    physiLeadCollimeter         = new G4PVPlacement(0,
                                    G4ThreeVector(0,0,CWThickness/2.+LCThickness/2.),
                                    logicLeadCollimeter,LeadCollimeterMaterial->GetName(),
                                    logicCollimeter,false,0);

    solidCassettleWindow1       = new G4Box("CasettleWindow1",
                                            CWsizeXY/2,CWsizeXY/2,CWThickness/2);
    logicCassettleWindow1       = new G4LogicalVolume(solidCassettleWindow1,
                                    CassettleWindowMaterial,CassettleWindowMaterial->GetName());
    physiCassettleWindow1       = new G4PVPlacement(0,
                                                    G4ThreeVector(0,0,CWThickness/2.),
                                                    logicCassettleWindow1,
                                                    CassettleWindowMaterial->GetName(),
                                                    logicCollimeter,false,0);

    solidCassettleWindow2       = new G4Box("CasettleWindow2",
                                            CWsizeXY/2,CWsizeXY/2,CWThickness/2);
    logicCassettleWindow2       = new G4LogicalVolume(solidCassettleWindow2,
                                                      CassettleWindowMaterial,
                                                      CassettleWindowMaterial->GetName());
    physiCassettleWindow2       = new G4PVPlacement(0,
                                                    G4ThreeVector(0,0,LCThickness+CWThickness/2.),
                                                    logicCassettleWindow2,
                                                    CassettleWindowMaterial->GetName(),
                                                    logicCollimeter,false,0);

    solidBowtieFilter           = new G4Box("BowtieFilter",
                                            BFsizeXY/2,BFsizeXY/2,BFThickness/2);
    logicBowtieFilter           = new G4LogicalVolume(solidBowtieFilter,
                                                      BowtieFilterMaterial,
                                                      BowtieFilterMaterial->GetName());
    physiBowtieFilter           = new G4PVPlacement(0,G4ThreeVector(0,0,
                                -(colposition-BFposition)+CWThickness/2.+BFTotalThickness/2.),
                logicBowtieFilter,BowtieFilterMaterial->GetName(),logicCollimeter,false,0);

    solidCassettleWindow3       = new G4Box("CasettleWindow3",
                                            CWsizeXY/2,CWsizeXY/2,CWThickness/2);
    logicCassettleWindow3       = new G4LogicalVolume(solidCassettleWindow3,
                                                      CassettleWindowMaterial,
                                                      CassettleWindowMaterial->GetName());
    physiCassettleWindow3       = new G4PVPlacement(0,
                                    G4ThreeVector(0,0,-(colposition-BFposition)+CWThickness/2.),
                                    logicCassettleWindow3,CassettleWindowMaterial->GetName(),
                                    logicCollimeter,false,0);
    solidCassettleWindow4       = new G4Box("CasettleWindow4",
                                            CWsizeXY/2,CWsizeXY/2,CWThickness/2);
    logicCassettleWindow4       = new G4LogicalVolume(solidCassettleWindow4,
                                                      CassettleWindowMaterial,
                                                      CassettleWindowMaterial->GetName());
    physiCassettleWindow4       = new G4PVPlacement(0,
                            G4ThreeVector(0,0,-(colposition-BFposition)+CWThickness/2.+BFTotalThickness),
                            logicCassettleWindow4,
                            CassettleWindowMaterial->GetName(),logicCollimeter,false,0);

     */
    //====================================================================================
    //  Phantoms
    //====================================================================================
    //-------------------Geometries---------------
    SSD                    = 100.*cm;
    PhantomSizeXY          = 600*mm;
    PhantomSizeZ           = 600*mm;
    Phantomposition        = PhantomSizeZ/2.+SSD;
    PhantomXCells          = 120;
    PhantomYCells          = 120;
    PhantomZCells          = 300;
    G4ThreeVector sensSize;
    sensSize.setX(PhantomSizeXY/PhantomXCells); // Detector xsize = 5 mm
    sensSize.setY(PhantomSizeXY/PhantomYCells); // Detector ysize = 5 mm
    sensSize.setZ(PhantomSizeZ /PhantomZCells); // Detector zsize = 2 mm

    G4double DetectorSizeXY         = 300*mm;
    G4double DetectorSizeZ          = 0.1*mm;
    G4double Detectorposition       =71*cm-DetectorSizeZ/2.;

    solidVirtualDetector    = new G4Box("VirtualDetector",
                                        DetectorSizeXY/2,
                                        DetectorSizeXY/2,
                                        DetectorSizeZ/2);
    logicVirtualDetector    = new G4LogicalVolume(solidVirtualDetector,
                                        DetectorMaterial,
                                        DetectorMaterial->GetName());
    G4RotationMatrix* rotDetector = new G4RotationMatrix;
    rotDetector->rotateX( 90.*deg);
    G4ThreeVector xyzDetector(0,-Detectorposition,0);
    physiVirtualDetector    = new G4PVPlacement(G4Transform3D(*rotDetector,xyzDetector),
                                logicVirtualDetector,
                                DetectorMaterial->GetName(),
                                logicWorld,false,0);

    //-------------------Water Phantom---------------

    solidWaterPhantom       = new G4Box("Phantom",
                                        PhantomSizeXY/2,
                                        PhantomSizeXY/2,
                                        PhantomSizeZ/2);
    logicWaterPhantom       = new G4LogicalVolume(solidWaterPhantom,
                                        PhantomMaterial,"Phantom", 0, 0, 0);
    G4RotationMatrix* rotPhantom = new G4RotationMatrix;
    rotPhantom->rotateX( 90.*deg);
    rotPhantom->rotateY(180.*deg);
    G4ThreeVector xyzPhantom(0,-Phantomposition,0);
    physiWaterPhantom       = new G4PVPlacement(
                                G4Transform3D(*rotPhantom,xyzPhantom),
                                logicWaterPhantom,"Phantom",logicWorld,false,0);

    // Region for cuts
    G4Region *regVol= new G4Region("PhantomR");
    G4ProductionCuts* cuts = new G4ProductionCuts;
    cuts->SetProductionCut(0.1*mm);
    regVol->SetProductionCuts(cuts);
    logicWaterPhantom->SetRegion(regVol);
    regVol->AddRootLogicalVolume(logicWaterPhantom);


    // Replication of Water Phantom Volume.
    // Y Slice
    G4String yRepName("RepY");
    G4VSolid        *solYRep  = new G4Box(yRepName,PhantomSizeXY/2.,sensSize.y()/2.,PhantomSizeZ/2.);
    G4LogicalVolume *logYRep  = new G4LogicalVolume(solYRep,PhantomMaterial,yRepName);
    G4PVReplica     *yReplica = new G4PVReplica(yRepName,
                                                logYRep,
                                                logicWaterPhantom,
                                                kYAxis,
                                                PhantomYCells,sensSize.y());
    // X Slice
    G4String xRepName("RepX");
    G4VSolid        *solXRep  = new G4Box(xRepName,sensSize.x()/2.,sensSize.y()/2.,PhantomSizeZ/2.);
    G4LogicalVolume *logXRep  = new G4LogicalVolume(solXRep,PhantomMaterial,xRepName);
    G4PVReplica     *xReplica = new G4PVReplica(xRepName,
                                                logXRep,
                                                logYRep,
                                                kXAxis,
                                                PhantomXCells,sensSize.x());
    // Z Slice
    G4String zVoxName("phantomSens");
    G4VSolid        * solVoxel        = new G4Box(zVoxName,sensSize.x()/2.,sensSize.y()/2.,sensSize.z()/2.);
    G4LogicalVolume *logicPhantomSens = new G4LogicalVolume(solVoxel,PhantomMaterial,zVoxName);
    std::vector<G4Material*> phantomMat(2,PhantomMaterial);
    //NestedPhantomParameterisation* paramPhantom = new NestedPhantomParameterisation(
    //sensSize/2.,
    //PhantomZCells,
    //phantomMat);
    //G4VPhysicalVolume *physiPhantomSens;
    //physiPhantomSens= new G4PVParameterised("PhantomSens",
    //                                        logicPhantomSens,
    //                                        logXRep,
    //                                        kUndefined,
    //                                        PhantomZCells,paramPhantom);

    //MultiFunctionDetector
    G4SDManager               *SDman         = G4SDManager::GetSDMpointer();
    G4String                   phantomSDname = "PhantomSD";
    G4MultiFunctionalDetector *MFDet         = new G4MultiFunctionalDetector(phantomSDname);
    SDman                     ->AddNewDetector( MFDet );      // Register SD to SDManager.
    logicPhantomSens          ->SetSensitiveDetector(MFDet);  // Assign SD to the logical volume.
    G4String psName;
    G4PSEnergyDeposit         *scorer0       = new PSEnergyDeposit(psName="totalEDep",
                            (G4int)PhantomXCells,(G4int)PhantomYCells,(G4int)PhantomZCells);
    MFDet->RegisterPrimitive(scorer0);
    
    // Visualization Setting=================================================
    //logicWorld->SetVisAttributes (G4VisAttributes::Invisible);
    //G4VisAttributes* visTarget     = new G4VisAttributes(G4Colour::Magenta());
    //G4VisAttributes* visConeFilter = new G4VisAttributes(G4Colour::Gray());
    //G4VisAttributes* visCollimeter = new G4VisAttributes(G4Colour::Yellow());
    G4VisAttributes* visDetector   = new G4VisAttributes(G4Colour::Green());
    G4VisAttributes* visPhantom    = new G4VisAttributes(G4Colour::Cyan());

    //visTarget    ->SetVisibility(true);
    //visConeFilter->SetVisibility(true);
    //visCollimeter->SetVisibility(true);
    visDetector  ->SetVisibility(true);
    visPhantom   ->SetVisibility(true);

    //logicTargetFilm      ->SetVisAttributes(visTarget);
    //logicTargetMount1    ->SetVisAttributes(visTarget);
    //logicTargetMount2    ->SetVisAttributes(visTarget);
    //logicTargetBase      ->SetVisAttributes(visTarget);

    //logicFilter1         ->SetVisAttributes(visConeFilter);
    //logicFilter2         ->SetVisAttributes(visConeFilter);
    //logicFilter3         ->SetVisAttributes(visConeFilter);
    //logicLCone           ->SetVisAttributes(visConeFilter);

    //logicCollimeter      ->SetVisAttributes(visCollimeter);
    
    logicVirtualDetector ->SetVisAttributes(visDetector);
    logicWaterPhantom    ->SetVisAttributes(visPhantom);

    //logicPhantomSens->SetVisAttributes(G4VisAttributes::Invisible);

    //always return the physical World
    return physiWorld;
}



#include "G4FieldManager.hh"
#include "G4TransportationManager.hh"

void DetectorConstruction::SetMagField(G4double fieldValue)
{
				//apply a global uniform magnetic field along Z axis
				G4FieldManager* fieldMgr
								= G4TransportationManager::GetTransportationManager()->GetFieldManager();
				if(magField) delete magField;		//delete the existing magn field
				if(fieldValue!=0.)			// create a new one if non nul
				{ magField = new G4UniformMagField(G4ThreeVector(0.,0.,fieldValue));
								fieldMgr->SetDetectorField(magField);
								fieldMgr->CreateChordFinder(magField);
				} else {
								magField = 0;
								fieldMgr->SetDetectorField(magField);
				}
}


#include "G4RunManager.hh"

void DetectorConstruction::UpdateGeometry()
{
				G4RunManager::GetRunManager()->DefineWorldVolume(ConstructCalorimeter());
}

/*
void DetectorConstruction::SetTargetFilmMaterial(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) TargetFilmMaterial = pttoMaterial;
}
void DetectorConstruction::SetTargetMountMaterial(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) TargetMountMaterial = pttoMaterial;
}
void DetectorConstruction::SetTargetBaseMaterial(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) TargetBaseMaterial = pttoMaterial;
}
void DetectorConstruction::SetLeadConeMaterial(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) LeadConeMaterial = pttoMaterial;
}
void DetectorConstruction::SetFilter1Material(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) Filter1Material = pttoMaterial;
}
void DetectorConstruction::SetFilter2Material(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) Filter2Material = pttoMaterial;
}
void DetectorConstruction::SetFilter3Material(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) Filter3Material = pttoMaterial;
}
void DetectorConstruction::SetClampRingMaterial(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) ClampRingMaterial = pttoMaterial;
}
void DetectorConstruction::SetPrimColMaterial(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) PrimColMaterial = pttoMaterial;
}
void DetectorConstruction::SetShieldingLeadMaterial(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) ShieldingLeadMaterial = pttoMaterial;
}
void DetectorConstruction::SetShieldingBracketMaterial(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) ShieldingBracketMaterial = pttoMaterial;
}
void DetectorConstruction::SetLeadCollimeterMaterial(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) LeadCollimeterMaterial = pttoMaterial;
}
void DetectorConstruction::SetCassettleWindowMaterial(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) CassettleWindowMaterial = pttoMaterial;
}
void DetectorConstruction::SetBowtieFilterMaterial(G4String materialChoice)
{
    G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
    if (pttoMaterial) BowtieFilterMaterial = pttoMaterial;
}
*/
void DetectorConstruction::SetDetectorMaterial(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) DetectorMaterial = pttoMaterial;
}
void DetectorConstruction::SetPhantomMaterial(G4String materialChoice)
{
				G4Material* pttoMaterial = G4Material::GetMaterial(materialChoice);
				if (pttoMaterial) PhantomMaterial = pttoMaterial;
}
