#include "RunAction.hh"

#include "PDDRun.hh"
#include "DetectorConstruction.hh"

#include "G4Run.hh"
#include "G4UserRunAction.hh"
#include "G4RunManager.hh"
#include "G4UnitsTable.hh"
#include "G4THitsMap.hh"
#include "G4Timer.hh"

using namespace CLHEP;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

RunAction::RunAction()
{
    theSDName.push_back(G4String("PhantomSD"));
}

RunAction::~RunAction()
{
    theSDName.clear();
}
G4Run* RunAction::GenerateRun()
{
    return new PDDRun(theSDName);
}

void RunAction::BeginOfRunAction(const G4Run* aRun)
{ 

    timer = new G4Timer();
	timer->Start();

    G4cout << "### Run " << aRun->GetRunID() << " start ###" << G4endl;


/*
    //inform the runManager to save random number seed
    G4RunManager::GetRunManager()->SetRandomNumberStore(true);

	//ROOT
    anaManager = G4AnalysisManager::Instance();

	const DetectorConstruction* detector =(const DetectorConstruction*)(G4RunManager::GetRunManager()->GetUserDetectorConstruction());
	detector->GetNumberOfSegmentsInPhantom(fNx,fNy,fNz); //Fill fNx,y,z.
	detector->GetPhantomPosandSize(Ppos,PsizeXY,PsizeZ); //Fill fNx,y,z.

	G4String filename = "Pencil_Beam_forPDDCheck";
	anaManager->OpenFile(filename);
	anaManager->SetHistoDirectoryName("VirtualDetector");

	anaManager->CreateH1("h1Events"             ,"Number of Events"                             ,1,0,1);           //0
	anaManager->CreateH1("h1TotEnergy"          ,"Energy Spectrum at Virtual Detector"          ,600,0,150);       //1
	anaManager->CreateH1("h1TotEnergy2"         ,"Energy Spectrum at Virtual Detector square"   ,600,0,150);       //2
	anaManager->CreateH1("h1VertexPos2040"      ,"Photon VertexPos at Virtual Detector[20-40]"  ,120,0*cm,120*cm); //3
	anaManager->CreateH1("h1VertexPos4060"      ,"Photon VertexPos at Virtual Detector[40-60]"  ,120,0*cm,120*cm); //4
	anaManager->CreateH1("h1VertexPos6080"      ,"Photon VertexPos at Virtual Detector[60-80]"  ,120,0*cm,120*cm); //5
	anaManager->CreateH1("h1VertexPos80100"     ,"Photon VertexPos at Virtual Detector[80-100]" ,120,0*cm,120*cm); //6
	anaManager->CreateH1("h1VertexPos100120"    ,"Photon VertexPos at Virtual Detector[100-120]",120,0*cm,120*cm); //7

	anaManager->CreateH1("h1PencilPDD"     ,"PDD of Pencil Beam"                       ,fNz,  0*cm ,PsizeZ);               //8
	anaManager->CreateH1("h1PencilOCRCr30" ,"OCR of Pencil Beam [Cross30mm]"           ,fNx ,-PsizeXY/2,PsizeXY/2);        //9
	anaManager->CreateH1("h1PencilOCRCr50" ,"OCR of Pencil Beam [Cross50mm]"           ,fNx ,-PsizeXY/2,PsizeXY/2);        //10
	anaManager->CreateH1("h1PencilOCRCr100","OCR of Pencil Beam [Cross100mm]"          ,fNx ,-PsizeXY/2,PsizeXY/2);        //11
	anaManager->CreateH1("h1PencilOCRIn30" ,"OCR of Pencil Beam [In30mm]"              ,fNy ,-PsizeXY/2,PsizeXY/2);        //12
	anaManager->CreateH1("h1PencilOCRIn50" ,"OCR of Pencil Beam [In50mm]"              ,fNy ,-PsizeXY/2,PsizeXY/2);        //13
	anaManager->CreateH1("h1PencilOCRIn100","OCR of Pencil Beam [In100mm]"             ,fNy ,-PsizeXY/2,PsizeXY/2);        //14

	anaManager->CreateH2("h2posE2040"  ,"Hit position on Virtual Detector [20-40]"  ,150,   -150*mm,   150*mm,150,   -150*mm,   150*mm);//0
	anaManager->CreateH2("h2posE4060"  ,"Hit position on Virtual Detector [40-60]"  ,150,   -150*mm,   150*mm,150,   -150*mm,   150*mm);//1
	anaManager->CreateH2("h2posE6080"  ,"Hit position on Virtual Detector [60-80]"  ,150,   -150*mm,   150*mm,150,   -150*mm,   150*mm);//2
	anaManager->CreateH2("h2posE80100" ,"Hit position on Virtual Detector [80-100]" ,150,   -150*mm,   150*mm,150,   -150*mm,   150*mm);//3
	anaManager->CreateH2("h2posE100120","Hit position on Virtual Detector [100-120]",150,   -150*mm,   150*mm,150,   -150*mm,   150*mm);//4
	anaManager->CreateH2("h2angE2040"  ,"Hit angle on Virtual Detector [20-40]"     ,150,   -10*deg,   10*deg,150,   -10*deg,    10*deg);//5
	anaManager->CreateH2("h2angE4060"  ,"Hit angle on Virtual Detector [40-60]"     ,150,   -10*deg,   10*deg,150,   -10*deg,    10*deg);//6
	anaManager->CreateH2("h2angE6080"  ,"Hit angle on Virtual Detector [60-80]"     ,150,   -10*deg,   10*deg,150,   -10*deg,    10*deg);//7
	anaManager->CreateH2("h2angE80100" ,"Hit angle on Virtual Detector [80-100]"    ,150,   -10*deg,   10*deg,150,   -10*deg,    10*deg);//8
	anaManager->CreateH2("h2angE100120","Hit angle on Virtual Detector [100-120]"   ,150,   -10*deg,   10*deg,150,   -10*deg,    10*deg);//9
	anaManager->CreateH2("h2AnglePosX" ,"Photon AngleX vs PosX at Virtual Detector" ,150,   -150*mm,   150*mm,150,   -10*deg,    10*deg);//10
	anaManager->CreateH2("h2AnglePosZ" ,"Photon AngleZ vs PosZ at Virtual Detector" ,150,   -150*mm,   150*mm,150,   -10*deg,    10*deg);//11

*/


}

void RunAction::EndOfRunAction(const G4Run* aRun)
{
  G4int NbOfEvents = aRun->GetNumberOfEvent();
  if (NbOfEvents == 0) return;
/*
	PDDRun* pddRun = (PDDRun*)aRun;
	G4THitsMap<G4double>* totEdep = pddRun->GetHitsMap("PhantomSD/totalEDep");  

	G4double Pwidthx = PsizeXY/(double)fNx;
	G4double Pwidthy = PsizeXY/(double)fNy;
	G4double Pwidthz = PsizeZ /(double)fNz;

	G4int ix= fNx/2;
	G4int iy= fNy/2;



	for (G4int iz = 0; iz < fNz; iz++){
					G4double* totED_center0 = (*totEdep)[CopyNo(ix  ,iy  ,iz)];
					G4double* totED_center1 = (*totEdep)[CopyNo(ix-1,iy  ,iz)];
					G4double* totED_center2 = (*totEdep)[CopyNo(ix  ,iy-1,iz)];
					G4double* totED_center3 = (*totEdep)[CopyNo(ix-1,iy-1,iz)];
					if ( !totED_center0 ) totED_center0 = new G4double(0.0);
					if ( !totED_center1 ) totED_center1 = new G4double(0.0);
					if ( !totED_center2 ) totED_center2 = new G4double(0.0);
					if ( !totED_center3 ) totED_center3 = new G4double(0.0);
					G4double  depth = Pwidthz/2. + iz*Pwidthz;
					G4double temp0= *totED_center0;
					G4double temp1= *totED_center1;
					G4double temp2= *totED_center2;
					G4double temp3= *totED_center3;
					G4double av_totED = (temp0+temp1+temp2+temp3)/4.;
					anaManager->FillH1(8,depth,av_totED);

					if(abs(depth-(3*cm+0.25*cm))<2.5*mm){
									for(G4int i=0;i<fNx;i++){
													G4double *totED_OCRCr0= (*totEdep)[CopyNo(i  ,fNy/2,iz)];
													G4double *totED_OCRCr1= (*totEdep)[CopyNo(i  ,fNy/2,iz-1)];
													if ( !totED_OCRCr0 ) totED_OCRCr0 = new G4double(0.0);
													if ( !totED_OCRCr1 ) totED_OCRCr1 = new G4double(0.0);
													G4double temp0= *totED_OCRCr0;
													G4double temp1= *totED_OCRCr1;
													G4double temp2=(temp0+temp1)/2.;
													G4double positionx = Pwidthx/2. + i*Pwidthx - Pwidthx*fNx/2;
													anaManager->FillH1(9,positionx,temp2);

													G4double *totED_OCRIn0= (*totEdep)[CopyNo(fNx/2  ,i,iz)];
													G4double *totED_OCRIn1= (*totEdep)[CopyNo(fNx/2  ,i,iz-1)];
													if ( !totED_OCRIn0 ) totED_OCRIn0 = new G4double(0.0);
													if ( !totED_OCRIn1 ) totED_OCRIn1 = new G4double(0.0);
													G4double temp3= *totED_OCRIn0;
													G4double temp4= *totED_OCRIn1;
													G4double temp5=(temp3+temp4)/2.;
													G4double positiony = Pwidthy/2. + i*Pwidthy - Pwidthy*fNy/2;
													anaManager->FillH1(12,positiony,temp5);

									}
					}
					if(abs(depth-(5*cm+0.25*cm))<2.5*mm){
									for(G4int i=0;i<fNx;i++){

													G4double *totED_OCRCr0= (*totEdep)[CopyNo(i  ,fNy/2,iz)];
													G4double *totED_OCRCr1= (*totEdep)[CopyNo(i  ,fNy/2,iz-1)];
													if ( !totED_OCRCr0 ) totED_OCRCr0 = new G4double(0.0);
													if ( !totED_OCRCr1 ) totED_OCRCr1 = new G4double(0.0);
													G4double temp0= *totED_OCRCr0;
													G4double temp1= *totED_OCRCr1;
													G4double temp2=(temp0+temp1)/2.;
													G4double positionx = Pwidthx/2. + i*Pwidthx - Pwidthx*fNx/2;
													anaManager->FillH1(10,positionx,temp2);

													G4double *totED_OCRIn0= (*totEdep)[CopyNo(fNx/2  ,i,iz)];
													G4double *totED_OCRIn1= (*totEdep)[CopyNo(fNx/2  ,i,iz-1)];
													if ( !totED_OCRIn0 ) totED_OCRIn0 = new G4double(0.0);
													if ( !totED_OCRIn1 ) totED_OCRIn1 = new G4double(0.0);
													G4double temp3= *totED_OCRIn0;
													G4double temp4= *totED_OCRIn1;
													G4double temp5=(temp3+temp4)/2.;
													G4double positiony = Pwidthy/2. + i*Pwidthy - Pwidthy*fNy/2;
													anaManager->FillH1(13,positiony,temp5);

									}
					}
					if(abs(depth-(10*cm+0.25*cm))<2.5*mm){
									for(G4int i=0;i<fNx;i++){

													G4double *totED_OCRCr0= (*totEdep)[CopyNo(i  ,fNy/2,iz)];
													G4double *totED_OCRCr1= (*totEdep)[CopyNo(i  ,fNy/2,iz-1)];
													if ( !totED_OCRCr0 ) totED_OCRCr0 = new G4double(0.0);
													if ( !totED_OCRCr1 ) totED_OCRCr1 = new G4double(0.0);
													G4double temp0= *totED_OCRCr0;
													G4double temp1= *totED_OCRCr1;
													G4double temp2=(temp0+temp1)/2.;
													G4double positionx = Pwidthx/2. + i*Pwidthx - Pwidthx*fNx/2;
													anaManager->FillH1(11,positionx,temp2);

													G4double *totED_OCRIn0= (*totEdep)[CopyNo(fNx/2  ,i,iz)];
													G4double *totED_OCRIn1= (*totEdep)[CopyNo(fNx/2  ,i,iz-1)];
													if ( !totED_OCRIn0 ) totED_OCRIn0 = new G4double(0.0);
													if ( !totED_OCRIn1 ) totED_OCRIn1 = new G4double(0.0);
													G4double temp3= *totED_OCRIn0;
													G4double temp4= *totED_OCRIn1;
													G4double temp5=(temp3+temp4)/2.;
													G4double positiony = Pwidthy/2. + i*Pwidthy - Pwidthy*fNy/2;
													anaManager->FillH1(14,positiony,temp5);

									}
					}

	}

	timer->Stop();
	G4cout << "The simulation took: " << timer->GetRealElapsed() << " s to run (real time)" << G4endl;

	// save histograms //
	anaManager->Write();
 	anaManager->CloseFile();
	// complete cleanup
	delete G4AnalysisManager::Instance();
  */
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
