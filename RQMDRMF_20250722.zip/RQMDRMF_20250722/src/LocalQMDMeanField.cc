//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// 081120 Add Update by T. Koi
// 211215 Add Skyrme and RMF models by A.Haga.
// 240620 openmp parallelization (A. Haga)

#include <omp.h> // for openmp
#include <map>
#include <algorithm>
#include <numeric>

#include <cmath>
#include <CLHEP/Random/Stat.h>

#include "LocalQMDMeanField.hh"
#include "LocalQMDParameters.hh"
#include "G4Exp.hh"
#include "G4Pow.hh"
#include "G4PhysicalConstants.hh"
#include "Randomize.hh"

#include "G4IonTable.hh"

LocalQMDMeanField::LocalQMDMeanField()
: rclds ( 4.0 )    // distance for cluster judgement // do not use (A.H.)
, epsx ( -20.0 )   // gauss term      
, epscl ( 0.0001 ) // coulomb term     
, irelcr ( 1 )
, ep_s ( 0.0 )    // factor for derivative term (A.H.)
, ep_v ( 0.0 )    // factor for derivative term (A.H.)
, ep_r ( 0.0 )    // factor for derivative term (A.H.)
, ep ( 0.0 )    // factor for derivative term (A.H.)
{

   LocalQMDParameters* parameters = LocalQMDParameters::GetInstance();
   wl = parameters->Get_wl();
   cl = parameters->Get_cl();
   rho0 = parameters->Get_rho0(); 
   hbc = parameters->Get_hbc();
   gamm = parameters->Get_gamm();
   eta = parameters->Get_eta(); // Skyrme-QMD
   kappas = parameters->Get_kappas(); // Skyrme-QMD

   cpw = parameters->Get_cpw();
   cph = parameters->Get_cph();
   cpc = parameters->Get_cpc();

   c0 = parameters->Get_c0();
   c3 = parameters->Get_c3();
   cs = parameters->Get_cs();
   g0 = parameters->Get_g0(); // Skyrme-QMD
   g0iso = parameters->Get_g0iso(); // Skyrme-QMD
   gtau0 = parameters->Get_gtau0(); // Skyrme-QMD
    
    // RMF-QMD
    cutoff_s = parameters->Get_cutoff_s();
    g_sigma = parameters->Get_g_sigma();
    g_sigma2 = parameters->Get_g_sigma2();
    g_sigma3 = parameters->Get_g_sigma3();
    g_sigma_bar = parameters->Get_g_sigma_bar();
    m_sigma = parameters->Get_m_sigma();
    cutoff_v = parameters->Get_cutoff_v();
    g_omega = parameters->Get_g_omega();
    g_omega_bar = parameters->Get_g_omega_bar();
    m_omega = parameters->Get_m_omega();
    cutoff_r = parameters->Get_cutoff_r();
    g_rho = parameters->Get_g_rho();
    g_rho_bar = parameters->Get_g_rho_bar();
    m_rho = parameters->Get_m_rho();
    
    cdp = parameters->Get_cdp();
    RMF = parameters->Get_RMF();
    
    //isoR ver. yoshi 20230103 
    // as a sensitive parameter
    //cluster_radius = parameters->Get_cluster_radius();
    cluster_radius_pp = parameters->Get_cluster_radius_pp();
    cluster_radius_pn = parameters->Get_cluster_radius_pn();
    cluster_radius_nn = parameters->Get_cluster_radius_nn();
    
// distance
   c0w = 1.0/4.0/wl;
   c0w2 = 1.0/2.0/wl;
   //c3w = 1.0/4.0/wl; //no need
   c0sw = std::sqrt( c0w );
   clw = 2.0 / std::sqrt ( 4.0 * pi * wl );

// graduate
   c0g = - c0 / ( 2.0 * wl );
   c3g = - c3 / ( 4.0 * wl ) * gamm;
   csg = - cs / ( 2.0 * wl );
   pag = gamm - 1;
   pag_tau = eta - 1; // Skyrme-QMD
   cg0 = - g0 / ( 2.0 * wl );  // Skyrme-QMD
   cgtau0 = - gtau0 / ( 4.0 * wl ) * eta;  // Skyrme-QMD

   omp_num = 12; // openmp
   system = NULL; // will be set through SetSystem method
}

LocalQMDMeanField::~LocalQMDMeanField()
{
   ;
}



void LocalQMDMeanField::SetSystem ( LocalQMDSystem* aSystem )
{ 

   //std::cout << "QMDMeanField SetSystem" << std::endl;

   system = aSystem; 

   G4int n = system->GetTotalNumberOfParticipant();
  
   pp2.clear();
   rr2.clear();
   rbij.clear();
   rha.clear();
   rhe.clear();
   rhc.clear();
    rha2.clear();
    
   rr2.resize( n );
   pp2.resize( n );
   rbij.resize( n );
   rha.resize( n );
   rhe.resize( n );
   rhc.resize( n );
    rha2.resize( n );
//#pragma omp parallel for
   for ( int i = 0 ; i < n ; ++i )
   {
      rr2[i].resize( n );
      pp2[i].resize( n );
      rbij[i].resize( n );
      rha[i].resize( n );
      rhe[i].resize( n );
      rhc[i].resize( n );
       rha2[i].resize( n );
   }
    
   ffr.clear();
   ffp.clear();
   rh3d.clear();
    rh3d_tau.clear(); // Skyrme-QMD
    sigma.clear(); //RMF-QMD
    scalar_potential.clear(); //RMF-QMD
    vector_potential.clear(); //RMF-QMD
    coulomb_potential.clear();
    
   ffr.resize(n);
   ffp.resize(n);
   rh3d.resize(n);
    rh3d_tau.resize(n); // Skyrme-QMD
    sigma.resize(n); //RMF-QMD
    scalar_potential.resize(n); //RMF-QMD
    vector_potential.resize(n); //RMF-QMD
    coulomb_potential.resize(n);
    
   Cal2BodyQuantities();

}

void LocalQMDMeanField::SetNucleus ( LocalQMDNucleus* aNucleus )
{

   //std::cout << "QMDMeanField SetNucleus" << std::endl;

   SetSystem( aNucleus );

   //G4double totalPotential = GetTotalPotential(); 
   //aNucleus->SetTotalPotential( totalPotential );

   aNucleus->CalEnergyAndAngularMomentumInCM();

}



void LocalQMDMeanField::Cal2BodyQuantities()
{
    G4double totale = 0.0;
    G4int n = system->GetTotalNumberOfParticipant();
    if ( n < 2 ) return;
    //G4int istart = 1;
    G4int istart = 0;
    G4int i;
#pragma omp parallel for private(i) num_threads(omp_num)
    for ( G4int j = istart ; j < n ; ++j )
    {
        G4int jcharge = system->GetParticipant(j)->GetChargeInUnitOfEplus();
        G4int jbry = system->GetParticipant(j)->GetBaryonNumber();
       
        G4ThreeVector rj = system->GetParticipant( j )->GetPosition();
        G4LorentzVector p4j = system->GetParticipant( j )->Get4Momentum();
        G4ThreeVector Rs = G4ThreeVector(0,0,0);
        G4double rhos = 0.0;
        G4double rhos_md = 0.0;
        G4LorentzVector rhov( G4ThreeVector(0,0,0) , 0 );
        G4LorentzVector rhov_md( G4ThreeVector(0,0,0) , 0 );
        G4LorentzVector rhoA( G4ThreeVector(0,0,0) , 0 );
        G4LorentzVector rhorho( G4ThreeVector(0,0,0) , 0 );
        G4LorentzVector omega( G4ThreeVector(0,0,0) , 0 );
        // if(p4j.m() < 0.000000001) continue; //new mf yoshi.
	// nucleons, pions(mesons), electrons, gamma
        //G4int iend = j;
        G4int iend = n;
        for ( i = 0 ; i < iend ; ++i )
        {
            if (i == j) continue;
            G4int icharge = system->GetParticipant(i)->GetChargeInUnitOfEplus();
            G4int ibry = system->GetParticipant(i)->GetBaryonNumber();
          
            G4ThreeVector ri = system->GetParticipant( i )->GetPosition();
            G4LorentzVector p4i = system->GetParticipant( i )->Get4Momentum();
            
            //if(p4i.m() < 0.000000001) continue; //new mf yoshi.
	    // nucleons, pions(mesons), electrons, gamma
            G4ThreeVector rij = ri - rj;
            G4ThreeVector pij = (p4i - p4j).v();
            //G4LorentzVector p4ij = p4i - p4j;
            
            //pij = G4ThreeVector(0,0,0.1);
            //G4LorentzVector p4ij_m( p4i.v() - p4j.v() , std::sqrt((p4i.v() - p4j.v())*(p4i.v() - p4j.v())+p4i.m()*p4i.m()) );
            //G4cout << "test " << i << j << " " << p4ij_m/p4ij_m.e() << G4endl;
            //exit(0);
            
            G4ThreeVector bij = ( p4i + p4j ).boostVector();
            G4double gammaij = ( p4i + p4j ).gamma();

            G4double eij = ( p4i + p4j ).e();

            G4double rbrb = rij*bij;
            //         G4double bij2 = bij*bij;
            G4double rij2 = rij*rij;
            G4double pij2 = pij*pij;

            rbrb = irelcr * rbrb;
            G4double  gamma2_ij = gammaij*gammaij;


            rr2[i][j] = rij2 + gamma2_ij * rbrb*rbrb;
            rr2[j][i] = rr2[i][j];

            rbij[i][j] = gamma2_ij * rbrb;
            rbij[j][i] = - rbij[i][j];

            pp2[i][j] = pij2
                   + irelcr * ( - G4Pow::GetInstance()->powN ( p4i.e() - p4j.e() , 2 )
                   + gamma2_ij * G4Pow::GetInstance()->powN ( ( ( p4i.m2() - p4j.m2() ) / eij ) , 2 ) );


            pp2[j][i] = pp2[i][j];

            //       Gauss term

            G4double expa1 = - rr2[i][j] * c0w;
            G4double expa2 = - rr2[i][j] * c0w2;

            G4double rh1;
            G4double rh2;
            if ( expa1 > epsx )
            {
                rh1 = G4Exp( expa1 );
                rh2 = G4Exp( expa2 );
            }
            else
            {
                rh1 = 0.0;
                rh2 = 0.0;
            }

            rha[i][j] = gammaij*ibry*jbry*rh1;
            rha[j][i] = rha[i][j];
            rha2[i][j] = gammaij*ibry*jbry*rh2;
            rha2[j][i] = rha2[i][j];
            //       Coulomb terms

            G4double rrs2 = rr2[i][j] + epscl;
            G4double rrs = std::sqrt ( rrs2 );

            G4double xerf = 0.0;
            // T. K. add this protection. 5.8 is good enough for double
            if ( rrs*c0sw < 5.8 ) {
            //erf = G4RandStat::erf ( rrs*c0sw );
            //Restore to CLHEP for avoiding compilation error in MT
            //erf = CLHEP::HepStat::erf ( rrs*c0sw );
            //Use cmath 
//#if defined WIN32-VC
//                xerf = CLHEP::HepStat::erf ( rrs*c0sw );
//#else
                xerf = erf ( rrs*c0sw );
//#endif
            } else {
                xerf = 1.0;
            }

            G4double erfij = xerf/rrs;

            rhe[i][j] = gammaij*icharge*jcharge * erfij;//RMF-QMD, gammaij is multiplied, new MF yoshi.

            rhe[j][i] = rhe[i][j];

            rhc[i][j] = gammaij*icharge*jcharge * ( - erfij + clw * rh1 ) / rrs2;//RMF-QMD, gammaij is multiplied, new MF yoshi.

            rhc[j][i] = rhc[i][j];
          
            G4double fi = p4i.m()/p4i.e();
            //G4ThreeVector bij_m = pij/std::sqrt ( pij2+p4i.m()*p4i.m() );
            G4double fsij = 3.0/(2*wl) - rr2[j][i]/(2*wl)/(2*wl);
            
            rhos += rha[j][i] * cdp * fi * jbry * ibry * (1 - ep_s * fsij/m_sigma/m_sigma);
            rhos_md += rha[j][i] * cdp * fi * jbry * ibry/(1.-pp2[i][j]*pp2[i][j]/(cutoff_s*cutoff_s));
          
            rhov += rha[j][i] * cdp * p4i/p4i.e() * jbry * ibry * (1 - ep_v * fsij/m_omega/m_omega);
            rhov_md += rha[j][i] * cdp * p4i/p4i.e() * jbry * ibry /(1.-pp2[i][j]*pp2[i][j]/(cutoff_v*cutoff_v));
            //G4cout << i << j << "rhov " << rhov << G4endl;
            rhoA += rhe[j][i] * p4i/p4i.e();
            //rhorho += rha[j][i] * p4j/p4j.e() * cdp * jnuc * inuc
            //* ( 1. - 2. * std::abs( jcharge - icharge ) );
            rhorho += rha[j][i] * p4i/p4i.e() * cdp * jbry * ibry * (1 - ep_r * fsij/m_rho/m_rho)
            * (2.* jcharge - 1) * (2.* icharge - 1);

            Rs += -rij*fi*gammaij*ibry*jbry*rh2/std::sqrt ( 2.0 * pi * wl )/(2.0 * pi * wl);
            //G4cout << "rhos " << rhos << " Rs " << Rs <<G4endl;
        }  // i
       
        
        
        // For scalar potential
        G4double Vsj = Rs*Rs*g_sigma*g_sigma/m_sigma/m_sigma/m_sigma/m_sigma/wl;
        sigma[j] = g_sigma * rhos/(m_sigma * m_sigma); // initial value
        //G4cout << "rhos " << g_sigma * rhos << " Vsj " << ep*g_sigma2*Vsj <<G4endl;
        G4double sigma1 = sigma[j]*1.1;// initial value
        G4int n_max = 100;
        for  ( G4int jj = 0 ; jj < n_max ; ++jj )
        {
            sigma[j] = (g_sigma * rhos - ep*g_sigma2*Vsj)/((m_sigma * m_sigma)+g_sigma2 * sigma[j] + g_sigma3 * sigma[j] * sigma[j] + ep*3*g_sigma3*Vsj);
            //sigma[j] = ( g_sigma * rhos )/( m_sigma * m_sigma + g_sigma2 * sigma[j] + g_sigma3 * sigma[j] * sigma[j] );
            sigma[j] = 0.5*(sigma[j]+sigma1);
            //G4cout << "sigma[j] " << sigma[j] << " " << g_sigma * rhos <<G4endl;
            if (abs(sigma[j]-sigma1)/abs(sigma[j]+0.00000001) < 0.00001) break;
            sigma1 = sigma[j];
        }
        //exit(0);
        scalar_potential[j] = (g_sigma * sigma[j] + (g_sigma_bar*g_sigma_bar/(m_sigma * m_sigma)) * rhos_md)*hbc; // GeV
        // For vector potential
        //G4cout << "test " << j << " " << rhov << G4endl;
        omega = g_omega * rhov/(m_omega * m_omega);
        vector_potential[j] = (g_omega * omega
        + (g_omega_bar*g_omega_bar/(m_omega * m_omega)) * rhov_md
        //+ cl * rhoA * 2/hbc
        + (g_rho/2 * g_rho/2 /(m_rho * m_rho)) * rhorho)*hbc;
	////
	// Coulmb potentianl is treated independently.
	// Electron and charged pions feel the Coulmb potential only.
	// Gamma and pi0 feel no potential.
	////
	coulomb_potential[j] = cl * rhoA.e() * 2;
    //+ (g_rho/2 * g_rho/2 /(m_rho * m_rho)) * rhorho;
    //+ cs * rhorho * 2/cdp/hbc;
    //G4cout << "rhov " << rhov << " pote " << potential*hbc*cdp <<G4endl;
    //exit(0);
   }  // j
    //G4cout << "totalenergy " << totale*1000/n <<G4endl;
}



void LocalQMDMeanField::Cal2BodyQuantities( G4int i )
{
  // do not use for RMF-QMD
   //std::cout << "Cal2BodyQuantities " << i << std::endl;

   G4ThreeVector ri = system->GetParticipant( i )->GetPosition();  
   G4LorentzVector p4i = system->GetParticipant( i )->Get4Momentum();  
   G4int n = system->GetTotalNumberOfParticipant();

    if(p4i.m()<0.000000001) return; //new MF yoshi.
   for ( G4int j = 0 ; j < n ; ++j )
   {
      if ( j == i ) continue; 

      G4ThreeVector rj = system->GetParticipant( j )->GetPosition();  
      G4LorentzVector p4j = system->GetParticipant( j )->Get4Momentum();  

        if(p4j.m()<0.000000001) continue; // new MF yoshi.
         G4ThreeVector rij = ri - rj;
         G4ThreeVector pij = (p4i - p4j).v();
         G4LorentzVector p4ij = p4i - p4j;
         G4ThreeVector bij = ( p4i + p4j ).boostVector();
         G4double gammaij = ( p4i + p4j ).gamma();

         G4double eij = ( p4i + p4j ).e();

         G4double rbrb = rij*bij;
//         G4double bij2 = bij*bij;
         G4double rij2 = rij*rij;
         G4double pij2 = pij*pij;

         rbrb = irelcr * rbrb;
         G4double  gamma2_ij = gammaij*gammaij;



      rr2[i][j] = rij2 + gamma2_ij * rbrb*rbrb;
      rr2[j][i] = rr2[i][j];

      rbij[i][j] = gamma2_ij * rbrb;
      rbij[j][i] = - rbij[i][j];
      
      pp2[i][j] = pij2
                + irelcr * ( - G4Pow::GetInstance()->powN ( p4i.e() - p4j.e() , 2 )
                + gamma2_ij * G4Pow::GetInstance()->powN ( ( ( p4i.m2() - p4j.m2() ) / eij ) , 2 ) );

      pp2[j][i] = pp2[i][j];

//    Gauss term

      G4double expa1 = - rr2[i][j] * c0w;  

      G4double rh1;
      if ( expa1 > epsx ) 
      {
         rh1 = G4Exp( expa1 );
      }
      else 
      {
         rh1 = 0.0;  
      } 

      G4int ibry = system->GetParticipant(i)->GetBaryonNumber();  
      G4int jbry = system->GetParticipant(j)->GetBaryonNumber();  


      //rha[i][j] = ibry*jbry*rh1;
      rha[i][j] = gammaij*ibry*jbry*rh1; //new MF yoshi
      //if(RMF) rha[i][j] = gammaij*ibry*jbry*rh1; //RMF-QMD
      rha[j][i] = rha[i][j]; 

//    Coulomb terms

      G4double rrs2 = rr2[i][j] + epscl; 
      G4double rrs = std::sqrt ( rrs2 ); 

      G4int icharge = system->GetParticipant(i)->GetChargeInUnitOfEplus();
      G4int jcharge = system->GetParticipant(j)->GetChargeInUnitOfEplus();

      G4double xerf = 0.0;
      // T. K. add this protection. 5.8 is good enough for double
      if ( rrs*c0sw < 5.8 ) {
         //xerf = G4RandStat::erf ( rrs*c0sw );
         //Use cmath 
	//#if defined WIN32-VC
	//xerf = CLHEP::HepStat::erf ( rrs*c0sw );
	//#else
         xerf = erf ( rrs*c0sw );
	 //#endif
      } else {
         xerf = 1.0;
      }

      G4double erfij = xerf/rrs; 
      

      //rhe[i][j] = icharge*jcharge * erfij;
      rhe[i][j] = gammaij*icharge*jcharge * erfij; // new MF yoshi

      rhe[j][i] = rhe[i][j]; 

//    G4double clw;

      //rhc[i][j] = icharge*jcharge * ( - erfij + clw * rh1 ) / rrs2;
      rhc[i][j] = gammaij*icharge*jcharge * ( - erfij + clw * rh1 ) / rrs2; //new MF yoshi

      rhc[j][i] = rhc[i][j]; 

   }
}



void LocalQMDMeanField::CalGraduate()
{
  G4int n = system->GetTotalNumberOfParticipant();
   ffr.resize( n );
   ffp.resize( n );

   G4double CS_bar = g_sigma_bar*g_sigma_bar/(m_sigma*m_sigma);
   G4int j;
#pragma omp parallel for private (j)  num_threads(omp_num)
   for ( G4int i = 0 ; i < n ; ++i )
     {
            
       G4ThreeVector ri = system->GetParticipant( i )->GetPosition();
       G4LorentzVector p4i = system->GetParticipant( i )->Get4Momentum();
            
       G4ThreeVector betai = p4i.v()/p4i.e();
            
       //    RMF-QMD
       G4LorentzVector V4i = vector_potential[i];
       G4double si = scalar_potential[i];
            
       G4ThreeVector p3i_star = p4i.v() - V4i.v();
       G4double mi_star = p4i.m() - si;
       G4double pi_zero_star = std::sqrt( p3i_star*p3i_star + mi_star*mi_star);
        
       G4double fi = p4i.m()/p4i.e();
       G4double fi_star = mi_star/pi_zero_star;
       G4double Di = (g_sigma*g_sigma)/(m_sigma*m_sigma+2*g_sigma2*sigma[i]+3*g_sigma3*sigma[i]*sigma[i]); // [fm^2]
       G4ThreeVector vi_star = p3i_star/pi_zero_star;
        
       G4ThreeVector dfi = -fi*betai/p4i.e();
        
       G4ThreeVector dfi_star = -fi_star*vi_star/pi_zero_star;
  
       G4double Ai = m_sigma*m_sigma+g_sigma2*sigma[i]+g_sigma3*sigma[i]*sigma[i];
       G4double Gi = sigma[i]*fi/Ai/Ai*(
                     (-1.0/3.0*g_sigma2
                      -3.0/4.0*g_sigma3*sigma[i])*Ai
                     +(1.0/6.0*g_sigma2*sigma[i]
                       +1.0/4.0*g_sigma3*sigma[i]*sigma[i])*(g_sigma2+2*g_sigma3*sigma[i]));
            
       G4double Gi_star = sigma[i]*fi_star/Ai/Ai*(
                     (-1.0/3.0*g_sigma2
                      -3.0/4.0*g_sigma3*sigma[i])*Ai
                     +(1.0/6.0*g_sigma2*sigma[i]
                       +1.0/4.0*g_sigma3*sigma[i]*sigma[i])*(g_sigma2+2*g_sigma3*sigma[i]));
            
       //G4double Fi = fi_star + si/pi_zero_star - si/pi_zero_star*fi_star*fi_star - V4i.v()*vi_star*fi_star/pi_zero_star;
       //G4double Hi = 1 - si/pi_zero_star*fi_star - V4i.v()*vi_star/pi_zero_star;
            
       G4ThreeVector delbetai = 0.5*betai - vi_star;
            
       ffr[i] = vi_star + 0.5*dfi*si + 0.5*(V4i.v()-(V4i.v()*betai)*betai)/p4i.e() + (-1.0/6.0*g_sigma2*sigma[i]-1.0/4.0*g_sigma3*sigma[i]*sigma[i])*dfi*si/Ai;
       ffp[i] = G4ThreeVector( 0.0 );
       //if(p4i.m()<0.000000001) continue; //new MF yoshi.
       //std::cout << "ffr[i] " << ffr[i] << "betai " << betai << std::endl;
       //std::cout << "ffr[i] " << 0.5*fi*si/p4i.e() << " " << si/p4i.e() << std::endl;
       for ( j = 0 ; j < n ; ++j )
	 {  
	   G4ThreeVector rj = system->GetParticipant( j )->GetPosition();
	   G4LorentzVector p4j = system->GetParticipant( j )->Get4Momentum();
            
	   //if(p4j.m()<0.000000001) continue; // new MF yoshi
	   G4ThreeVector betaj = p4j.v()/p4j.e();
            
	   G4double eij = p4i.e() + p4j.e();
            
	   G4int icharge = system->GetParticipant(i)->GetChargeInUnitOfEplus();
	   G4int jcharge = system->GetParticipant(j)->GetChargeInUnitOfEplus();
            
	   G4int inuc = system->GetParticipant(i)->GetNuc();
	   G4int jnuc = system->GetParticipant(j)->GetNuc();
            
	   //G4LorentzVector V4j = GetVectorPotential( j );
	   //G4double sj = GetScalarPotential( j );
	   G4LorentzVector V4j = vector_potential[j];
	   G4double sj = scalar_potential[j];
	   G4ThreeVector p3j_star = p4j.v() - V4j.v();
	   G4double mj_star = p4j.m() - sj;
	   G4double pj_zero_star = std::sqrt( p3j_star*p3j_star + mj_star*mj_star);
	   //pj_zero_star += 0.5*(V4j.e()+sj*mj_star/pj_zero_star+V4j.v()*p3j_star/pj_zero_star);
	   //G4double pj_zero = pj_zero_star + p4j.e();
            
	   G4double fj = p4j.m()/p4j.e();
	   G4ThreeVector dfj = -fj*betaj/p4j.e();
                
	   //G4ThreeVector fijb = -0.5*fij*p4ji.v()/p4ji.e()/p4ji.e();
	   G4double fj_star = mj_star/pj_zero_star;
	   G4double Dj = (g_sigma*g_sigma)/(m_sigma*m_sigma+2*g_sigma2*sigma[j]+3*g_sigma3*sigma[j]*sigma[j]);
	   G4ThreeVector vj_star = p3j_star/pj_zero_star;
	   G4ThreeVector dfj_star = -fj_star*vj_star/pj_zero_star;

	   //G4double ratioj = sj*fj/(m_sigma*m_sigma + g_sigma2*sigma[j] + g_sigma3*sigma[j]*sigma[j])/(sigma[j]*sigma[j]);
	   //G4double Gj = ratioj*g_sigma*(0.5*g_sigma2*sigma[j]*sigma[j]+g_sigma3*sigma[j]*sigma[j]*sigma[j])/(m_sigma*m_sigma+2*g_sigma2*sigma[j]+3*g_sigma3*sigma[j]*sigma[j]);
	   G4double Aj = m_sigma*m_sigma+g_sigma2*sigma[j]+g_sigma3*sigma[j]*sigma[j];
	   //G4double Gj = g_sigma/(m_sigma*m_sigma+2*g_sigma2*sigma[j]+3*g_sigma3*sigma[j]*sigma[j]);
	   G4double Gj = sigma[j]*fj/Aj/Aj*(
                         (-1.0/3.0*g_sigma2
                          -3.0/4.0*g_sigma3*sigma[j])*Aj
                         +(1.0/6.0*g_sigma2*sigma[j]
                           +1.0/4.0*g_sigma3*sigma[j]*sigma[j])*(g_sigma2+2*g_sigma3*sigma[j]));
	   G4double Gj_star = sigma[j]*fj_star/Aj/Aj*(
                         (-1.0/3.0*g_sigma2
                          -3.0/4.0*g_sigma3*sigma[j])*Aj
                         +(1.0/6.0*g_sigma2*sigma[j]
                           +1.0/4.0*g_sigma3*sigma[j]*sigma[j])*(g_sigma2+2*g_sigma3*sigma[j]));
                
	   G4ThreeVector delbetaj = 0.5*betaj - vj_star;

	   //G4double Fj = fj_star + sj/pj_zero_star - sj/pj_zero_star*fj_star*fj_star - V4j.v()*vj_star*fj_star/pj_zero_star;
	   //G4double Hj = 1 - sj/pj_zero_star*fj_star - V4j.v()*vj_star/pj_zero_star;
	   //G4double CS_bar = g_sigma_bar*g_sigma_bar/(m_sigma*m_sigma);
	   G4double CW = inuc*jnuc*g_omega*g_omega/(m_omega*m_omega);
	   G4double CW_bar = inuc*jnuc*g_omega_bar*g_omega_bar/(m_omega*m_omega);
	   G4double CR = inuc*jnuc*(g_rho/2)*(g_rho/2)/(m_rho*m_rho);
	   G4double CR_bar = inuc*jnuc*(g_rho_bar/2)*(g_rho_bar/2)/(m_rho*m_rho);
            
	   //G4double sfacj = fj_star + sj/pj_zero_star*(vj_star*vj_star) - V4j.v()*vj_star/pj_zero_star*fj_star;
	   //G4ThreeVector vfacj = vj_star + V4j.v()/pj_zero_star*fj_star*fj_star - fj_star*sj/pj_zero_star*vj_star;
            
	   G4double Fijs = 1.0/(1.0+pp2[i][j]/(cutoff_s*cutoff_s));
	   G4double Fijw = 1.0/(1.0+pp2[i][j]/(cutoff_v*cutoff_v));
	   G4double Fijr = 1.0/(1.0+pp2[i][j]/(cutoff_r*cutoff_r));
            
	   G4double gammaij = ( p4i + p4j ).gamma();
	   G4double gamma2ij = gammaij*gammaij;
	   G4ThreeVector betaij =  ( p4i + p4j ).v()/eij;
	   //G4ThreeVector bij = ( p4i + p4j ).boostVector();
	   G4ThreeVector del_PT2ij = 2*(p4j.e()/p4i.e() * p4i.v() - p4j.v()) + 2*gamma2ij*gamma2ij/eij * (p4i.m()*p4i.m()-p4j.m()*p4j.m())*(p4i.m()*p4i.m()-p4j.m()*p4j.m())/(eij*eij)*(betaij-p4i.v()/p4i.e());
            
	   G4ThreeVector del_Fijs = Fijs*Fijs * del_PT2ij/(cutoff_s*cutoff_s);
	   G4ThreeVector del_Fijw = Fijw*Fijw * del_PT2ij/(cutoff_v*cutoff_v);
	   G4ThreeVector del_Fijr = Fijr*Fijr * del_PT2ij/(cutoff_r*cutoff_r);
            
	   G4double Dsj = inuc*jnuc*(Dj + CS_bar*Fijs);
	   G4double Dsi = inuc*jnuc*(Di + CS_bar*Fijs);
	   G4double Dw = (CW + CW_bar*Fijw);
	   G4double Drho = (CR + CR_bar*Fijw);
            
                
	   G4double fsij = 3.0/(2*wl) - rr2[j][i]/(2*wl)/(2*wl);
                
	   G4double ccpp = 0.0;
	   G4ThreeVector res = G4ThreeVector( 0.0 );

	   ccpp = (((0.5*fj-fj_star+Gj)*Dsj*fi + (0.5*fi-fi_star+Gi)*Dsi*fj) * (1 - ep_s * fsij/(m_sigma*m_sigma))
                                 + Dw * (1 - ep_v * fsij/(m_omega*m_omega))) * rha[i][j] * cdp;
	   ccpp += (delbetaj*betai)* Dw * (1 - ep_v * fsij/(m_omega*m_omega)) * rha[i][j] * cdp;
	   ccpp += (delbetai*betaj)* Dw * (1 - ep_v * fsij/(m_omega*m_omega)) * rha[i][j] * cdp;
	   ccpp += Drho * (1 - ep_r * fsij/(m_rho*m_rho)) * rha[i][j] * cdp * (2.* jcharge - 1) * (2.* icharge - 1);
	   ccpp += (delbetaj*betai)* Drho * (1 - ep_r * fsij/(m_rho*m_rho)) * rha[i][j] * cdp * (2.* jcharge - 1) * (2.* icharge - 1);
	   ccpp += (delbetai*betaj)* Drho * (1 - ep_r * fsij/(m_rho*m_rho)) * rha[i][j] * cdp * (2.* jcharge - 1) * (2.* icharge - 1);
                                
	   res = (0.5*fj-fj_star+Gj)* (1 - ep_s * fsij/(m_sigma*m_sigma))*Dsj*dfi*rha[i][j] * cdp;
	   res +=  Dw * (1 - ep_v * fsij/(m_omega*m_omega)) * (delbetaj-(delbetaj*betai)*betai)/p4i.e() * rha[i][j] * cdp;
	   res +=  Drho * (1 - ep_r * fsij/(m_rho*m_rho)) * (delbetaj-(delbetaj*betai)*betai)/p4i.e() * rha[i][j] * cdp * (2.* jcharge - 1) * (2.* icharge - 1);
                
	   // MD term
	   res += (0.5*fj-fj_star+Gj)* (1 - ep_s * fsij/(m_sigma*m_sigma))*Dsj*fi*del_Fijs*rha[i][j] * cdp;
	   res += CW_bar * del_Fijw * rha[i][j] * cdp;
                
	   G4double grbb = - rbij[j][i];
                
	   //G4double ccrr = 0.0;
            
	   G4ThreeVector rij = ri - rj;
	   G4ThreeVector cij = betaij - betai;
	   G4double dbp = betaij*betaij;
	   G4ThreeVector dij = (betaij-dbp*betai)/eij;
	   //if(i==j) dij = dij*0.0;
            
	   G4ThreeVector dp_rhoij = (gamma2ij * dij  -c0w *  (2 * grbb / eij) * ( rij + grbb*cij )) ; // GeV^-1
	   G4ThreeVector dp_Rij = 2 * grbb / eij * ( rij + grbb*cij ) ; // fm^2 GeV^-1
	   //G4ThreeVector dp_rhoij1 = ( - c0w * (2 * grbb / eij) * ( rij + grbb*cij )) ; // GeV^-1
	   //G4ThreeVector dp_rhoij2 = gamma2ij * dij ; // GeV^-1
	   G4ThreeVector dr_rhoij = -c0w * 2 * ( rij + grbb*betaij ) ; // fm^-1
	   //G4ThreeVector dr_Rij = 2 * ( rij + grbb*betaij ) ; // fm
                
	   G4double ccrr_c = cl * rhc[j][i]/hbc; //new MF yoshi
	   G4double ccrr_cc = cl * rhe[j][i] * 2/hbc; // new MF yoshi
	   G4ThreeVector D_1 = gamma2ij * dij;
	   G4ThreeVector D_2 = c0w * (2 * grbb / eij) * ( rij + grbb*cij );
	   G4ThreeVector D_3 = c0w * 2 * ( rij + grbb*betaij );
                
	   ffr[i] = ffr[i] + (ccpp * dp_rhoij + res + ccrr_c * D_2/c0w + ccrr_cc * D_1) * hbc;
	   //ffp[i] = ffp[i] - (ccpp * dr_rhoij + ccrr * dr_Rij + ccrr_c * D_3/c0w) * hbc;
	   ffp[i] = ffp[i] - (ccpp * dr_rhoij + ccrr_c * D_3/c0w) * hbc;
	 }
     }
}

G4double LocalQMDMeanField::GetPotential( G4int i )
{
    // do not use in RMF-QMD
   G4int n = system->GetTotalNumberOfParticipant();

   G4double rhoa = 0.0;
   G4double rho3 = 0.0;
    G4double fsij_rhoa = 0.0; // Skyrme-QMD
//    G4double fsij_rhos = 0.0; // Skyrme-QMD
    G4double rho3_tau = 0.0; // Skyrme-QMD
   G4double rhos = 0.0;
   G4double rhoc = 0.0;


   G4int icharge = system->GetParticipant(i)->GetChargeInUnitOfEplus();
   G4int inuc = system->GetParticipant(i)->GetNuc();

   for ( G4int j = 0 ; j < n ; ++j )
   {
      G4int jcharge = system->GetParticipant(j)->GetChargeInUnitOfEplus();
      G4int jnuc = system->GetParticipant(j)->GetNuc();
       
       G4double fsij = 3.0/(2*wl) - rr2[j][i]/(2*wl)/(2*wl); // Add for Skyrme-QMD

      rhoa += rha[j][i];
       fsij_rhoa += fsij * rha[j][i]; // Skyrme-QMD
      rhoc += rhe[j][i];
      rhos += rha[j][i] * jnuc * inuc
                * ( 1. - 2. * std::abs( jcharge - icharge ) )  // Skyrme-QMD
                * (1. - kappas * fsij);  // Skyrme-QMD
//       fsij_rhos += fsij * rha[j][i] * jnuc * inuc
//       * ( 1. - 2. * std::abs( jcharge - icharge ) )  // Skyrme-QMD
//       * (1. - kappas * fsij);  // Skyrme-QMD
   }

   rho3 = G4Pow::GetInstance()->powA ( rhoa , gamm );
    rho3_tau = G4Pow::GetInstance()->powA ( rhoa , eta );

   G4double potential = c0 * rhoa
                      + c3 * rho3
                      + g0 * fsij_rhoa  // Skyrme-QMD
//                      + g0iso * fsij_rhos  // Skyrme-QMD
                      + gtau0 * rho3_tau  // Skyrme-QMD
                      + cs * rhos
                      + cl * rhoc;

   return potential;
}



G4double LocalQMDMeanField::GetTotalPotential()
{
  // do not use in RMF-QMD
   G4int n = system->GetTotalNumberOfParticipant();

   std::vector < G4double > rhoa ( n , 0.0 ); 
   std::vector < G4double > rho3 ( n , 0.0 );
    std::vector < G4double > rho3_tau ( n , 0.0 ); // Skyrme-QMD
//    std::vector < G4double > fsij_rhos ( n , 0.0 ); // Skyrme-QMD
    std::vector < G4double > fsij_rhoa ( n , 0.0 ); // Skyrme-QMD
   std::vector < G4double > rhos ( n , 0.0 ); 
   std::vector < G4double > rhoc ( n , 0.0 ); 
   

   for ( G4int i = 0 ; i < n ; ++i )
   {
      G4int icharge = system->GetParticipant(i)->GetChargeInUnitOfEplus();
      G4int inuc = system->GetParticipant(i)->GetNuc();

      for ( G4int j = 0 ; j < n ; ++j )
      {
         G4int jcharge = system->GetParticipant(j)->GetChargeInUnitOfEplus();
         G4int jnuc = system->GetParticipant(j)->GetNuc();
          
          G4double fsij = 3.0/(2*wl) - rr2[j][i]/(2*wl)/(2*wl); // Add for Skyrme-QMD

         rhoa[i] += rha[j][i];
          fsij_rhoa[i] += fsij * rha[j][i]; // Skyrme-QMD
         rhoc[i] += rhe[j][i];
         rhos[i] += rha[j][i] * jnuc * inuc 
//                   * ( 1 - 2 * std::abs ( jcharge - icharge ) );
          * ( 1. - 2. * std::abs( jcharge - icharge ) )  // Skyrme-QMD
          * (1. - kappas * fsij);  // Skyrme-QMD
//          fsij_rhos[i] += fsij * rha[j][i] * jnuc * inuc
//          * ( 1. - 2. * std::abs( jcharge - icharge ) )  // Skyrme-QMD
//          * (1. - kappas * fsij);  // Skyrme-QMD
      }

      rho3[i] = G4Pow::GetInstance()->powA ( rhoa[i] , gamm );
       rho3_tau[i] = G4Pow::GetInstance()->powA ( rhoa[i] , eta );
   }

   G4double potential = c0 * std::accumulate( rhoa.begin() , rhoa.end() , 0.0 ) 
                      + c3 * std::accumulate( rho3.begin() , rho3.end() , 0.0 )
                    + g0 * std::accumulate( fsij_rhoa.begin() , fsij_rhoa.end() , 0.0 )
//                    + g0iso * std::accumulate( fsij_rhos.begin() , fsij_rhos.end() , 0.0 )
                    + gtau0 * std::accumulate( rho3_tau.begin() , rho3_tau.end() , 0.0 )
                      + cs * std::accumulate( rhos.begin() , rhos.end() , 0.0 ) 
                      + cl * std::accumulate( rhoc.begin() , rhoc.end() , 0.0 );
    

    //std::cout << "g0 " << g0 * std::accumulate( fsij_rhoa.begin() , fsij_rhoa.end() , 0.0 ) << " gtau0 " << std::accumulate( rho3_tau.begin() , rho3_tau.end() , 0.0 ) << std::endl;
   return potential;

}

G4double LocalQMDMeanField::GetSingleEnergy( G4int i )
{
    
  //G4int n = system->GetTotalNumberOfParticipant();
  G4LorentzVector p4i = system->GetParticipant( i )->Get4Momentum();
        
  //G4int icharge = system->GetParticipant(i)->GetChargeInUnitOfEplus();
  //G4int inuc = system->GetParticipant(i)->GetNuc();
        
  //G4double c_energy = GetCoulombPotential(i);
  G4double c_energy = coulomb_potential[i];
        
  //if ( icharge == 0 && inuc == 0 ) return p4i.e();        
  //if ( inuc == 0 ) return (p4i.e() + cl * rhoA.e());
        
  G4LorentzVector vectorpote = vector_potential[i];
  G4double scalarpote = scalar_potential[i];
        
  G4double mi_star = p4i.m() - scalarpote;
  G4ThreeVector p3i_star = p4i.v() - vectorpote.v();
  G4double fi = p4i.m()/p4i.e();
  //G4double pi_zero_star = std::sqrt( p3i_star*p3i_star + mi_star*mi_star);
  //G4double fi_star = mi_star/pi_zero_star;
  G4double ener = std::sqrt( p3i_star*p3i_star + mi_star*mi_star);
  G4double ratio = scalarpote*fi/(m_sigma*m_sigma + g_sigma2*sigma[i] + g_sigma3*sigma[i]*sigma[i]);
  G4double energy = ener + vectorpote.e()/2 + scalarpote*fi/2 + vectorpote.v()*p4i.v()/p4i.e()/2 + c_energy/2 + (-1.0/6.0*g_sigma2*sigma[i]-1.0/4.0*g_sigma3*sigma[i]*sigma[i])*ratio;
  return energy;
}

G4double LocalQMDMeanField::GetTotalEnergy()
{
  G4double energy = 0.0;
  G4int n = system->GetTotalNumberOfParticipant();
//#pragma omp parallel for reduction(+:energy)  num_threads(12)
  for ( int i = 0 ; i < n ; ++i )
    {
      //G4double testenergy = GetSingleEnergy(i);
      //G4int icharge = system->GetParticipant(i)->GetChargeInUnitOfEplus();
      //G4int inuc = system->GetParticipant(i)->GetNuc(); // same as GetBaryonNumber()
      G4LorentzVector p4i = system->GetParticipant( i )->Get4Momentum();
      G4LorentzVector vectorpote = vector_potential[i];
      G4double scalarpote = scalar_potential[i];
      G4double mi_star = p4i.m() - scalarpote;
      G4ThreeVector p3i_star = p4i.v() - vectorpote.v();
      G4double ener = std::sqrt( p3i_star*p3i_star + mi_star*mi_star);
      G4double fi = p4i.m()/p4i.e();
      //G4double fi_star = mi_star/ener;
      //G4double c_energy = GetCoulombPotential(i);
      G4double c_energy = coulomb_potential[i];
      //if ( icharge == 0 && inuc == 0 )
      //{
      //    energy = p4i.e();
      //}
      //else
      //{
      G4double ratio = scalarpote*fi/(m_sigma*m_sigma + g_sigma2*sigma[i] + g_sigma3*sigma[i]*sigma[i]);
      energy += ener + vectorpote.e()/2 + scalarpote*fi/2 + vectorpote.v()*p4i.v()/p4i.e()/2 + c_energy/2 + (-1.0/6.0*g_sigma2*sigma[i]-1.0/4.0*g_sigma3*sigma[i]*sigma[i])*ratio;
      //energy += vectorpote.e()/2 + scalarpote*fi_star/2 + vectorpote.v()*p3i_star/ener/2;
      //if(ich == 0) energy += vectorpote.e()/2 + scalarpote*fi_star/2 + vectorpote.v()*p3i_star/ener/2;
      
      //if(ich == 1)
      //energy += vectorpote.e()/2 + scalarpote*fi/2 + vectorpote.v()*p4i.v()/p4i.e()/2;
      //energy = p4i.e();
      //energy += -scalarpote*fi/2 + vectorpote*p4i/p4i.e()/2;
      //energy += c_energy/2;

      //energy += (-1.0/6.0*g_sigma2*sigma[i]-1.0/4.0*g_sigma3*sigma[i]*sigma[i])*ratio;
      //}
      //totale += energy;
    }
        
  //totale += GetSelfPotential( );
  return energy;
}

G4double LocalQMDMeanField::calPauliBlockingFactor( G4int i )
{

   G4double pf = 0.0;
   G4int n = system->GetTotalNumberOfParticipant();
// i is supposed beyond total number of Participant()
   G4int icharge = system->GetParticipant(i)->GetChargeInUnitOfEplus();

   for ( G4int j = 0 ; j < n ; ++j )
   {

      G4int jcharge = system->GetParticipant(j)->GetChargeInUnitOfEplus();
      G4int jnuc = system->GetParticipant(j)->GetNuc();

      if ( jcharge == icharge && jnuc == 1 )
      {

/*
   G4cout << "Pauli i j " << i << " " << j << G4endl;
   G4cout << "Pauli icharge " << icharge << G4endl;
   G4cout << "Pauli jcharge " << jcharge << G4endl;
*/
         G4double expa = -rr2[i][j]*cpw;   


         if ( expa > epsx ) 
         {
            expa = expa - pp2[i][j]*cph;
/*
   G4cout << "Pauli cph " << cph << G4endl;
   G4cout << "Pauli pp2 " << pp2[i][j] << G4endl;
   G4cout << "Pauli expa " <<  expa  << G4endl;
   G4cout << "Pauli epsx " <<  epsx  << G4endl;
*/
            if ( expa > epsx ) 
            { 
//   std::cout << "Pauli phase " <<  pf  << std::endl;
               pf = pf + G4Exp ( expa );
            }
         }
      }
      
   }


   pf  = ( pf - 1.0 ) * cpc;

   //std::cout << "Pauli pf " << pf << std::endl;

   return pf;
    
}



G4bool LocalQMDMeanField::IsPauliBlocked( G4int i )
{
    G4bool result = false; 
    
    if ( system->GetParticipant( i )->GetNuc() == 1 )
    {
       G4double pf = calPauliBlockingFactor( i );
       G4double rand = G4UniformRand(); 
       if ( pf > rand ) result = true;
    }

    return result; 
}



void LocalQMDMeanField::DoPropagation( G4double dt )
{
 
   G4double cc2 = 1.0;
   G4double cc1 = 1.0 - cc2; 
   G4double cc3 = 1.0 / 2.0 / cc2; 

   G4double dt3 = dt * cc3;
   G4double dt1 = dt * ( cc1 - cc3 );
   G4double dt2 = dt * cc2;

   CalGraduate(); 

   G4int n = system->GetTotalNumberOfParticipant();

// 1st Step 

   std::vector< G4ThreeVector > f0r, f0p;
   f0r.resize( n );
   f0p.resize( n );

   for ( G4int i = 0 ; i < n ; ++i )
   {
      G4ThreeVector ri = system->GetParticipant( i )->GetPosition();  
      G4ThreeVector p3i = system->GetParticipant( i )->GetMomentum();  

      ri += dt3* ffr[i];
      p3i += dt3* ffp[i];

      f0r[i] = ffr[i];
      f0p[i] = ffp[i];
      
      system->GetParticipant( i )->SetPosition( ri );  
      system->GetParticipant( i )->SetMomentum( p3i );  

//    we do not need set total momentum by ourselvs
   }

// 2nd Step
   Cal2BodyQuantities(); 
   CalGraduate(); 

   for ( G4int i = 0 ; i < n ; ++i )
   {
      G4ThreeVector ri = system->GetParticipant( i )->GetPosition();  
      G4ThreeVector p3i = system->GetParticipant( i )->GetMomentum();  

      ri += dt1* f0r[i] + dt2* ffr[i];
      p3i += dt1* f0p[i] + dt2* ffp[i];

      system->GetParticipant( i )->SetPosition( ri );  
      system->GetParticipant( i )->SetMomentum( p3i );  

//    we do not need set total momentum by ourselvs
   }

   Cal2BodyQuantities(); 

}

/* Runge-Kutta 4th order
void LocalQMDMeanField::DoPropagation( G4double dt )
{
 
   G4double cc2 = 1.0;
   G4double cc1 = 1.0 - cc2; 
   G4double cc3 = 1.0 / 2.0 / cc2; 

   G4double dt3 = dt * cc3;
   G4double dt1 = dt * ( cc1 - cc3 );
   G4double dt2 = dt * cc2;

   CalGraduate(); 

   G4int n = system->GetTotalNumberOfParticipant();

// 1st Step 

   std::vector< G4ThreeVector > rkr0, rkp0;
   rkr0.resize( n );
   rkp0.resize( n );
   std::vector< G4ThreeVector > f0r, f0p;
   f0r.resize( n );
   f0p.resize( n );
   std::vector< G4ThreeVector > k1r, k1p;
   k1r.resize( n );
   k1p.resize( n );
   std::vector< G4ThreeVector > k2r, k2p;
   k2r.resize( n );
   k2p.resize( n );
   std::vector< G4ThreeVector > k3r, k3p;
   k3r.resize( n );
   k3p.resize( n );
   std::vector< G4ThreeVector > k4r, k4p;
   k4r.resize( n );
   k4p.resize( n );

   for ( G4int i = 0 ; i < n ; i++ )
   {
      G4ThreeVector ri = system->GetParticipant( i )->GetPosition();  
      G4ThreeVector p3i = system->GetParticipant( i )->GetMomentum();  
      rkr0[i] = ri;
      rkp0[i] = p3i;
      
      ri += dt* ffr[i]/2;
      p3i += dt* ffp[i]/2;

      k1r[i] = dt* ffr[i];
      k1p[i] = dt* ffp[i];
      
      f0r[i] = ffr[i];
      f0p[i] = ffp[i];
      
      system->GetParticipant( i )->SetPosition( ri );
      system->GetParticipant( i )->SetMomentum( p3i );

//    we do not need set total momentum by ourselvs
   }

// 2nd Step
   Cal2BodyQuantities(); 
   CalGraduate(); 

   for ( G4int i = 0 ; i < n ; i++ )
   {
      G4ThreeVector ri = system->GetParticipant( i )->GetPosition();  
      G4ThreeVector p3i = system->GetParticipant( i )->GetMomentum();  

      ri += dt1* f0r[i] + dt* ffr[i]/2;
      p3i += dt1* f0p[i] + dt* ffp[i]/2;

      k2r[i] = dt* ffr[i];
      k2p[i] = dt* ffp[i];
      
      system->GetParticipant( i )->SetPosition( ri );  
      system->GetParticipant( i )->SetMomentum( p3i );  

//    we do not need set total momentum by ourselvs
   }

// 3rd Step
   Cal2BodyQuantities(); 
   CalGraduate(); 

   for ( G4int i = 0 ; i < n ; i++ )
   {
      G4ThreeVector ri = system->GetParticipant( i )->GetPosition();  
      G4ThreeVector p3i = system->GetParticipant( i )->GetMomentum();  

      ri = rkr0[i] + dt* ffr[i];
      p3i = rkp0[i] + dt* ffp[i];

      k3r[i] = dt* ffr[i];
      k3p[i] = dt* ffp[i];

      system->GetParticipant( i )->SetPosition( ri );  
      system->GetParticipant( i )->SetMomentum( p3i );  

//    we do not need set total momentum by ourselvs
   }
   
// 4th Step
   Cal2BodyQuantities(); 
   CalGraduate(); 

   for ( G4int i = 0 ; i < n ; i++ )
   {
      G4ThreeVector ri = system->GetParticipant( i )->GetPosition();  
      G4ThreeVector p3i = system->GetParticipant( i )->GetMomentum();  

      k4r[i] = dt* ffr[i];
      k4p[i] = dt* ffp[i];

      ri = rkr0[i] + (k1r[i] + 2*k2r[i] + 2*k3r[i] + k4r[i])/6;
      p3i = rkp0[i] +(k1p[i] + 2*k2p[i] + 2*k3p[i] + k4p[i])/6;

      system->GetParticipant( i )->SetPosition( ri );  
      system->GetParticipant( i )->SetMomentum( p3i );  

//    we do not need set total momentum by ourselvs
   }

   Cal2BodyQuantities(); 

}
*/

std::vector< LocalQMDNucleus* > LocalQMDMeanField::DoClusterJudgment()
{

    //std::cout << "MeanField DoClusterJudgemnt" << std::endl;

    Cal2BodyQuantities();

    G4double cpf2 = G4Pow::GetInstance()->A23 ( 1.5 * pi*pi * G4Pow::GetInstance()->powA ( 4.0 * pi * wl , -1.5 ) ) * hbc * hbc;



    //isoR ver. yoshi 20230103
    //G4double rcc2 = cluster_radius*cluster_radius;
    G4double rcc2_pn = cluster_radius_pn*cluster_radius_pn;
    G4double rcc2_pp = cluster_radius_pp*cluster_radius_pp;
    G4double rcc2_nn = cluster_radius_nn*cluster_radius_nn;
    //G4double rcc2 = rclds*rclds;

    G4int n = system->GetTotalNumberOfParticipant();
    std::vector < G4double > rhoa;
    rhoa.resize ( n );

    for ( G4int i = 0 ; i < n ; ++i )
    {
        rhoa[i] = 0.0;

        if ( system->GetParticipant( i )->GetBaryonNumber() == 1 )
        {
            for ( G4int j = 0 ; j < n ; ++j )
          {
             if ( system->GetParticipant( j )->GetBaryonNumber() == 1 )
             rhoa[i] += rha[i][j];
          }
        }

        rhoa[i] = G4Pow::GetInstance()->A13 ( rhoa[i] + 1 );

    }

// identification of the cluster

   std::map < G4int , std::vector < G4int > > cluster_map;
   std::vector < G4bool > is_already_belong_some_cluster;

   //         cluster_id   participant_id
   std::multimap < G4int , G4int > comb_map; 
   std::multimap < G4int , G4int > assign_map; 
   assign_map.clear(); 

   std::vector < G4int > mascl;
   std::vector < G4int > num;
   mascl.resize ( n );
   num.resize ( n );
   is_already_belong_some_cluster.resize ( n );

   std::vector < G4int > is_assigned_to ( n , -1 );
   std::multimap < G4int , G4int > clusters;

   for ( G4int i = 0 ; i < n ; ++i )
   {
      mascl[i] = 1;
      num[i] = 1;

      is_already_belong_some_cluster[i] = false;
   }


   G4int nclst = 1;
   G4int ichek = 1;


   G4int id = 0;
   G4int cluster_id = -1;  
   for ( G4int i = 0 ; i < n-1 ; ++i )
   { 
       G4int icharge = system->GetParticipant(i)->GetChargeInUnitOfEplus();
       G4bool hasThisCompany = false;
       //Check only for bryons?
       //std::cout << "Check Baryon " << i << std::endl;
       if ( system->GetParticipant( i )->GetBaryonNumber() == 1 )
       {

           //if ( is_already_belong_some_cluster[i] != true )
           //      {
           //G4int j1 = ichek + 1;
           G4int j1 = i + 1;
           for ( G4int j = j1 ; j < n ; ++j )
           {
               G4int jcharge = system->GetParticipant(j)->GetChargeInUnitOfEplus();
               std::vector < G4int > cluster_participants;
               if ( system->GetParticipant( j )->GetBaryonNumber() == 1 )
               {
                   G4double rdist2 = rr2[ i ][ j ];
                   G4double pdist2 = pp2[ i ][ j ];
                   //G4double rdist2 = rr2[ num[i] ][ num[j] ];
                   //G4double pdist2 = pp2[ num[i] ][ num[j] ];
                   G4double pcc2 = cpf2
                       * ( rhoa[ i ] + rhoa[ j ] )
                       * ( rhoa[ i ] + rhoa[ j ] );
                   //G4cout << "LocalQMDRESULT "
                   //<< i << " " << j << " n " << n << std::endl;
                   //       Check phase space: close enough?
                   
                   //isoR ver. yoshi 20230103 
                   //G4cout << "ic:" << icharge << "," << "jc:" << jcharge << G4endl;
                   G4double rcluster2 = rcc2_pn;
                   //G4cout << "pn" << G4endl;
                   if (icharge == jcharge)
                   {
                       if (icharge == 0)
                       {
                           rcluster2 = rcc2_nn;
                           //G4cout << "nn" << G4endl;
                       }
                       if (icharge == 1)
                       {
                           rcluster2 = rcc2_pp;
                           //G4cout << "pp" << G4endl;
                       }
                   }



                   if ( rdist2 < rcluster2 && pdist2 < pcc2*2.0 )
                   {

                       /*
                        G4cout << "LocalQMDRESULT "
                        << i << " " << j << " " << id << " "
                        << is_assigned_to [ i ] << " " << is_assigned_to [ j ]
                        << G4endl;
                        */

                       if ( is_assigned_to [ j ] == -1 )
                       {
                           if ( is_assigned_to [ i ] == -1 )
                           {
                               if ( clusters.size() != 0 )
                               {
                                   id = clusters.rbegin()->first + 1;
                                   //std::cout << "id is increare " << id << std::endl;
                               }
                               else
                               {
                                   id = 0;
                               }
                               clusters.insert ( std::multimap<G4int,G4int>::value_type ( id , i ) );
                               is_assigned_to [ i ] = id;
                               clusters.insert ( std::multimap<G4int,G4int>::value_type ( id , j ) );
                               is_assigned_to [ j ] = id;
                           }
                           else
                           {
                               clusters.insert ( std::multimap<G4int,G4int>::value_type ( is_assigned_to [ i ] , j ) );
                               is_assigned_to [ j ] = is_assigned_to [ i ];
                           }
                       }
                       else
                       {
                           //j is already belong to some cluester
                           if ( is_assigned_to [ i ] == -1 )
                           {
                               clusters.insert ( std::multimap<G4int,G4int>::value_type ( is_assigned_to [ j ] , i ) );
                               is_assigned_to [ i ] = is_assigned_to [ j ];
                           }
                           else
                           {
                               // i has companion
                               if ( is_assigned_to [ i ] != is_assigned_to [ j ] )
                               {
                                   // move companions to the cluster
                                   //
                                   //std::cout <<  "combine " << is_assigned_to [ i ] << " to " << is_assigned_to [ j ] << std::endl;
                                   std::multimap< G4int , G4int > clusters_tmp;
                                   G4int target_cluster_id;
                                   if ( is_assigned_to [ i ] > is_assigned_to [ j ] )
                                       target_cluster_id = is_assigned_to [ i ];
                                   else
                                       target_cluster_id = is_assigned_to [ j ];
                      
                                   for ( std::multimap< G4int , G4int >::iterator it
                                        = clusters.begin() ; it != clusters.end() ; ++it )
                                   {

                                       //std::cout << it->first << " " << it->second  << " " << target_cluster_id << std::endl;
                                       if ( it->first == target_cluster_id )
                                       {
                                           //std::cout << "move " <<  it->first << " " << it->second << std::endl;
                                           is_assigned_to [ it->second ] = is_assigned_to [ j ];
                                           clusters_tmp.insert ( std::multimap<G4int,G4int>::value_type (  is_assigned_to [ j ] , it->second ) );
                                       }
                                       else
                                       {
                                           clusters_tmp.insert ( std::multimap<G4int,G4int>::value_type ( it->first , it->second ) );
                                       }
                                   }

                                   clusters = clusters_tmp;
                                   //id = clusters.rbegin()->first;
                                   //id = target_cluster_id;
                                   //std::cout <<  "id " << id << std::endl;
                               }
                           }
                       }

                       //std::cout << "combination " << i << " " << j << std::endl;
                       comb_map.insert( std::multimap<G4int,G4int>::value_type ( i , j ) );
                       cluster_participants.push_back ( j );



                       if ( assign_map.find( cluster_id ) == assign_map.end() )
                       {
                           is_already_belong_some_cluster[i] = true;
                           assign_map.insert ( std::multimap<G4int,G4int>::value_type ( cluster_id , i ) );
                           hasThisCompany = true;
                       }
                       assign_map.insert ( std::multimap<G4int,G4int>::value_type ( cluster_id , j ) );
                       is_already_belong_some_cluster[j] = true;

                   }

                   if ( ichek == i )
                   {
                       ++nclst;
                       ++ichek;
                   }
               } // j is baryon

               if ( cluster_participants.size() > 0 )
               {
                   //                                         cluster , participant
                   cluster_map.insert ( std::pair < G4int , std::vector < G4int > > ( i , cluster_participants ) );
               }
           } // j
           //      }
       } // i is baryon
       if ( hasThisCompany == true ) ++cluster_id;
    } // i

   //std::cout << " id " << id << std::endl;

// sort
// Heavy cluster comes first
//                size    cluster_id 
   std::multimap< G4int , G4int > sorted_cluster_map; 
   for ( G4int i = 0 ; i <= id ; ++i )  // << "<=" because id is highest cluster nubmer.
   {
 
      //std::cout << i << " cluster has " << clusters.count( i )  << " nucleons." << std::endl;
      sorted_cluster_map.insert ( std::multimap<G4int,G4int>::value_type ( (G4int) clusters.count( i ) , i ) );

   }


// create nucleus from devided clusters
    // original
    /*
    std::vector < LocalQMDNucleus* > result;
    for ( std::multimap < G4int , G4int >::reverse_iterator it
        = sorted_cluster_map.rbegin() ; it != sorted_cluster_map.rend()  ; ++it)
    {

       //G4cout << "Add Participants to cluseter " << it->second << G4endl;

       if ( it->first != 0 )
       {
          LocalQMDNucleus* nucleus = new LocalQMDNucleus();
          for ( std::multimap < G4int , G4int >::iterator itt
              = clusters.begin() ; itt != clusters.end()  ; ++itt)
          {

             if ( it->second == itt->first )
             {
                nucleus->SetParticipant( system->GetParticipant ( itt->second ) );
                //G4cout << "Add Participants " << itt->second << " "  << system->GetParticipant ( itt->second )->GetPosition() << G4endl;
              }

          }
          result.push_back( nucleus );
       }

    }
    */
    // original -- end
    
    std::vector < G4int > cluster_id_system;
    cluster_id_system.resize( n );
    std::vector < LocalQMDNucleus* > result;
    for ( std::multimap < G4int , G4int >::reverse_iterator it
       = sorted_cluster_map.rbegin() ; it != sorted_cluster_map.rend()  ; ++it) 
    {

        //G4cout << "Add Participants to cluseter first " << it->first << " second " << it->second << G4endl;
    
        if ( it->first != 0 ) // means a nucleus (not meson/nucleon)
        {
            // Remove neutron cluster and proton cluster added by A. H.
            G4int p_clus = 0;
            G4int n_clus = 0;
            G4ThreeVector ic(0.0,0.0,0.0);
            for ( std::multimap < G4int , G4int >::iterator itt
                 = clusters.begin() ; itt != clusters.end()  ; ++itt)
            {
                //G4cout << "check " << itt->first << " itt second " << itt->second << G4endl;
                if ( it->second == itt->first ) // Extracting same cluster id
                {
                    //G4cout << "check " << itt->first-it->second << " itt second " << itt->second << G4endl;
                    G4String pname = system->GetParticipant ( itt->second )->GetDefinition()->GetParticleName();
                    if ( pname == "proton") p_clus += 1;
                    else if ( pname == "neutron") n_clus += 1;
                    ic += system->GetParticipant ( itt->second )->GetPosition();
                    cluster_id_system[itt->second] = itt->first;
                }
                //else
                //{
                //    G4cout << "check " << itt->first-it->second << " itt second " << itt->second << G4endl;
                //}
            }
            ic = ic/(p_clus+n_clus);
            if (p_clus == 0 || n_clus == 0) continue;
            // Remove neutron cluster and proton cluster added by A. H. -- end
            
            // Remove shortlived nucleus added by A. H.
            // G4cout << p_clus << " " << n_clus << " position " << ic << G4endl;  ///////////////// 2022.03.22
            G4double excitEnergy = 0.0;
            G4ParticleDefinition* particle0
                = G4IonTable::GetIonTable()->GetIon(p_clus,p_clus+n_clus,excitEnergy);
            G4double lifetime0 = particle0->GetPDGLifeTime();
            G4String cname = particle0->GetParticleName();
            
            G4int n_rem = 0;
            G4int max_id[4] = {-1};
            G4double max_diff[4] = {0.0};
            if ((lifetime0 < 0.001 && lifetime0 > -0.1) && ( cname != "Be8"))
            {
                // G4cout << cname << " Decay time: " << lifetime0 << G4endl;  ///////////////// 2022.03.22
                G4int nn_clus = n_clus;
                G4int pp_clus = p_clus;
                G4double max_diff1 = 0.0;
                G4int max_id1 = 0;
                G4double max_diff2 = 0.0;
                G4int max_id2 = 0;
                G4double max_diff3 = 0.0;
                G4int max_id3 = 0;
                G4double max_diff4 = 0.0;
                G4int max_id4 = 0;
                
                G4int n_extra = 0;
                if(p_clus > 50) n_extra = 10 + (p_clus-50);
                if(p_clus < n_clus - n_extra)
                {
                    for (G4int ii = 1; ii < 5; ++ii)
                    {
                        nn_clus = n_clus-ii;
                        G4ParticleDefinition* particle00
                            = G4IonTable::GetIonTable()->GetIon(p_clus,nn_clus+p_clus,excitEnergy);
                        G4double lifetime00 = particle00->GetPDGLifeTime();
                        G4String cname0 = particle00->GetParticleName();
                        // G4cout << cname0 << " Decay timeN: " << lifetime00 << G4endl; ///////////////// 2022.03.22
                        if ((lifetime00 >= 0.001 || lifetime00 < -0.1) || ( cname0 == "Be8")) break;
                    }
                    n_rem = n_clus - nn_clus;
                    for ( std::multimap < G4int , G4int >::iterator itt
                         = clusters.begin() ; itt != clusters.end()  ; ++itt)
                    {
                        G4String pname0 = system->GetParticipant ( itt->second )->GetDefinition()->GetParticleName();
                        if ( it->second == itt->first && pname0 == "neutron")
                        {
                            G4ThreeVector ipos(system->GetParticipant ( itt->second )->GetPosition());
                            G4double diff = (ipos-ic)*(ipos-ic);
                            if (max_diff1 < diff)
                            {
                                max_diff4 = max_diff3;
                                max_id4 = max_id3;
                                max_diff3 = max_diff2;
                                max_id3 = max_id2;
                                max_diff2 = max_diff1;
                                max_id2 = max_id1;
                                max_diff1 = diff;
                                max_id1 = itt->second;
                            }
                            else if (max_diff1 > diff && max_diff2 < diff)
                            {
                                max_diff4 = max_diff3;
                                max_id4 = max_id3;
                                max_diff3 = max_diff2;
                                max_id3 = max_id2;
                                max_diff2 = diff;
                                max_id2 = itt->second;
                            }
                            else if (max_diff2 > diff && max_diff3 < diff)
                            {
                                max_diff4 = max_diff3;
                                max_id4 = max_id3;
                                max_diff3 = diff;
                                max_id3 = itt->second;
                            }
                            else if (max_diff3 > diff && max_diff4 < diff)
                            {
                                max_diff4 = diff;
                                max_id4 = itt->second;
                            }
                            // G4cout << "Add Participants " << itt->second << " "  << diff << G4endl;  ///////////////// 2022.03.22
                        }

                    }
                    max_id[0] = max_id1;
                    max_id[1] = max_id2;
                    max_id[2] = max_id3;
                    max_id[3] = max_id4;
                    max_diff[0] = max_diff1;
                    max_diff[1] = max_diff2;
                    max_diff[2] = max_diff3;
                    max_diff[3] = max_diff4;
                    
                    //for ( std::multimap < G4int , G4int >::iterator itt
                    //     = clusters.begin() ; itt != clusters.end()  ; ++itt)
                    //{
                    //    for (G4int ii2 = 0; ii2 < n_clus-nn_clus; ++ii2)
                    //    {
                    //        if(itt->second == max_id[ii2])
                    //        {
                    //            G4cout << "remove id " << max_id[ii2] << " diff " << max_diff[ii2] << G4endl;
                    //            //itt->first = 0;
                    //        }
                    //    }
                    //}
                     
                }
                else
                {
                    for (G4int ii = 1; ii < 5; ++ii)
                    {
                        pp_clus = p_clus-ii;
                        G4ParticleDefinition* particle00
                            = G4IonTable::GetIonTable()->GetIon(pp_clus,n_clus+pp_clus,excitEnergy);
                        G4double lifetime00 = particle00->GetPDGLifeTime();
                        G4String cname0 = particle00->GetParticleName();
                        // G4cout << cname0 << " Decay timeP: " << lifetime00 << G4endl; ///////////////// 2022.03.22
                        if ((lifetime00 >= 0.001 || lifetime00 < -0.1) || ( cname0 == "Be8")) break;
                    }
                    n_rem = p_clus - pp_clus;
                    for ( std::multimap < G4int , G4int >::iterator itt
                         = clusters.begin() ; itt != clusters.end()  ; ++itt)
                    {
                        G4String pname0 = system->GetParticipant ( itt->second )->GetDefinition()->GetParticleName();
                        if ( it->second == itt->first && pname0 == "proton")
                        {
                            G4ThreeVector ipos(system->GetParticipant ( itt->second )->GetPosition());
                            G4double diff = (ipos-ic)*(ipos-ic);
                            if (max_diff1 < diff)
                            {
                                max_diff4 = max_diff3;
                                max_id4 = max_id3;
                                max_diff3 = max_diff2;
                                max_id3 = max_id2;
                                max_diff2 = max_diff1;
                                max_id2 = max_id1;
                                max_diff1 = diff;
                                max_id1 = itt->second;
                            }
                            else if (max_diff1 > diff && max_diff2 < diff)
                            {
                                max_diff4 = max_diff3;
                                max_id4 = max_id3;
                                max_diff3 = max_diff2;
                                max_id3 = max_id2;
                                max_diff2 = diff;
                                max_id2 = itt->second;
                            }
                            else if (max_diff2 > diff && max_diff3 < diff)
                            {
                                max_diff4 = max_diff3;
                                max_id4 = max_id3;
                                max_diff3 = diff;
                                max_id3 = itt->second;
                            }
                            else if (max_diff3 > diff && max_diff4 < diff)
                            {
                                max_diff4 = diff;
                                max_id4 = itt->second;
                            }
                            //G4cout << "Add Participants " << itt->second << " "  << diff << G4endl; ///////////////// 2022.03.22
                        }

                    }
                    max_id[0] = max_id1;
                    max_id[1] = max_id2;
                    max_id[2] = max_id3;
                    max_id[3] = max_id4;
                    max_diff[0] = max_diff1;
                    max_diff[1] = max_diff2;
                    max_diff[2] = max_diff3;
                    max_diff[3] = max_diff4;
                    
                    //for ( std::multimap < G4int , G4int >::iterator itt
                    //     = clusters.begin() ; itt != clusters.end()  ; ++itt)
                    //{
                    //    for (G4int ii2 = 0; ii2 < p_clus-pp_clus; ++ii2)
                    //    {
                    //        if(itt->second == max_id[ii2])
                    //        {
                    //            G4cout << "remove id " << max_id[ii2] << " diff " << max_diff[ii2] << G4endl;
                    //            //it->first = 0;
                    //        }
                    //    }
                    //}
                    
                    
                }
                //G4cout << "diff pn " << p_clus-pp_clus << " "  << n_clus-nn_clus << G4endl;
                //G4cout << "Max diff id " << max_id1 << " "  << max_diff1 << G4endl;
                //G4cout << "Max diff id " << max_id2 << " "  << max_diff2 << G4endl;
                //G4cout << "Max diff id " << max_id3 << " "  << max_diff3 << G4endl;
                
            }
            LocalQMDNucleus* nucleus = new LocalQMDNucleus();
            for ( std::multimap < G4int , G4int >::iterator itt
                 = clusters.begin() ; itt != clusters.end()  ; ++itt)
            {
                
                if ( it->second == itt->first )
                {
                    G4int id_remove = 0;
                    for (G4int ii2 = 0; ii2 < n_rem; ++ii2)
                    {
                        if(itt->second == max_id[ii2])
                        {
                            //G4cout << "remove id " << max_id[ii2] << " diff " << max_diff[ii2] << G4endl; ///////////////// 2022.03.22
                            id_remove = -1;
                        }
                    }
                    if (id_remove == -1) continue;
                
                    nucleus->SetParticipant( system->GetParticipant ( itt->second ) );
                    //G4cout << "Add Participants " << itt->second << " "  << max_id[0] << " "  << max_id[1] << G4endl;
                    
                    //G4cout << "Add Participants " << itt->second << " "  << system->GetParticipant ( itt->second )->GetDefinition()->GetParticleName() << G4endl;
                }

            }
            result.push_back( nucleus );
        } // For a nucleus (not meson/nucleon)

    } // map
    
    //exit(0);
    /*
    for (G4int i = 0; i<n;++i)
    {
        G4cout << "cluster id: " << cluster_id_system[i] << G4endl;
    }
    exit(0);
     */
// delete participants from current system

   for ( std::vector < LocalQMDNucleus* > ::iterator it
       = result.begin() ; it != result.end() ; ++it ) 
   {
      system->SubtractSystem ( *it ); 
   }
   
   return result;
   
}



void LocalQMDMeanField::Update() 
{ 
   SetSystem( system ); 
}

double LocalQMDMeanField::CalDensityProfile()
{
    G4int A = system->GetTotalNumberOfParticipant();
    
    G4double rsquare_gauss = 0.0;
    for ( G4int j = 0 ; j < A ; ++j )
    {
        G4ThreeVector rj = system->GetParticipant( j )->GetPosition();
        rsquare_gauss += rj*rj+3*wl;
    }
    return rsquare_gauss/A;
    //return rsquare*dd/3*dd/3*dd/3/A;
}

double LocalQMDMeanField::CalChargeDensityProfile()
{
    G4int A = system->GetTotalNumberOfParticipant();
    G4int Z = 0;
    G4double rsquare_gauss = 0.0;
    for ( G4int j = 0 ; j < A ; ++j )
    {
        G4int jcharge = system->GetParticipant(j)->GetChargeInUnitOfEplus();
        G4ThreeVector rj = system->GetParticipant( j )->GetPosition();
        if (jcharge==1)
        {
            rsquare_gauss += rj*rj+3*wl;
            Z += 1;
        }
    }
    return rsquare_gauss/Z;
}

G4double LocalQMDMeanField::GetSelfPotential( G4int j )
{
  G4double selfenergy = 0.0;
  G4double sigmaj = sigma[j];
  G4double ratio = scalar_potential[j]/(m_sigma*m_sigma + g_sigma2*sigmaj + g_sigma3*sigmaj*sigmaj);
  selfenergy += (-1.0/6.0*g_sigma2*sigmaj-1.0/4.0*g_sigma3*sigmaj*sigmaj)*ratio;
  return selfenergy;
}


G4double LocalQMDMeanField::GetScalarPotential( G4int i ) // 20240125 modified
{
    return scalar_potential[i];
}

G4double LocalQMDMeanField::GetCoulombPotential( G4int i )
{
    G4LorentzVector p4i = system->GetParticipant( i )->Get4Momentum();
    G4int n = system->GetTotalNumberOfParticipant();
    G4LorentzVector rhoA( G4ThreeVector(0,0,0) , 0 );
    for ( G4int j = 0 ; j < n ; ++j )
    {
        G4LorentzVector p4j = system->GetParticipant( j )->Get4Momentum();
        G4ThreeVector pji = p4j.v() - p4i.v();
        G4double ej = std::sqrt( pji*pji + p4j.m()*p4j.m());
        G4LorentzVector p4ji( pji, ej );
        rhoA += rhe[j][i] * p4ji/p4ji.e();
    }
    G4LorentzVector potential =
    + cl * rhoA * 2/hbc;
    //+ (g_rho/2 * g_rho/2 /(m_rho * m_rho)) * rhorho;
    //+ cs * rhorho * 2/cdp/hbc;
    //G4cout << "rhov " << rhov << " pote " << potential*hbc*cdp <<G4endl;
    //exit(0);
    return potential.e()*hbc;
}

G4double LocalQMDMeanField::GetRhoMesonPotential( G4int i )
{
    G4int n = system->GetTotalNumberOfParticipant();
    G4LorentzVector p4i = system->GetParticipant( i )->Get4Momentum();
    
    G4LorentzVector rhoA( G4ThreeVector(0,0,0) , 0 );
    G4LorentzVector rhorho( G4ThreeVector(0,0,0) , 0 );
    
    G4int icharge = system->GetParticipant(i)->GetChargeInUnitOfEplus();
    G4int inuc = system->GetParticipant(i)->GetNuc();
    
    for ( G4int j = 0 ; j < n ; ++j )
    {
        G4int jcharge = system->GetParticipant(j)->GetChargeInUnitOfEplus();
        G4int jnuc = system->GetParticipant(j)->GetNuc();
        
        G4LorentzVector p4j = system->GetParticipant( j )->Get4Momentum();
        
        //G4ThreeVector pij = (p4i - p4j).v();
        G4ThreeVector pji = p4j.v() - p4i.v();
        G4double e = std::sqrt( pji*pji + p4j.m()*p4j.m());
        G4LorentzVector p4ji( pji, e );
        
        //rhoA += rhe[j][i] * p4j/p4j.e();
        //rhorho += rha[j][i] * p4j/p4j.e() * cdp * jnuc * inuc
        //* (2.* jcharge - 1) * (2.* icharge - 1);
        rhoA += rhe[j][i] * p4ji/p4ji.e();
        rhorho += rha[j][i] * p4ji/p4ji.e() * cdp * jnuc * inuc
        * (2.* jcharge - 1) * (2.* icharge - 1);
        //exit(0);
    }
    G4LorentzVector potential =
    //+ cl * rhoA * 2;
    + (g_rho/2 * g_rho/2 /(m_rho * m_rho)) * rhorho;
    //+ cs * rhorho * 2/cdp/hbc;
    //G4cout << "rhov " << rhov << " pote " << potential*hbc*cdp <<G4endl;
    //exit(0);
    return potential.e()*hbc;
}

G4LorentzVector LocalQMDMeanField::GetVectorPotential( G4int i )
{
    return vector_potential[i];
}
