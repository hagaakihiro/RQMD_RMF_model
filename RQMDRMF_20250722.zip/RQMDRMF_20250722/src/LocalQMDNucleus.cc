//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// 081024 G4NucleiPropertiesTable:: to G4NucleiProperties::
//
#include <numeric>
#include <omp.h>
#include "LocalQMDNucleus.hh"
#include "G4Pow.hh"
#include "G4SystemOfUnits.hh"
#include "G4Proton.hh"
#include "G4Neutron.hh"
#include "G4NucleiProperties.hh"
#include "G4HadronicException.hh"

#include "LocalQMDParameters.hh"
#include "G4PhysicalConstants.hh"
#include <cmath>
#include <CLHEP/Random/Stat.h>

#include "G4ParticleDefinition.hh"

#include "G4IonTable.hh"

LocalQMDNucleus::LocalQMDNucleus()
{
   LocalQMDParameters* parameters = LocalQMDParameters::GetInstance();
   hbc = parameters->Get_hbc();
   
   jj = 0; // will be calcualted in CalEnergyAndAngularMomentumInCM;
   potentialEnergy = 0.0; // will be set through set method 
   excitationEnergy = 0.0;
    
    wl = parameters->Get_wl();
    cl = parameters->Get_cl();
    rho0 = parameters->Get_rho0();
    gamm = parameters->Get_gamm();
    eta = parameters->Get_eta(); // Skyrme-QMD
    kappas = parameters->Get_kappas(); // Skyrme-QMD
    
    cpw = parameters->Get_cpw();
    cph = parameters->Get_cph();
    cpc = parameters->Get_cpc();
    
    c0 = parameters->Get_c0();
    c3 = parameters->Get_c3();
    cs = parameters->Get_cs();
    g0 = parameters->Get_g0(); // Skyrme-QMD
    g0iso = parameters->Get_g0iso(); // Skyrme-QMD
    gtau0 = parameters->Get_gtau0(); // Skyrme-QMD
    
    // RMF-QMD
    cutoff_s = parameters->Get_cutoff_s();
    g_sigma = parameters->Get_g_sigma();
    g_sigma2 = parameters->Get_g_sigma2();
    g_sigma3 = parameters->Get_g_sigma3();
    g_sigma_bar = parameters->Get_g_sigma_bar();
    m_sigma = parameters->Get_m_sigma();
    cutoff_v = parameters->Get_cutoff_v();
    g_omega = parameters->Get_g_omega();
    g_omega_bar = parameters->Get_g_omega_bar();
    m_omega = parameters->Get_m_omega();
    cutoff_r = parameters->Get_cutoff_r();
    g_rho = parameters->Get_g_rho();
    g_rho_bar = parameters->Get_g_rho_bar();
    m_rho = parameters->Get_m_rho();
    
    cdp = parameters->Get_cdp();
    RMF = parameters->Get_RMF();
    
    // distance
    c0w = 1.0/4.0/wl;
    //c3w = 1.0/4.0/wl; //no need
    c0sw = std::sqrt( c0w );
    clw = 2.0 / std::sqrt ( 4.0 * pi * wl );
    
    // graduate
    c0g = - c0 / ( 2.0 * wl );
    c3g = - c3 / ( 4.0 * wl ) * gamm;
    csg = - cs / ( 2.0 * wl );
    pag = gamm - 1;
    pag_tau = eta - 1; // Skyrme-QMD
    cg0 = - g0 / ( 2.0 * wl );  // Skyrme-QMD
    cgtau0 = - gtau0 / ( 4.0 * wl ) * eta;  // Skyrme-QMD

    omp_num = 12;
}



//LocalQMDNucleus::~LocalQMDNucleus()
//{
//   ;
//}

// For energy conservation by A. H.
G4ThreeVector LocalQMDNucleus::GetNucleusPosition()
{
    G4ThreeVector r( 0.0 );
    std::vector< LocalQMDParticipant* >::iterator it;
    G4int num = 0;
    for ( it = participants.begin() ; it != participants.end() ; it++ )
    {
        r += (*it)->GetPosition();
        num += 1;
    }
    return r/num;
}


G4LorentzVector LocalQMDNucleus::Get4Momentum()
{
    G4LorentzVector p( 0 );
    std::vector< LocalQMDParticipant* >::iterator it;
    
    for ( it = participants.begin() ; it != participants.end() ; it++ )
    {
        p += (*it)->Get4Momentum();
    }
    return p;
}



G4int LocalQMDNucleus::GetMassNumber()
{

   G4int A = 0; 
   std::vector< LocalQMDParticipant* >::iterator it;
   for ( it = participants.begin() ; it != participants.end() ; it++ ) 
   {
      if ( (*it)->GetDefinition() == G4Proton::Proton() 
        || (*it)->GetDefinition() == G4Neutron::Neutron() ) 
         A++; 
   }

   if ( A == 0 ) {
      throw G4HadronicException(__FILE__, __LINE__, "LocalQMDNucleus has the mass number of 0!");
   }

   return A;
}



G4int LocalQMDNucleus::GetAtomicNumber()
{
   G4int Z = 0; 
   std::vector< LocalQMDParticipant* >::iterator it;
   for ( it = participants.begin() ; it != participants.end() ; it++ ) 
   {
      if ( (*it)->GetDefinition() == G4Proton::Proton() ) 
         Z++; 
   }
   return Z;
}



G4double LocalQMDNucleus::GetNuclearMass()
{

   G4double mass = G4NucleiProperties::GetNuclearMass( GetMassNumber() , GetAtomicNumber() );
   
   if ( mass == 0.0 )
   {

      G4int Z = GetAtomicNumber();
      G4int A = GetMassNumber();
      G4int N = A - Z;

// Weizsacker-Bethe 

      G4double Av = 16*MeV; 
      G4double As = 17*MeV; 
      G4double Ac = 0.7*MeV; 
      G4double Asym = 23*MeV; 

      G4double BE = Av * A 
                  - As * G4Pow::GetInstance()->A23 ( G4double ( A ) ) 
                  - Ac * Z*Z/G4Pow::GetInstance()->A13 ( G4double ( A ) )
                  - Asym * ( N - Z )* ( N - Z ) / A; 

      mass = Z * G4Proton::Proton()->GetPDGMass() 
           + N * G4Neutron::Neutron()->GetPDGMass()
           - BE;

   }

   return mass;
}



void LocalQMDNucleus::CalEnergyAndAngularMomentumInCM()
{

   //G4cout << "CalEnergyAndAngularMomentumInCM " << this->GetAtomicNumber() << " " << GetMassNumber() << G4endl;

   G4double gamma = Get4Momentum().gamma();
   G4ThreeVector beta = Get4Momentum().v()/ Get4Momentum().e();
    
   G4ThreeVector pcm0( 0.0 ) ;

   G4int n = GetTotalNumberOfParticipant();
   pcm.resize( n );
   ecm.resize( n );

    G4double tmass = 0;
    G4ThreeVector rcm0( 0.0 ) ;
    rcm.resize( n );
    es.resize( n );

   for ( G4int i= 0; i < n ; i++ ) 
   {
       G4ThreeVector ri = GetParticipant( i )->GetPosition();
      G4ThreeVector p_i = GetParticipant( i )->GetMomentum();
       G4double e_i = GetParticipant( i )->Get4Momentum().e();
       G4double mi = GetParticipant( i )->GetMass();
      G4double trans = gamma / ( gamma + 1.0 ) * p_i * beta;
       //pcm[i] = p_i - trans*beta;
       //G4cout << "p_i " << p_i << " " << pcm[i] << " " << trans << " " << e_i <<G4endl;
       //G4cout << "p_i " << p_i << " " << pcm[i] << " " << (trans+e_i)*beta*gamma+p_i <<G4endl;
       pcm[i] = p_i + (trans-e_i)*beta*gamma;
       ecm[i] = gamma * e_i - gamma * p_i * beta;
       //pcm[i] = p_i;
       //ecm[i] = e_i;
       pcm0 += pcm[i];

       trans = gamma / ( gamma + 1.0 ) * ri * beta;
       rcm[i] = ri + trans*beta*gamma;
       //rcm[i] = ri;
       
       rcm0 += rcm[i]*ecm[i];
       tmass += ecm[i];
       
       //rcm0 += rcm[i]*std::sqrt ( mi*mi + pcm[i]*pcm[i] );
       //tmass += std::sqrt ( mi*mi + pcm[i]*pcm[i] );
       //rcm[i] = ri;
       //ecm[i] = std::sqrt(pcm[i]*pcm[i]+mi*mi);
       //pcm[i] = p_i + (trans-e_i)*beta*gamma;
   }
    //exit(0);
    //G4cout << "beta " << beta << " gamma " << gamma << " pcm0 " << pcm0 << G4endl;
   pcm0 = pcm0 / double ( n );
   G4ThreeVector rl ( 0.0 );
    rcm0 = rcm0/tmass;
    for ( G4int i= 0; i < n ; i++ )
    {
        rcm[i] += -rcm0;
        //rcm[i][2] *= gamma;
        //G4cout << "rcm " << i << " " << rcm[i] << G4endl;
	// Angluar momentum
        rl += rcm[i].cross ( pcm[i] );
    }
    // DHW: move hbc outside of sqrt to get correct units
    //  jj = int ( std::sqrt ( rl*rl / hbc ) + 0.5 );

    jj = int (std::sqrt(rl*rl)/hbc + 0.5);

    G4double totalMass = 0.0;
    G4double totalenergy = 0.0;
    G4int totalZ = 0;
    G4int totalA = 0;
#pragma omp parallel for reduction(+:totalenergy,totalMass,totalZ,totalA) num_threads(omp_num)
    for ( G4int i= 0; i < n ; i++ )
    {
        // following two lines are equivalent
        //totalMass += GetParticipant( i )->GetDefinition()->GetPDGMass()/GeV;
        totalMass += GetParticipant( i )->GetMass();
        totalZ += GetParticipant( i )->GetChargeInUnitOfEplus();
        totalA += 1;
        
	totalenergy += GetSingleEnergy_CM( i ); // RMF-QMD
    }

    G4double bindingEnergy = totalenergy; //RMF-QMD
    G4double b_mass = G4IonTable::GetIonTable()->GetIonMass( totalZ , totalA )-totalMass*GeV;
   //excitationEnergy = bindingEnergy + G4NucleiProperties::GetBindingEnergy( GetMassNumber() , GetAtomicNumber() )/GeV;
    excitationEnergy = bindingEnergy - b_mass/1000.0;
   //if ( excitationEnergy < 0 ) excitationEnergy = 0.0;
    //G4cout << "excitationEnergy in MeV " << excitationEnergy*1000 << " bindingEnergy in MeV " << bindingEnergy*1000 << " b_mass " << b_mass << " totalMass " << totalMass << G4endl;

}

G4double LocalQMDNucleus::GetNuclPotential( G4int i )
{
    epsx = -20.0;
    epscl = 0.0001; // coulomb term
    irelcr = 1;
    G4int n = GetTotalNumberOfParticipant();

    G4double rhoa = 0.0;
    G4double rho3 = 0.0;
    G4double fsij_rhoa = 0.0; // Skyrme-QMD
    //    G4double fsij_rhos = 0.0; // Skyrme-QMD
    G4double rho3_tau = 0.0; // Skyrme-QMD
    G4double rhos = 0.0;
    G4double rhoc = 0.0;
    
    
    G4int icharge = GetParticipant(i)->GetChargeInUnitOfEplus();
    G4int inuc = GetParticipant(i)->GetNuc();
    G4int ibry = GetParticipant(i)->GetBaryonNumber();
    
    //G4ThreeVector ri = GetParticipant( i )->GetPosition();
    //G4LorentzVector p4i = GetParticipant( i )->Get4Momentum();
    G4ThreeVector ri = rcm[i];
    G4LorentzVector p4i (pcm[i],ecm[i]);
    
    for ( G4int j = 0 ; j < n ; j ++ )
    {
        if (i == j) continue;
        G4double cef = 1.0;
        //if (i == j)
        //{
        //    cef = 0.0;
        //}

        
        G4int jcharge = GetParticipant(j)->GetChargeInUnitOfEplus();
        G4int jnuc = GetParticipant(j)->GetNuc();
        G4int jbry = GetParticipant(j)->GetBaryonNumber();
        
        //G4ThreeVector rj = GetParticipant( j )->GetPosition();
        //G4LorentzVector p4j = GetParticipant( j )->Get4Momentum();
        G4ThreeVector rj = rcm[j];
        G4LorentzVector p4j (pcm[j],ecm[j]);
        
        G4ThreeVector rij = ri - rj;
        G4ThreeVector pij = (p4i - p4j).v();
        G4LorentzVector p4ij = p4i - p4j;
        G4ThreeVector bij = ( p4i + p4j ).boostVector();
        G4double gammaij = ( p4i + p4j ).gamma();
        
        G4double eij = ( p4i + p4j ).e();
        
        G4double rbrb = rij*bij;
        //         G4double bij2 = bij*bij;
        G4double rij2 = rij*rij;
        G4double pij2 = pij*pij;
        
        
        rbrb = irelcr * rbrb;
        G4double  gamma2_ij = gammaij*gammaij;
        
        G4double rr2 = rij2 + gamma2_ij * rbrb*rbrb;
        
        G4double expa1 = - (rij2 + gamma2_ij * rbrb*rbrb) * c0w;
        G4double rh1;
        if ( expa1 > epsx )
        {
            rh1 = G4Exp( expa1 )*gammaij;
        }
        else
        {
            rh1 = 0.0;
        }
        
        G4double rrs2 = (rij2 + gamma2_ij * rbrb*rbrb) + epscl;
        G4double rrs = std::sqrt ( rrs2 );
        
        G4double xerf = 0.0;
        // T. K. add this protection. 5.8 is good enough for double
        if ( rrs*c0sw < 5.8 ) {
            //erf = G4RandStat::erf ( rrs*c0sw );
            //Restore to CLHEP for avoiding compilation error in MT
            //erf = CLHEP::HepStat::erf ( rrs*c0sw );
            //Use cmath
#if defined WIN32-VC
            xerf = CLHEP::HepStat::erf ( rrs*c0sw );
#else
            xerf = erf ( rrs*c0sw );
#endif
        } else {
            xerf = 1.0;
        }
        
        G4double erfij = xerf/rrs;
        
        G4double fsij = 3.0/(2*wl) - rr2/(2*wl)/(2*wl); // Add for Skyrme-QMD
        
        rhoa += ibry*jbry*rh1*cef;
        fsij_rhoa += fsij * ibry*jbry*rh1*cef; // Skyrme-QMD
        rhoc += icharge*jcharge * erfij * cef;
        rhos += ibry*jbry*rh1 * jnuc * inuc * cef
        * ( 1 - 2 * std::abs ( jcharge - icharge ) )
        * (1. - kappas * fsij);
        
        //G4cout << i << " " << j << " " << ( - erfij ) << " " << clw << G4endl;
        

    }
    
    rho3 = G4Pow::GetInstance()->powA ( rhoa , gamm );
    rho3_tau = G4Pow::GetInstance()->powA ( rhoa , eta );
    
    G4double potential = c0 * rhoa
    + c3 * rho3
    + g0 * fsij_rhoa  // Skyrme-QMD
    // + g0iso * fsij_rhos  // Skyrme-QMD
    + gtau0 * rho3_tau  // Skyrme-QMD
    + cs * rhos
    + cl * rhoc;
    
    //G4cout << "n " << n << " " << rho3 << G4endl;
    return potential;
}

G4double LocalQMDNucleus::GetSingleEnergy_CM( G4int i )
{
    //G4cout << "GetSingleEnergy_CM " << GetTotalNumberOfParticipant() << G4endl;
    G4int n = GetTotalNumberOfParticipant();
    G4ThreeVector p_i = pcm[i];
    G4double mi = GetParticipant( i )->GetMass();
    G4double ei = std::sqrt (mi*mi+p_i*p_i);
    G4ThreeVector ri = rcm[i];
    G4LorentzVector p4i( p_i , ei );
    
    G4LorentzVector rhov( G4ThreeVector(0,0,0) , 0 );
    G4LorentzVector rhov_md( G4ThreeVector(0,0,0) , 0 );
    G4LorentzVector rhoA( G4ThreeVector(0,0,0) , 0 );
    G4LorentzVector rhorho( G4ThreeVector(0,0,0) , 0 );
    G4LorentzVector omega( G4ThreeVector(0,0,0) , 0 );
    
    G4double rhos_md = 0.0;
    G4double rhos = 0.0;
    
    G4int icharge = GetParticipant(i)->GetChargeInUnitOfEplus();
    G4int inuc = GetParticipant(i)->GetNuc();
    
    for ( G4int j = 0 ; j < n ; j ++ )
    {
        if (i == j) continue;
        G4int jcharge = GetParticipant(j)->GetChargeInUnitOfEplus();
        G4int jnuc = GetParticipant(j)->GetNuc();
        
        G4ThreeVector pj = pcm[j];
        G4double mj = GetParticipant( j )->GetMass();
        G4double ej = std::sqrt (mj*mj+pj*pj);
        G4ThreeVector rj = rcm[j];
        G4LorentzVector p4j( pj , ej );
        
        G4ThreeVector rij = ri - rj;
        G4ThreeVector pij = (p_i - pj);
        
        G4ThreeVector bij = ( p4i + p4j ).boostVector();
        G4double gammaij = ( p4i + p4j ).gamma();
        G4double eij = ( p4i + p4j ).e();
        
        G4double rbrb = rij*bij;
        
        G4double rij2 = rij*rij;
        G4double pij2 = pij*pij;
        
        G4double  gamma2_ij = gammaij*gammaij;
        G4double rr2 = rij2 + gamma2_ij * rbrb*rbrb;
        
        G4double pp2 = pij2
        + ( - G4Pow::GetInstance()->powN ( p4i.e() - p4j.e() , 2 )
           + gamma2_ij * G4Pow::GetInstance()->powN ( ( ( p4i.m2() - p4j.m2() ) / eij ) , 2 ) );
        
        
        G4double expa1 = - rr2 * c0w;
        G4double rh1;
        if ( expa1 > -20.0 )
        {
            rh1 = G4Exp( expa1 );
        }
        else
        {
            rh1 = 0.0;
        }
        
        //if ( i == j ) rh1 = 0.0;
        
        rhos += rh1*gammaij * cdp * mj/ej;
        rhos_md += rh1*gammaij * cdp * mj/ej/(1.-pp2*pp2/(cutoff_s*cutoff_s));
        
        rhov += rh1*gammaij * cdp * p4j/p4j.e() * jnuc * inuc;
        rhov_md += rh1*gammaij * cdp * p4j/p4j.e() * jnuc * inuc /(1.-pp2*pp2/(cutoff_v*cutoff_v));
        
        
        G4double rrs2 = rr2 + 0.0001;
        G4double rrs = std::sqrt ( rrs2 );
        G4double xerf = 0.0;
        //G4double c0sw = std::sqrt( c0w );
        if ( rrs*c0sw < 5.8 )
        {
#if defined WIN32-VC
            xerf = CLHEP::HepStat::erf ( rrs*c0sw );
#else
            xerf = erf ( rrs*c0sw );
#endif
        } else
        {
            xerf = 1.0;
        }
        G4double erfij = xerf/rrs;
        //if ( i == j ) erfij = 0.0;
        rhoA += erfij * p4j/p4j.e() * jcharge * icharge ;
        //rhorho += rha[j][i] * p4j/p4j.e() * cdp * jnuc * inuc
        //* ( 1. - 2. * std::abs( jcharge - icharge ) );
        rhorho += rh1*gammaij * p4j/p4j.e() * cdp * jnuc * inuc
        * (2.* jcharge - 1) * (2.* icharge - 1);
        //exit(0);
    }
    
    G4double sigma = g_sigma * rhos/(m_sigma * m_sigma);
    
    //G4cout << "rhos " << rhos << " p4j.m()/p4j.e() " << p4i.m()/p4i.e() <<G4endl;
    G4double sigma1 = sigma*1.1;
    G4int n_max = 100;
    for  ( G4int j = 0 ; j < n_max ; j ++ )
    {
        sigma = (g_sigma * rhos)/((m_sigma * m_sigma) + g_sigma2 * sigma + g_sigma3 * sigma * sigma);
        sigma = 0.5*(sigma+sigma1);
        //G4cout << "sigma[i] " << j << " : " << sigma[i] << G4endl;
        if (abs(sigma-sigma1)/abs(sigma) < 0.00001) break;
        sigma1 = sigma;
        
    }
    
    omega = g_omega * rhov/(m_omega * m_omega);
    G4LorentzVector vectorpote =
    (g_omega * omega
     + (g_omega_bar*g_omega_bar/(m_omega * m_omega)) * rhov_md
     + cl * rhoA * 2/hbc
     + (g_rho/2 * g_rho/2 /(m_rho * m_rho)) * rhorho)*hbc;
    
    G4double scalarpote = (g_sigma * sigma
                           + (g_sigma_bar*g_sigma_bar/(m_sigma * m_sigma)) * rhos_md)*hbc;
    
    G4double mi_star = p4i.m() - scalarpote;
    G4ThreeVector p3i_star = p4i.v() - vectorpote.v();
    G4double fi = p4i.m()/p4i.e();
    
    G4double ener = std::sqrt( p3i_star*p3i_star + mi_star*mi_star);
    G4double energy = ener-p4i.m();
    energy += vectorpote.e()/2 + scalarpote*p4i.m()/p4i.e()/2 + vectorpote.v()*p4i.v()/p4i.e()/2;
    G4double ratio = scalarpote*fi/(m_sigma*m_sigma + g_sigma2*sigma + g_sigma3*sigma*sigma);
    energy += (-1.0/6.0*g_sigma2*sigma-1.0/4.0*g_sigma3*sigma*sigma)*ratio;
    //energy += vectorpote.e()/2;
    //energy += ((g_sigma2 * sigma * sigma * sigma)/(3.0)
    //           + (g_sigma3 * sigma * sigma * sigma * sigma)/(4.0)
    //           - 0.5*(g_sigma2 * sigma * sigma * sigma)
    //           - 0.5*(g_sigma3 * sigma * sigma * sigma * sigma))*hbc;
    return energy;
}

G4double LocalQMDNucleus::GetTotalEnergy_withMomentum( )
{
    G4double tenergy = 0.0;
    G4int n = GetTotalNumberOfParticipant();
    /*
    pcm.resize( n );
    ecm.resize( n );
     rcm.resize( n );
    for ( G4int i= 0; i < n ; i++ )
    {
        pcm[i] = GetParticipant( i )->GetMomentum();
        ecm[i] = GetParticipant( i )->Get4Momentum().e();
        rcm[i] = GetParticipant( i )->GetPosition();
    }
    */
#pragma omp parallel for num_threads(omp_num)
    for ( G4int i= 0; i < n ; i++ )
    {
      //G4ThreeVector p_i = GetParticipant( i )->GetMomentum();
      //if(RMF)
      //{
      tenergy += GetSingleEnergy_withMomentum(i);
      //}
      //else
      //{
      //    G4double nucpote = GetNuclPotential( i );
      //    tenergy += std::sqrt ( G4Pow::GetInstance()->powN ( GetParticipant( i )->GetMass() , 2 ) + p_i*p_i + 2.0*GetParticipant( i )->GetMass()*nucpote); //R-JQMD
      //}
    }
    return tenergy;
}


G4double LocalQMDNucleus::GetSingleEnergy_withMomentum( G4int i )
{
    //G4cout << "GetSingleEnergy_CM " << GetTotalNumberOfParticipant() << G4endl;
    G4int n = GetTotalNumberOfParticipant();
    G4ThreeVector p_i = GetParticipant( i )->GetMomentum();
    G4double mi = GetParticipant( i )->GetMass();
    G4double ei = std::sqrt (mi*mi+p_i*p_i);
    G4ThreeVector ri = GetParticipant( i )->GetPosition();
    G4LorentzVector p4i( p_i , ei );
    
    G4LorentzVector rhov( G4ThreeVector(0,0,0) , 0 );
    G4LorentzVector rhov_md( G4ThreeVector(0,0,0) , 0 );
    G4LorentzVector rhoA( G4ThreeVector(0,0,0) , 0 );
    G4LorentzVector rhorho( G4ThreeVector(0,0,0) , 0 );
    G4LorentzVector omega( G4ThreeVector(0,0,0) , 0 );
    
    G4double rhos_md = 0.0;
    G4double rhos = 0.0;
    
    G4int icharge = GetParticipant(i)->GetChargeInUnitOfEplus();
    G4int inuc = GetParticipant(i)->GetNuc();
    
    for ( G4int j = 0 ; j < n ; j ++ )
    {
        if (i == j) continue;
        G4int jcharge = GetParticipant(j)->GetChargeInUnitOfEplus();
        G4int jnuc = GetParticipant(j)->GetNuc();
        
        G4ThreeVector pj = GetParticipant( j )->GetMomentum();
        G4double mj = GetParticipant( j )->GetMass();
        G4double ej = std::sqrt (mj*mj+pj*pj);
        G4ThreeVector rj = GetParticipant( j )->GetPosition();
        G4LorentzVector p4j( pj , ej );
        
        G4ThreeVector rij = ri - rj;
        G4ThreeVector pij = (p_i - pj);
        
        G4ThreeVector bij = ( p4i + p4j ).boostVector();
        G4double gammaij = ( p4i + p4j ).gamma();
        G4double eij = ( p4i + p4j ).e();
        
        G4double rbrb = rij*bij;
        
        G4double rij2 = rij*rij;
        G4double pij2 = pij*pij;
        
        G4double  gamma2_ij = gammaij*gammaij;
        G4double rr2 = rij2 + gamma2_ij * rbrb*rbrb;
        
        G4double pp2 = pij2
        + ( - G4Pow::GetInstance()->powN ( p4i.e() - p4j.e() , 2 )
           + gamma2_ij * G4Pow::GetInstance()->powN ( ( ( p4i.m2() - p4j.m2() ) / eij ) , 2 ) );
        
        
        G4double expa1 = - rr2 * c0w;
        G4double rh1;
        if ( expa1 > -20.0 )
        {
            rh1 = G4Exp( expa1 );
        }
        else
        {
            rh1 = 0.0;
        }
        
        //if ( i == j ) rh1 = 0.0;
        
        rhos += rh1*gammaij * cdp * mj/ej;
        rhos_md += rh1*gammaij * cdp * mj/ej/(1.-pp2*pp2/(cutoff_s*cutoff_s));
        
        rhov += rh1*gammaij * cdp * p4j/p4j.e() * jnuc * inuc;
        rhov_md += rh1*gammaij * cdp * p4j/p4j.e() * jnuc * inuc /(1.-pp2*pp2/(cutoff_v*cutoff_v));
        
        
        G4double rrs2 = rr2 + 0.0001;
        G4double rrs = std::sqrt ( rrs2 );
        G4double xerf = 0.0;
        //G4double c0sw = std::sqrt( c0w );
        if ( rrs*c0sw < 5.8 )
        {
#if defined WIN32-VC
            xerf = CLHEP::HepStat::erf ( rrs*c0sw );
#else
            xerf = erf ( rrs*c0sw );
#endif
        } else
        {
            xerf = 1.0;
        }
        G4double erfij = xerf/rrs;
        //if ( i == j ) erfij = 0.0;
        rhoA += erfij * p4j/p4j.e() * jcharge * icharge ;
        //rhorho += rha[j][i] * p4j/p4j.e() * cdp * jnuc * inuc
        //* ( 1. - 2. * std::abs( jcharge - icharge ) );
        rhorho += rh1*gammaij * p4j/p4j.e() * cdp * jnuc * inuc
        * (2.* jcharge - 1) * (2.* icharge - 1);
        //exit(0);
    }
    
    G4double sigma = g_sigma * rhos/(m_sigma * m_sigma);
    
    //G4cout << "rhos " << rhos << " p4j.m()/p4j.e() " << p4i.m()/p4i.e() <<G4endl;
    G4double sigma1 = sigma*1.1;
    G4int n_max = 100;
    for  ( G4int j = 0 ; j < n_max ; j ++ )
    {
        sigma = (g_sigma * rhos)/((m_sigma * m_sigma) + g_sigma2 * sigma + g_sigma3 * sigma * sigma);
        sigma = 0.5*(sigma+sigma1);
        //G4cout << "sigma[i] " << j << " : " << sigma[i] << G4endl;
        if (abs(sigma-sigma1)/abs(sigma) < 0.00001) break;
        sigma1 = sigma;
        
    }
    
    omega = g_omega * rhov/(m_omega * m_omega);
    G4LorentzVector vectorpote =
    (g_omega * omega
     + (g_omega_bar*g_omega_bar/(m_omega * m_omega)) * rhov_md
     + cl * rhoA * 2/hbc
     + (g_rho/2 * g_rho/2 /(m_rho * m_rho)) * rhorho)*hbc;
    
    G4double scalarpote = (g_sigma * sigma
                           + (g_sigma_bar*g_sigma_bar/(m_sigma * m_sigma)) * rhos_md)*hbc;
    
    G4double mi_star = p4i.m() - scalarpote;
    G4ThreeVector p3i_star = p4i.v() - vectorpote.v();
    G4double fi = p4i.m()/p4i.e();
    
    G4double ener = std::sqrt( p3i_star*p3i_star + mi_star*mi_star);
    G4double energy = ener-p4i.m();
    energy += vectorpote.e()/2 + scalarpote*p4i.m()/p4i.e()/2 + vectorpote.v()*p4i.v()/p4i.e()/2;
    G4double ratio = scalarpote*fi/(m_sigma*m_sigma + g_sigma2*sigma + g_sigma3*sigma*sigma);
    energy += (-1.0/6.0*g_sigma2*sigma-1.0/4.0*g_sigma3*sigma*sigma)*ratio;
    //energy += vectorpote.e()/2;
    //energy += ((g_sigma2 * sigma * sigma * sigma)/(3.0)
    //           + (g_sigma3 * sigma * sigma * sigma * sigma)/(4.0)
    //           - 0.5*(g_sigma2 * sigma * sigma * sigma)
    //           - 0.5*(g_sigma3 * sigma * sigma * sigma * sigma))*hbc;
    return energy;
}

