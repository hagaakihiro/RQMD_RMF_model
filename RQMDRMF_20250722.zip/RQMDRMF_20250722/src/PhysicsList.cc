
#include "PhysicsList.hh"
#include "G4ProcessManager.hh"
#include "G4BosonConstructor.hh"
#include "G4LeptonConstructor.hh"
#include "G4MesonConstructor.hh"
#include "G4BosonConstructor.hh"
#include "G4BaryonConstructor.hh"
#include "G4IonConstructor.hh"
//#include "G4EmProcessOptions.hh"

#include "G4EmLivermorePhysics.hh"
#include "G4DecayPhysics.hh"

using namespace CLHEP;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PhysicsList::PhysicsList():  G4VUserPhysicsList()
{
				defaultCutValue = 0.1*mm; //livemore
				//SetVerboseLevel(1);
}


PhysicsList::~PhysicsList()
{}


void PhysicsList::ConstructParticle()
{
				// In this method, static member functions should be called
				// for all particles which you want to use.
				// This ensures that objects of these particle types will be
				// created in the program. 

				G4BosonConstructor  pBosonConstructor;
				pBosonConstructor.ConstructParticle();

				G4LeptonConstructor pLeptonConstructor;
				pLeptonConstructor.ConstructParticle();

				G4MesonConstructor pMesonConstructor;
				pMesonConstructor.ConstructParticle();

				G4BaryonConstructor pBaryonConstructor;
				pBaryonConstructor.ConstructParticle();

				G4IonConstructor pIonConstructor;
				pIonConstructor.ConstructParticle(); 
}


void PhysicsList::ConstructProcess()
{
				AddTransportation();
				//ConstructEM();
				//ConstructDecay();
				emPhysicsList  = new G4EmLivermorePhysics();
				//decPhysicsList = new G4DecayPhysics();
				emPhysicsList  ->ConstructProcess();
				//decPhysicsList ->ConstructProcess();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#include "G4PhysicsListHelper.hh"

#include "G4PhotoElectricEffect.hh"
#include "G4RayleighScattering.hh"
#include "G4ComptonScattering.hh"
#include "G4GammaConversion.hh"


#include "G4LivermorePhotoElectricModel.hh"
#include "G4LivermoreRayleighModel.hh"
#include "G4LivermoreComptonModel.hh"
#include "G4LivermoreGammaConversionModel.hh"


#include "G4eMultipleScattering.hh"
#include "G4eIonisation.hh"
#include "G4eBremsstrahlung.hh"
#include "G4eplusAnnihilation.hh"
#include "G4LivermoreIonisationModel.hh"
#include "G4LivermoreBremsstrahlungModel.hh"

#include "G4MuMultipleScattering.hh"
#include "G4UniversalFluctuation.hh"
#include "G4MuIonisation.hh"
#include "G4MuBremsstrahlung.hh"
#include "G4MuPairProduction.hh"

#include "G4hMultipleScattering.hh"
#include "G4hIonisation.hh"
#include "G4hBremsstrahlung.hh"
#include "G4hPairProduction.hh"

#include "G4ionIonisation.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PhysicsList::ConstructEM()
{
				//G4PhysicsListHelper* ph = G4PhysicsListHelper::GetPhysicsListHelper();
				//theParticleIterator->reset();
				//while( (*theParticleIterator)() ){
				//				G4ParticleDefinition* particle = theParticleIterator->value();
				//				G4String particleName = particle->GetParticleName();

				//				G4double highEnergyLimit = 1*GeV;
				//				if (particleName == "gamma") {
				//								// gamma         

				//								G4PhotoElectricEffect* thePhotoElectricEffect = new G4PhotoElectricEffect();
				//								thePhotoElectricEffect->SetModel(new G4LivermorePhotoElectricModel());
				//								ph->RegisterProcess(thePhotoElectricEffect, particle);

				//								G4ComptonScattering* theComptonScattering = new G4ComptonScattering();
				//								theComptonScattering->SetModel(new G4LivermoreComptonModel());
				//								ph->RegisterProcess(theComptonScattering, particle);

				//								G4GammaConversion* theGammaConversion = new G4GammaConversion();
				//								theGammaConversion->SetModel(new G4LivermoreGammaConversionModel());
				//								ph->RegisterProcess(theGammaConversion, particle);

				//								G4RayleighScattering* theRayleigh = new G4RayleighScattering();
				//								theRayleigh->SetModel(new G4LivermoreRayleighModel());
				//								ph->RegisterProcess(theRayleigh, particle);

				//								//ph->RegisterProcess(new G4PhotoElectricEffect, particle);
				//								//ph->RegisterProcess(new G4RayleighScattering,  particle);
				//								//ph->RegisterProcess(new G4ComptonScattering,   particle);
				//								//ph->RegisterProcess(new G4GammaConversion,     particle);

				//				} else if (particleName == "e-") {
				//								//electron

				//								ph->RegisterProcess(new G4eMultipleScattering, particle);
				//								//ph->RegisterProcess(new G4eIonisation,         particle);
				//								//ph->RegisterProcess(new G4eBremsstrahlung,     particle);      

				//								G4eIonisation* eIoni = new G4eIonisation();
				//								eIoni->SetEmModel(new G4LivermoreIonisationModel());
				//								eIoni->SetFluctModel(new G4UniversalFluctuation() );
				//								ph->RegisterProcess(eIoni, particle);

				//								G4eBremsstrahlung* eBrem = new G4eBremsstrahlung();
				//								eBrem->SetEmModel(new G4LivermoreBremsstrahlungModel());
				//								ph->RegisterProcess(eBrem, particle);

				//				} else if (particleName == "e+") {
				//								//positron
				//								ph->RegisterProcess(new G4eMultipleScattering, particle);
				//								ph->RegisterProcess(new G4eIonisation,         particle);
				//								ph->RegisterProcess(new G4eBremsstrahlung,     particle);
				//								ph->RegisterProcess(new G4eplusAnnihilation,   particle);

				//								//G4eIonisation* eIoni = new G4eIonisation();
				//								//eIoni->SetEmModel(new G4LivermoreIonisationModel());
				//								//eIoni->SetFluctModel(new G4UniversalFluctuation() );
				//								//ph->RegisterProcess(eIoni, particle);
				//								//G4eBremsstrahlung* eBrem = new G4eBremsstrahlung();
				//								//eBrem->SetEmModel(new G4LivermoreBremsstrahlungModel());
				//								//ph->RegisterProcess(eBrem, particle);

				//				} else if( particleName == "mu+" || 
				//												particleName == "mu-"    ) {
				//								//muon  
				//								ph->RegisterProcess(new G4MuMultipleScattering, particle);
				//								ph->RegisterProcess(new G4MuIonisation,         particle);
				//								ph->RegisterProcess(new G4MuBremsstrahlung,     particle);
				//								ph->RegisterProcess(new G4MuPairProduction,     particle);

				//				} else if( particleName == "proton" || 
				//												particleName == "pi-" ||
				//												particleName == "pi+"    ) {
				//								//proton  
				//								ph->RegisterProcess(new G4hMultipleScattering, particle);
				//								ph->RegisterProcess(new G4hIonisation,         particle);
				//								ph->RegisterProcess(new G4hBremsstrahlung,     particle);
				//								ph->RegisterProcess(new G4hPairProduction,     particle);       

				//				} else if( particleName == "alpha" || 
				//												particleName == "He3" )     {
				//								//alpha 
				//								ph->RegisterProcess(new G4hMultipleScattering, particle);
				//								ph->RegisterProcess(new G4ionIonisation,       particle);

				//				} else if( particleName == "GenericIon" ) { 
				//								//Ions 
				//								ph->RegisterProcess(new G4hMultipleScattering, particle);
				//								ph->RegisterProcess(new G4ionIonisation,       particle);     

				//				} else if ((!particle->IsShortLived()) &&
				//												(particle->GetPDGCharge() != 0.0) && 
				//												(particle->GetParticleName() != "chargedgeantino")) {
				//								//all others charged particles except geantino
				//								ph->RegisterProcess(new G4hMultipleScattering, particle);
				//								ph->RegisterProcess(new G4hIonisation,         particle);        
				//				}     
				//}

				//SetCuts();

}


#include "G4Decay.hh"

void PhysicsList::ConstructDecay()
{
				//G4PhysicsListHelper* ph = G4PhysicsListHelper::GetPhysicsListHelper();

				//// Add Decay Process
				//G4Decay* theDecayProcess = new G4Decay();
				//theParticleIterator->reset();
				//while( (*theParticleIterator)() ){
				//				G4ParticleDefinition* particle = theParticleIterator->value();
				//				if (theDecayProcess->IsApplicable(*particle)) { 
				//								ph->RegisterProcess(theDecayProcess, particle);
				//				}
				//}
}


void PhysicsList::SetCuts()
{
				//if (verboseLevel >0){
				//				G4cout << "PhysicsList::SetCuts:";
				//				G4cout << "CutLength : " << G4BestUnit(defaultCutValue,"Length") << G4endl;
				//}

				//// set cut values for gamma at first and for e- second and next for e+,
				//// because some processes for e+/e- need cut values for gamma
				////
				//SetCutValue(defaultCutValue, "gamma");
				//SetCutValue(defaultCutValue, "e-");
				//SetCutValue(defaultCutValue, "e+");
				//SetCutValue(defaultCutValue, "proton");

				//G4EmProcessOptions opt;
				//opt.SetMinEnergy(0.25*keV);//livermore
				//opt.SetMaxEnergy(1.  *GeV);//livermore
				//opt.SetDEDXBinning  (220) ;//livermore
				////opt.SetLambdaBinning(1000);//dousatsu

				//if (verboseLevel>0) DumpCutValuesTable();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
