
#include "EventAction.hh"
#include "RunAction.hh"
#include "G4RunManager.hh"
#include "G4Event.hh"
#include "G4UnitsTable.hh"

#include "Randomize.hh"
#include <iomanip>

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

EventAction::EventAction()
{
    runAct = (RunAction*)G4RunManager::GetRunManager()->GetUserRunAction();
    printModulo = 1;
}

EventAction::~EventAction()
{
}

void EventAction::BeginOfEventAction(const G4Event* evt)
{  
    G4int evtNb = evt->GetEventID();
    if (evtNb%printModulo == 0) {
        if((evtNb%100000)==0){
            G4cout << "--->event: " << evtNb << G4endl;
            //CLHEP::HepRandom::showEngineStatus();
        }
    }

    //G4AnalysisManager* anaManager = G4AnalysisManager::Instance();
    //anaManager->FillH1(0,0);

}


void EventAction::EndOfEventAction(const G4Event* )
{
    //accumulates statistic
    //runAct->fillPerEvent(EnergyAbs, EnergyGap, TrackLAbs, TrackLGap);
}  

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
