//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
// $Id: SteppingAction.cc,v 1.1 2010-10-18 15:56:17 maire Exp $
// GEANT4 tag $Name: not supported by cvs2svn $
//
// 

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#include "SteppingAction.hh"

#include "DetectorConstruction.hh"
#include "EventAction.hh"

#include "G4Step.hh"
#include "G4RunManager.hh"

//for ROOT
//#include "g4analysis_defs.hh"

//using namespace G4Root;
using namespace CLHEP;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

SteppingAction::SteppingAction()					 
{
				detector    = (DetectorConstruction*) G4RunManager::GetRunManager()->GetUserDetectorConstruction();
				eventaction = (EventAction*)          G4RunManager::GetRunManager()->GetUserEventAction();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

SteppingAction::~SteppingAction()
{ }

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void SteppingAction::UserSteppingAction(const G4Step* aStep){

				// get volume of the current step
				G4VPhysicalVolume* prevolume  = aStep->GetPreStepPoint() ->GetTouchableHandle()->GetVolume();
				G4VPhysicalVolume* postvolume = aStep->GetPostStepPoint()->GetTouchableHandle()->GetVolume();
				//Get Energy Spectrum

				if (postvolume == detector->GetVirtualDetector()){
								G4double       totene    = aStep->GetTrack()->GetTotalEnergy()*1000;
								G4ThreeVector  pos       = aStep->GetTrack()->GetPosition();
								G4ThreeVector  verpos    = aStep->GetTrack()->GetVertexPosition();
								G4ThreeVector  direction = aStep->GetTrack()->GetVertexMomentumDirection();
								if((direction.y()<0.)&&(pos.y()!=-710)){ // Record the photon come from anode direction
												G4double anglex = atan((pos.x()-verpos.x())/(pos.y()-verpos.y()))*deg;
												G4double anglez = atan((pos.z()-verpos.z())/(pos.y()-verpos.y()))*deg;
												//G4cout<< " track Energy (Virtual Detector) "<<totene<<" position "<<pos.x()<<":"<<pos.z()<<":"<<pos.y()<<" angle "<<anglex<<":"<<anglez<<G4endl;
												
/*
G4AnalysisManager* anaManager = G4AnalysisManager::Instance();
												anaManager->FillH1(1 ,totene);
												anaManager->FillH1(2 ,totene*totene);
												anaManager->FillH2(10,pos.x(),anglex);
												anaManager->FillH2(11,pos.z(),anglez);
												for(int i=0;i<5;i++){
																if(abs(totene-(i*20+30))<10){
																				anaManager->FillH1(i+3,verpos.y());
																				anaManager->FillH2(i  ,pos.x(),pos.z());
																				anaManager->FillH2(i+5,anglex,anglez);

																}

												}
*/
								}
				}

}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
