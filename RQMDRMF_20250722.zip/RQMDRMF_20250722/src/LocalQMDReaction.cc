//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// 080505 Fixed and changed sampling method of impact parameter by T. Koi 
// 080602 Fix memory leaks by T. Koi 
// 080612 Delete unnecessary dependency and unused functions
//        Change criterion of reaction by T. Koi
// 081107 Add UnUseGEM (then use the default channel of G4Evaporation)
//            UseFrag (chage criterion of a inelastic reaction)
//        Fix bug in nucleon projectiles  by T. Koi    
// 090122 Be8 -> Alpha + Alpha 
// 090331 Change member shenXS and genspaXS object to pointer 
// 091119 Fix for incidence of neutral particles 
//
#include "LocalQMDReaction.hh"
#include "LocalQMDNucleus.hh"
#include "LocalQMDGroundStateNucleus.hh"
#include "G4Pow.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"
#include "G4NistManager.hh"

#include "G4CrossSectionDataSetRegistry.hh"
#include "G4BGGPionElasticXS.hh"
#include "G4BGGPionInelasticXS.hh"
//yoshi add new header file for using GG XS.
#include "G4VCrossSectionDataSet.hh"
#include "G4CrossSectionInelastic.hh"
#include "G4ComponentGGNuclNuclXsc.hh"
#include "G4PhysicsModelCatalog.hh"

#include "Randomize.hh"

// Fpr inelastic cross section check
#include "G4NuclearRadii.hh"
#include "G4HadronNucleonXsc.hh"
// test.csv (writting reaction data (particle, position, momentum))
#include <iostream>
#include <fstream>
using std::endl;
using std::ofstream;
// -- test.csv

LocalQMDReaction::LocalQMDReaction()
: G4HadronicInteraction("QMDModel")
, system ( NULL )
, deltaT ( 1 ) // in fsec (c=1)
, maxTime ( 100 ) // will have maxTime-th time step
, envelopF ( 1.3 ) // 10% for Peripheral reactions
, gem ( true )
, frag ( false )
, secID( -1 )
{
  LocalQMDParameters* parameters = LocalQMDParameters::GetInstance();
  maxT_parameter = parameters->Get_maxT_parameter();
  delT_parameter = parameters->Get_delT_parameter();
  env_parameter = parameters->Get_env_parameter();
    
  G4cout << "LocalQMDReaction::LocalQMDReaction " << " maxT " <<maxT_parameter << " delT " << delT_parameter << " envlopeF " << env_parameter <<G4endl;
   
  theXS = new G4CrossSectionInelastic( new G4ComponentGGNuclNuclXsc );//GG ver. yoshi 20230103
  //shenXS = new G4IonsShenCrossSection(); //090331
  //genspaXS = new G4GeneralSpaceNNCrossSection();

  pipElNucXS = new G4BGGPionElasticXS(G4PionPlus::PionPlus() );
  pipElNucXS->BuildPhysicsTable(*(G4PionPlus::PionPlus() ) );
  
  pimElNucXS = new G4BGGPionElasticXS(G4PionMinus::PionMinus() );
  pimElNucXS->BuildPhysicsTable(*(G4PionMinus::PionMinus() ) );

  pipInelNucXS = new G4BGGPionInelasticXS(G4PionPlus::PionPlus() );
  pipInelNucXS->BuildPhysicsTable(*(G4PionPlus::PionPlus() ) );

  pimInelNucXS = new G4BGGPionInelasticXS(G4PionMinus::PionMinus() );
  pimInelNucXS->BuildPhysicsTable(*(G4PionMinus::PionMinus() ) );

  meanField = new LocalQMDMeanField();
  collision = new LocalQMDCollision();

  excitationHandler = new G4ExcitationHandler;
  excitationHandler->SetDeexChannelsType( fCombined );
  //excitationHandler->SetDeexChannelsType( fEvaporation );
  //fEvaporation - 8 default channels
  //fCombined    - 8 default + 60 GEM
  //fGEM         - 2 default + 66 GEM
  evaporation = new G4Evaporation;
  excitationHandler->SetEvaporation( evaporation );
  setEvaporationCh();

  coulomb_collision_gamma_proj = 0.0;
  coulomb_collision_rx_proj = 0.0;
  coulomb_collision_rz_proj = 0.0;
  coulomb_collision_px_proj = 0.0;
  coulomb_collision_pz_proj = 0.0;
  
  coulomb_collision_gamma_targ = 0.0;
  coulomb_collision_rx_targ = 0.0;
  coulomb_collision_rz_targ = 0.0;
  coulomb_collision_px_targ = 0.0;
  coulomb_collision_pz_targ = 0.0;
  
  secID = G4PhysicsModelCatalog::GetModelID( "model_QMDModel" );
  //RMF = false;
    
  G4cout << "LocalQMDReaction::LocalQMDReaction -- end" << G4endl;
}

LocalQMDReaction::~LocalQMDReaction()
{
   delete evaporation; 
   delete excitationHandler;
   delete collision;
   delete meanField;
}

G4HadFinalState* LocalQMDReaction::ApplyYourself( const G4HadProjectile & projectile , G4Nucleus & target )
{
  //G4cout << "LocalQMDReaction::ApplyYourself -- start" << G4endl;
  clock_t start = clock();
  theParticleChange.Clear();
  //G4double init_elab;
  G4double bvalue;
  system = new LocalQMDSystem;

  G4int proj_Z = 0;
  G4int proj_A = 0;
  const G4ParticleDefinition* proj_pd = ( const G4ParticleDefinition* ) projectile.GetDefinition();
  if ( proj_pd->GetParticleType() == "nucleus" )
    {
      proj_Z = proj_pd->GetAtomicNumber();
      proj_A = proj_pd->GetAtomicMass();
    }
  else
    {
      proj_Z = (int)( proj_pd->GetPDGCharge()/eplus );
      proj_A = 1;
    }
  G4int targ_Z = target.GetZ_asInt();
  G4int targ_A = target.GetA_asInt();
  const G4ParticleDefinition* targ_pd = G4IonTable::GetIonTable()->GetIon( targ_Z , targ_A , 0.0 );

  //G4cout << "target: " << targ_A << ", " << targ_Z << " projectile: " << proj_A << ", " << proj_Z <<G4endl;

  //G4NistManager* nistMan = G4NistManager::Instance();
  //   G4Element* G4NistManager::FindOrBuildElement( targ_Z );

  const G4DynamicParticle* proj_dp = new G4DynamicParticle ( proj_pd , projectile.Get4Momentum() );
  //const G4Element* targ_ele =  nistMan->FindOrBuildElement( targ_Z ); 
  //G4double aTemp = projectile.GetMaterial()->GetTemperature();
  //G4cout << "LocalQMDReaction::ApplyYourself 1" << G4endl;

  ////////////////////
  // For proton projectile, the proton and target should be exchanged in the GG xs.
  // For proton target and projectile A < 40, the proton and target should be exchanged in the GG xs.
  G4DynamicParticle particle_projectile;
  G4double KineticEnergy = targ_A*proj_dp->GetKineticEnergy()/proj_A*MeV;
  //G4double KineticEnergy = targ_A*200*MeV; // criteria; use XS in 200 MeV/A for bvalue 
  particle_projectile.SetKineticEnergy(KineticEnergy);
  particle_projectile.SetDefinition(targ_pd);
  G4HadProjectile proton_targ(particle_projectile);
  const G4DynamicParticle* proton_targ_pd = new G4DynamicParticle ( targ_pd , proton_targ.Get4Momentum() );


  G4DynamicParticle particle_projectile1;
  G4double KineticEnergy1 = proj_A*200*MeV; // criteria; use XS in 200 MeV/A for bvalue 
  particle_projectile1.SetKineticEnergy(KineticEnergy1);
  particle_projectile1.SetDefinition(proj_pd);
  G4HadProjectile proton_targ1(particle_projectile1);
  const G4DynamicParticle* proj_dp1 = new G4DynamicParticle ( proj_pd , proton_targ1.Get4Momentum() );
  ///////////////////
  
  //090331
  //G4VCrossSectionDataSet* theXS_shen = shenXS;

  //G4double xs_1 = theXS_shen->GetIsoCrossSection ( proj_dp , targ_Z , targ_A );
  G4double xs_0 = theXS->GetElementCrossSection( proj_dp , targ_Z , projectile.GetMaterial() );
  //G4double xs_0 = theXS->GetElementCrossSection( proj_dp1 , targ_Z , proton_targ1.GetMaterial() );
  G4double xs_1 = theXS->GetElementCrossSection( proton_targ_pd , proj_Z , proton_targ.GetMaterial() );
  if ((proj_Z == 1 && proj_A == 1) && targ_A > 39) xs_0 = xs_1;
  if ((targ_Z == 1 && targ_A == 1) && targ_A < 40) xs_0 = xs_1;

  // When the projectile is a pion
  if (proj_pd == G4PionPlus::PionPlus() ) {
    xs_0 = pipElNucXS->GetElementCrossSection(proj_dp, targ_Z, projectile.GetMaterial() ) +
      pipInelNucXS->GetElementCrossSection(proj_dp, targ_Z, projectile.GetMaterial() );
  } else if (proj_pd == G4PionMinus::PionMinus() ) {
    xs_0 = pimElNucXS->GetElementCrossSection(proj_dp, targ_Z, projectile.GetMaterial() ) +
      pimInelNucXS->GetElementCrossSection(proj_dp, targ_Z, projectile.GetMaterial() );
  }
  else if (proj_pd == G4PionZero::PionZero() ) {
    xs_0 = 0.5*(pipElNucXS->GetElementCrossSection(proj_dp, targ_Z, projectile.GetMaterial() )
		+ pipInelNucXS->GetElementCrossSection(proj_dp, targ_Z, projectile.GetMaterial() )
		+ pimElNucXS->GetElementCrossSection(proj_dp, targ_Z, projectile.GetMaterial() )
		+ pimInelNucXS->GetElementCrossSection(proj_dp, targ_Z, projectile.GetMaterial() ))
      ; // for pi0 as secondaries
  }
  //if ( proj_pd->GetParticleType() == "meson" ) theXS = piNucXS;

  //G4double xs_0 = genspaXS->GetCrossSection ( proj_dp , targ_ele , aTemp );
  //G4double xs_0 = theXS->GetCrossSection ( proj_dp , targ_ele , aTemp );
  //110822 
   

  G4double bmax_0 = std::sqrt( xs_0 / pi );
  //std::cout << "GG xs_0 [b] " <<  xs_0/fermi/fermi/100 << " "  << xs_1/fermi/fermi/100 << std::endl;
  //exit(0);
  /*
    std::cout << "GG xs_0 [b] " <<  xs_0/fermi/fermi/100 << " Shen xs_1 [b] " <<  xs_1/fermi/fermi/100 <<std::endl;
    G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
    const G4ParticleDefinition* pro = particleTable->FindParticle("proton");
    const G4ParticleDefinition* neu = particleTable->FindParticle("neutron");
    
    G4HadronNucleonXsc* HadN = new G4HadronNucleonXsc();
    G4double xsc = HadN->HadronNucleonXscNS(pro, pro, 400)/fermi/fermi;
    std::cout << "Proton mass " << pro->GetPDGMass() << "Neutron mass " << neu->GetPDGMass() << " " << xsc << std::endl;
    exit(0);
  */
  //delete proj_dp; 

  G4bool elastic = true;

  //std::vector< LocalQMDNucleus_RMF* > nucleuses; // Secondary nuceluses
  std::vector< LocalQMDNucleus* > nucleuses; // Secondary nuceluses

    
  G4ThreeVector boostToReac; // ReactionSystem (CM or NN);
  G4ThreeVector boostBackToLAB; // Reaction System to LAB; 

  //G4cout << "LocalQMDReaction::ApplyYourself 2" << " " << targ_pd->GetPDGMass() << G4endl;
  G4LorentzVector targ4p( G4ThreeVector( 0.0 ) , targ_pd->GetPDGMass()/GeV );
  G4ThreeVector boostLABtoCM = targ4p.findBoostToCM( proj_dp->Get4Momentum()/GeV ); // CM of target and proj;
  //G4cout << boostLABtoCM << G4endl;

  G4double p1 = proj_dp->GetMomentum().mag()/GeV/proj_A; 
  G4double m1 = proj_dp->GetDefinition()->GetPDGMass()/GeV/proj_A;
  G4double e1 = std::sqrt( p1*p1 + m1*m1 ); 
  G4double e2 = targ_pd->GetPDGMass()/GeV/targ_A;
  G4double beta_nn = -p1 / ( e1+e2 );
    
  G4ThreeVector boostLABtoNN ( 0. , 0. , beta_nn ); // CM of NN; 

  G4double beta_nncm = ( - boostLABtoCM.beta() + boostLABtoNN.beta() ) / ( 1 - boostLABtoCM.beta() * boostLABtoNN.beta() ) ;  
  //G4cout << "LocalQMDReaction::ApplyYourself 4" << G4endl;

  //std::cout << targ4p << std::endl; 
  //std::cout << proj_dp->Get4Momentum()<< std::endl; 
  //std::cout << beta_nncm << std::endl; 
  G4ThreeVector boostNNtoCM( 0. , 0. , beta_nncm ); // 
  G4ThreeVector boostCMtoNN( 0. , 0. , -beta_nncm ); // 

  boostToReac = boostLABtoNN; 
  boostBackToLAB = -boostLABtoNN; 

  delete proj_dp; 

  //std::vector < G4ThreeVector > coulomb_repulsion;
  //  std::vector < G4double > coulomb_value;
    
  //std::vector < G4double > nucpote_allsystem;

  //G4double totale_afterdecay = 0.0;
  //G4double totale_afterdecay_NN = 0.0;
  //G4double totale_beforedecay_NN = 0.0;
  //G4double totale = 0.0;
  //G4double totale_2 = 0.0;
  //G4LorentzVector totalp4_afterdecay (0,0,0,0);
  //G4LorentzVector totalp4_afterdecay_NN (0,0,0,0);
  //G4LorentzVector totalp4 (0,0,0,0);
  G4int icounter = 0;
  G4int icounter_max = 1024;
  //G4double ebefore = 0.0;
  //G4LorentzVector p40_before (0,0,0,0);
  //G4LorentzVector p40_before_NN (0,0,0,0);
  //G4LorentzVector p40_beforedecay_NN (0,0,0,0);
  //G4LorentzVector p40_afterdecay_NN (0,0,0,0);
  //icounter_max = 100000; //yoshi
  //ofstream ofs("bvalue.csv",std::ios::app); //yoshi
  //ofstream ofs("bvalue.csv"); //yoshi
  //ofs << "bvalue,elastic" << endl; //yoshi
  //ofstream ofs_b0("bmax_0.csv"); //yoshi
  //ofs_b0 << "bmax_0" << endl; //yoshi
  while ( elastic ) // Loop checking, 11.03.2015, T. Koi
    {
      icounter++;
      if ( icounter > icounter_max ) { 
	G4cout << "Loop-counter exceeded the threshold value at " << __LINE__ << "th line of " << __FILE__ << "." << G4endl;
	break;
      }

      // impact parameter 
      //G4double bmax = 1.05*(bmax_0/fermi);  // 10% for Peripheral reactions
      envelopF = env_parameter;
      G4double bmax = envelopF*(bmax_0/fermi);
 
      G4double rmax_from_bnn = std::abs(beta_nn)*20.0; // collision at 20 fm/c, bnn means relative velocity in NN (20250125)
      if(rmax_from_bnn < bmax_0/fermi/2) rmax_from_bnn = bmax_0/fermi/2;
      //if(rmax_from_bnn < 4.0) rmax_from_bnn = 4.0;
      maxTime = rmax_from_bnn/std::abs(beta_nn) * maxT_parameter/delT_parameter;
      // We don't see NN collision after 15 steps from mid collision 
      G4double maxCollisionTime = (rmax_from_bnn/std::abs(beta_nn) + 15) /delT_parameter;
      if ( (projectile.GetDefinition()->GetParticleName() == "proton"
	    || projectile.GetDefinition()->GetParticleName() == "neutron") &&
	   (targ_pd->GetParticleName()  == "proton"
	    || targ_pd->GetParticleName()  == "neutron")) bmax =  envelopF*1.323142; // same value is used in NN Collision
        
      G4double b = bmax * std::sqrt ( G4UniformRand() );
      //G4double b = 30;
      bvalue = b;
      //G4double b = bmax * 10;
      //G4cout << icounter << " fm, b = " << b  << " fm " << " bnn " << rmax_from_bnn << " bmax " << bmax << " maxT " << maxTime << " final T " << maxTime*delT_parameter << G4endl;
//071112
      //G4double b = bmax;
      //G4double b = bmax/1.05 * 0.7 * G4UniformRand();

      //G4cout << "LocalQMDRESULT bmax_0 = " << bmax_0/fermi << " fm, bmax = " << bmax << " fm , b = " << b  << " fm " << G4endl;

      G4double plab = projectile.GetTotalMomentum()/GeV;
      G4double elab = ( projectile.GetKineticEnergy() + proj_pd->GetPDGMass() + targ_pd->GetPDGMass() )/GeV;
      //init_elab = elab*1000;
      /*
      // Energy conservation check; Coulomb energy in point like nucleus
      G4double rmax0 = rmax_from_bnn * 2.0;
      G4double rmax = std::sqrt( rmax0*rmax0 + b*b );
      G4double ccoul = 0.001439767; // alpha hbar c in GeV fm
      G4cout << (projectile.GetKineticEnergy() + proj_pd->GetPDGMass())/GeV << " targ " << targ_pd->GetPDGMass()/GeV << " Coulomb " << ccoul/rmax*targ_Z*proj_Z << G4endl;
      */
      calcOffSetOfCollision( b , proj_pd , targ_pd , plab , elab , bmax , boostCMtoNN, rmax_from_bnn );

// Projectile
      G4LorentzVector proj4pLAB = projectile.Get4Momentum()/GeV;
       
       
      LocalQMDGroundStateNucleus* proj(NULL);
      if ( projectile.GetDefinition()->GetParticleType() == "nucleus" 
	   || projectile.GetDefinition()->GetParticleName() == "proton"
	   || projectile.GetDefinition()->GetParticleName() == "neutron" )
	{
	  //proj_Z = proj_pd->GetAtomicNumber();
	  //proj_A = proj_pd->GetAtomicMass();

          proj = new LocalQMDGroundStateNucleus( proj_Z , proj_A );
          meanField->SetSystem (proj);
                    
          if ( proj_A != 1 ) proj->CalEnergyAndAngularMomentumInCM();
          

	}
       
      // Target
      G4int iz = int ( target.GetZ_asInt() );
      G4int ia = int ( target.GetA_asInt() );

      LocalQMDGroundStateNucleus* targ = new LocalQMDGroundStateNucleus( iz , ia );
      //targ->ShowParticipants();
      //G4cout << "iz " << iz << ", ia " <<  ia << G4endl;
      //exit(0);
      meanField->SetSystem (targ );
      //targ->SetTotalPotential( meanField->GetTotalPotential() );
      if ( ia != 1 ) targ->CalEnergyAndAngularMomentumInCM();

      for ( G4int i = 0 ; i < targ->GetTotalNumberOfParticipant() ; i++ )
	{

	  G4ThreeVector p0 = targ->GetParticipant( i )->GetMomentum();
	  G4ThreeVector r0 = targ->GetParticipant( i )->GetPosition();
          //pt0 += p0/targ->GetTotalNumberOfParticipant();
          //rt0 += r0/targ->GetTotalNumberOfParticipant();
          //G4cout << pt0 << " " << rt0 << " " << G4endl;
	  G4ThreeVector p ( p0.x() + coulomb_collision_px_targ 
			    , p0.y() 
			    , p0.z() * coulomb_collision_gamma_targ + coulomb_collision_pz_targ ); 

	  G4ThreeVector r ( r0.x() + coulomb_collision_rx_targ 
			    , r0.y() 
			    , r0.z() / coulomb_collision_gamma_targ + coulomb_collision_rz_targ ); 
     
	  system->SetParticipant( new LocalQMDParticipant( targ->GetParticipant( i )->GetDefinition() , p , r ) );
	  system->GetParticipant( i )->SetTarget();
          
	}

      
      // create nucleus from devided clusters
      //std::vector < LocalQMDNucleus* > testboost;
      //LocalQMDNucleus* test_nucleus = new LocalQMDNucleus();
       
       
      G4LorentzVector proj4pCM = CLHEP::boostOf ( proj4pLAB , boostToReac );
      G4LorentzVector targ4pCM = CLHEP::boostOf ( targ4p , boostToReac );
      //G4cout << proj4pLAB << " " << targ4p.e()+proj4pLAB.e() << " " << init_elab << G4endl;
      //exit(0);
      //system->ShowParticipants();
//    Projectile
      //if ( proj != NULL )
      if ( proj_A != 1 )
	{

	  //    projectile is nucleus

	  for ( G4int i = 0 ; i < proj->GetTotalNumberOfParticipant() ; i++ )
	    {

	      G4ThreeVector p0 = proj->GetParticipant( i )->GetMomentum();
	      G4ThreeVector r0 = proj->GetParticipant( i )->GetPosition();
	      
	      G4ThreeVector p ( p0.x() + coulomb_collision_px_proj 
				, p0.y() 
				, p0.z() * coulomb_collision_gamma_proj + coulomb_collision_pz_proj ); 
	      
	      G4ThreeVector r ( r0.x() + coulomb_collision_rx_proj 
				, r0.y() 
				, r0.z() / coulomb_collision_gamma_proj + coulomb_collision_rz_proj ); 
	      
	      //G4ThreeVector p (0,0,p0.z()+ coulomb_collision_pz_proj);
	      //G4ThreeVector r (0,0,r0.z()+ coulomb_collision_rz_proj);
	      
	      system->SetParticipant( new LocalQMDParticipant( proj->GetParticipant( i )->GetDefinition() , p  , r ) );
	      system->GetParticipant ( i + targ->GetTotalNumberOfParticipant() )->SetProjectile();
	      //test_nucleus->SetParticipant( system->GetParticipant ( i + targ->GetTotalNumberOfParticipant() ) );
	    }
          //G4cout << "boosted nucleus energy " << G4endl;
          //meanField->SetNucleus( test_nucleus );
          //test_nucleus->SetTotalPotential( meanField->GetTotalPotential() );
          //test_nucleus->CalEnergyAndAngularMomentumInCM();
          //G4cout << "boosted nucleus energy -- end " << G4endl;
          //G4cout << "excitation energy " << test_nucleus->GetExcitationEnergy() << G4endl;
          //exit(0);
	}
      else
	{

	  //       projectile is particle
	  
	  // avoid multiple set in "elastic" loop
	  if ( system->GetTotalNumberOfParticipant() == targ->GetTotalNumberOfParticipant() )
	    {
	      
	      G4int i = targ->GetTotalNumberOfParticipant(); 
	      
	      G4ThreeVector p0( 0 ); 
	      G4ThreeVector r0( 0 );
	      
	      G4ThreeVector p ( p0.x() + coulomb_collision_px_proj 
				, p0.y() 
				, p0.z() * coulomb_collision_gamma_proj + coulomb_collision_pz_proj ); 
	      
	      G4ThreeVector r ( r0.x() + coulomb_collision_rx_proj 
				, r0.y() 
				, r0.z() / coulomb_collision_gamma_proj + coulomb_collision_rz_proj ); 
	      
	      system->SetParticipant( new LocalQMDParticipant( (G4ParticleDefinition*)projectile.GetDefinition() , p , r ) );
	      // This is not important becase only 1 projectile particle.
	      system->GetParticipant ( i )->SetProjectile();
	    }
	  
	}
      //if(system->GetTotalNumberOfParticipant()!=13) system->ShowParticipants();
      //system->ShowParticipants();
      //exit(0);
      delete targ;
      delete proj;

      meanField->SetSystem ( system );
      collision->SetMeanField ( meanField );

      ///////////////////////////////////////////////////
      // Time Evolution
      ///////////////////////////////////////////////////
      //std::cout << "Start time evolution " << std::endl;
      //system->ShowParticipants();
      
      // test.csv header
      //ofstream ofs("test.csv");
      //ofs << "time" << "," << "particleNo" << "," << "particleName" << "," << "x" << "," << "y" << "," << "z" << "," << "px" << "," << "py" << "," << "pz" << endl;
      // -- end test.csv header
      
      //clock_t end0 = clock();
      //    G4cout << "Before time: " << (double)(end0 - start) / CLOCKS_PER_SEC << "sec. "  <<G4endl;
      //maxTime = 0;
      //G4int nji = system->GetTotalNumberOfParticipant();
      //ebefore = meanField->GetTotalEnergy();
      //p40_before = p40_before*0.0;
      //for ( G4int ji = 0; ji < nji; ji++ )
      //	{
      //	  G4LorentzVector p0 = system->GetParticipant( ji )->Get4Momentum();
      //	  p40_before += p0;
      //	}
      for ( G4int i = 0 ; i < maxTime ; i++ )
	{
	  //G4cout << i << " th time step. " << G4endl;
	  //G4cout << " do Propagate " << i << " th time step. " << G4endl;
	  //clock_t start = clock();
	  meanField->DoPropagation( delT_parameter );
	  //clock_t end = clock();
	  //G4cout << "Atime: " << (double)(end - start) / CLOCKS_PER_SEC << "sec. " << delT_parameter <<G4endl;
	  //system->ShowParticipants();
	  //start = clock();
	  if  (i < maxCollisionTime) collision->CalKinematicsOfBinaryCollisions( delT_parameter );
	  //end = clock();
	  //G4cout << "Btime: " << (double)(end - start) / CLOCKS_PER_SEC << "sec. " << delT_parameter <<G4endl;
	  //G4cout << "Collision " << system->GetNOCollision() << G4endl;
	  //system->ShowParticipants();
	 
	} // maxTime -- end
      //system->ShowParticipants();
      
      //clock_t end1 = clock();
      //    G4cout << "After time: " << (double)(end1 - start) / CLOCKS_PER_SEC << "sec. "  <<G4endl;       

      /////////////////////////////////////////////////////////
      //std::cout << "Doing Cluster Judgment " << std::endl;
      /////////////////////////////////////////////////////////
      nucleuses = meanField->DoClusterJudgment();
      //std::cout << "Doing Cluster Judgment -- end " << std::endl;
      
      G4int numberOfSecondary = int ( nucleuses.size() ) + system->GetTotalNumberOfParticipant(); 
      //std::cout << "Doing Cluster Judgment -- end " << " nucl.size " << int ( nucleuses.size() ) << " system.participants " << system->GetTotalNumberOfParticipant() << std::endl;
      //exit(0);       

      /*
      ////////////////////////////////////////////////////////
      // Coulomb repulsive potential estimation
      ////////////////////////////////////////////////////////
      // Due to the clustering, the energy conservation may be violated (mainly due to the Coulomb interaction)  
       
      G4ThreeVector r0 (0,0,0);
      G4ThreeVector r1 (0,0,0);
      coulomb_repulsion.resize( numberOfSecondary );
      //coulomb_value.resize( numberOfSecondary );
      for (G4int i = 0; i < numberOfSecondary; i++)
	{
	  coulomb_repulsion[i] = r0;
	  //coulomb_value[i] = 0.0;
	}
      p40_beforedecay_NN = p40_before_NN*0.0;
       
      G4double e0 = 0.0;
      G4double e0_2 = 0.0;
      G4LorentzVector p40 (0,0,0,0);
      G4LorentzVector p41 (0,0,0,0);
      G4double Sum_Coulomb = 0.0;
      totale = 0.0;
      totale_2 = 0.0;
      totalp4 = p40;
      G4double m0 = 0.0;
      G4double m1 = 0.0;
      for (G4int i = 0; i < numberOfSecondary; i++)
      {
      G4int zi = 0;
      G4int ai = 0;
      if ( i < int ( nucleuses.size() ))
      {
      zi = nucleuses[i]->GetAtomicNumber();
      ai = nucleuses[i]->GetMassNumber();
      r0 = nucleuses[i]->GetNucleusPosition();
      e0 = nucleuses[i]->GetTotalEnergy_withMomentum();
      //G4cout << "Z A = " << G4endl;
      m0 = nucleuses[i]->GetNuclearMass()/GeV;
      
      //p40 = nucleuses[i]->Get4Momentum();
      meanField->SetNucleus( nucleuses[i] );
      G4double ex = nucleuses[i]->GetExcitationEnergy()*GeV;
      G4double n_mass = G4IonTable::GetIonTable()->GetIonMass( zi , ai );
      G4LorentzVector n_p4 = nucleuses[i]->Get4Momentum()*GeV;
      
      G4double nu_e = std::sqrt (n_mass*n_mass+n_p4.vect()*n_p4.vect())/GeV;
      G4LorentzVector n_p4CM ( n_p4.vect()/GeV , nu_e );
      p40 = n_p4CM;
      
      e0_2 = nu_e + ex/GeV;
      //G4double n_mass_2 = zi*938.272+(ai-zi)*939.565-G4NucleiProperties::GetBindingEnergy( ai , zi )/GeV;
      //G4cout << "nu_e " << nu_e << " ex " << ex/GeV << " n_mass " << n_mass << " mass " << n_mass_2 << G4endl;
      
      }
      else // proton, neutron
      {
      G4int ji = i - int ( nucleuses.size() );
      G4String particlename = system->GetParticipant( ji )->GetDefinition()->GetParticleName();
      if(particlename == "proton" || particlename == "pi+") zi = 1;
      r0 = system->GetParticipant( ji )->GetPosition();
      e0 = system->GetParticipant( ji )->Get4Momentum().e();
      e0_2 = e0;
      p40 = system->GetParticipant( ji )->Get4Momentum();
      m0 = system->GetParticipant( ji )->GetMass();
      }
      
      for (G4int j = i+1; j < numberOfSecondary; j++)
      {
      G4int zj = 0;
      G4int aj = 0;
      if ( j < int ( nucleuses.size() ))
      {
      zj = nucleuses[j]->GetAtomicNumber();
      aj = nucleuses[j]->GetMassNumber();
      r1 = nucleuses[j]->GetNucleusPosition();
      
      G4double n_mass = G4IonTable::GetIonTable()->GetIonMass( zj , aj );
      G4LorentzVector n_p4 = nucleuses[j]->Get4Momentum()*GeV;
      G4double nu_e = std::sqrt (n_mass*n_mass+n_p4.vect()*n_p4.vect())/GeV;
      G4LorentzVector n_p4CM ( n_p4.vect()/GeV , nu_e );
      p41 = n_p4CM;
      m1 = n_mass/GeV;
      }
      else
      {
      G4int ji = j - int ( nucleuses.size() );
      G4String particlename = system->GetParticipant( ji )->GetDefinition()->GetParticleName();
      if(particlename == "proton" || particlename == "pi+") zj = 1;
      r1 = system->GetParticipant( ji )->GetPosition();
      p41 = system->GetParticipant( ji )->Get4Momentum();
      m1 = p41.m()/GeV;
      }
      
      G4ThreeVector bij = ( p40 + p41 ).boostVector();
      G4double gammaij = ( p40 + p41 ).gamma();
      G4double  gamma2_ij = gammaij*gammaij;
      G4ThreeVector rij = r0 - r1;
      G4double rbrb = rij*bij;
      G4double diff_R = std::sqrt(rij*rij + gamma2_ij * rbrb*rbrb);
      G4double CoulombE = zi*zj*0.001439767/diff_R;
      //G4double pvconb = std::sqrt(CoulombE*CoulombE+2.0*CoulombE*(m0+m1));
      //coulomb_repulsion[i] += rij/std::sqrt(rij*rij)*pvconb/2.0;
      //coulomb_repulsion[j] += -rij/std::sqrt(rij*rij)*pvconb/2.0;
      if(diff_R>2.0)
      {
      coulomb_repulsion[i] += rij*CoulombE/(diff_R*diff_R);
      coulomb_repulsion[j] += -rij*CoulombE/(diff_R*diff_R);
      Sum_Coulomb += CoulombE;
      }
      //G4cout << "i, j = " << i << ", " << j << " Diff: " << diff_R << " Coulomb " << Sum_Coulomb*1000 << " repulsive " << coulomb_repulsion[i] << " " << m0+m1 <<G4endl;
	 }
       totale += e0;
       totale_2 += e0_2;
       totalp4 += p40;
       p40_beforedecay_NN = totalp4;
       //G4cout << "i-th particle " << i << " K Momentum: " << (e0-m0)*1000 << " e0 "<< e0*1000 << " totale " << totale << " totale_2 " << totale_2 << G4endl;
       //G4cout << "i-th particle " << i << " K Momentum: " << (e0-m0)*1000 << " Coulomb "<< Sum_Coulomb*1000 << G4endl; ///////////////// 2022.03.22
       }
     
       //for (G4int i = 0; i < numberOfSecondary; i++)
       //{
       //  coulomb_repulsion[i] = coulomb_repulsion[i]/std::sqrt(coulomb_repulsion[i]*coulomb_repulsion[i]);
	// G4double p_coul = 0;
	// G4int zi = 0;
	// G4int ai = 0;
	// if ( i < int ( nucleuses.size() ))
	// {
	// zi = nucleuses[i]->GetAtomicNumber();
	// ai = nucleuses[i]->GetMassNumber();
	// r0 = nucleuses[i]->GetNucleusPosition();
	// e0 = nucleuses[i]->GetTotalEnergy_withMomentum();
	// //G4cout << "Z A = " << G4endl;
	// m0 = nucleuses[i]->GetNuclearMass()/GeV;
	 
	// //p40 = nucleuses[i]->Get4Momentum();
	// meanField->SetNucleus( nucleuses[i] );
	// G4double ex = nucleuses[i]->GetExcitationEnergy()*GeV;
	// G4double n_mass = G4IonTable::GetIonTable()->GetIonMass( zi , ai );
	// G4LorentzVector n_p4 = nucleuses[i]->Get4Momentum()*GeV;
	// G4double xb = n_p4.vect()*coulomb_repulsion[i];
	// G4double EE = (n_p4.e()-n_mass);
	// p_coul = -xb + std::sqrt(xb*xb - n_mass*n_mass + 2*EE*n_mass);
	// }
       ////G4cout << "i-th particle " << i << " Coulomb repalsive: " << coulomb_repulsion[i] << G4endl;
       //}
       
       // check delta E #2
       // G4cout << "Diff. energy2 " << (totale-ebefore)*1000 << " total p4 " << totalp4 << " p4diff " << p40_beforedecay_NN - p40_before << G4endl; ///////////////// 2022.03.22
       //exit(0);
       */
      ////////////////////////////////////////////
      // Elastic Judgment
      ////////////////////////////////////////////
      G4int sec_a_Z = 0;
      G4int sec_a_A = 0;
      const G4ParticleDefinition* sec_a_pd = NULL;
      G4int sec_b_Z = 0;
      G4int sec_b_A = 0;
      const G4ParticleDefinition* sec_b_pd = NULL;

      if ( numberOfSecondary == 2 )
	{

	  G4bool elasticLike_system = false;
	  if ( nucleuses.size() == 2 ) 
	    {
	   
	      sec_a_Z = nucleuses[0]->GetAtomicNumber();
	      sec_a_A = nucleuses[0]->GetMassNumber();
	      sec_b_Z = nucleuses[1]->GetAtomicNumber();
	      sec_b_A = nucleuses[1]->GetMassNumber();
	      
	      //G4cout << "sec_a_Z " << sec_a_Z << " sec_a_A " << sec_a_A << " sec_b_Z " << sec_b_Z << " sec_b_A " << sec_b_A << G4endl;
	      //G4cout << "proj_Z " << proj_Z << " proj_A " << proj_A << " targ_Z " << targ_Z << " targ_A " << targ_A << G4endl;
          
	      if ( ( sec_a_Z == proj_Z && sec_a_A == proj_A && sec_b_Z == targ_Z && sec_b_A == targ_A )
		   || ( sec_a_Z == targ_Z && sec_a_A == targ_A && sec_b_Z == proj_Z && sec_b_A == proj_A ) )
		{
		  elasticLike_system = true;
		}
	      else // Added by A.H.
		{
		  elastic = false;
		}
	      
	    }
	  else if ( nucleuses.size() == 1 ) 
	    {
	      
	      sec_a_Z = nucleuses[0]->GetAtomicNumber();
	      sec_a_A = nucleuses[0]->GetMassNumber();
	      sec_b_pd = system->GetParticipant( 0 )->GetDefinition();
	      
	      if ( ( sec_a_Z == proj_Z && sec_a_A == proj_A && sec_b_pd == targ_pd )
		   || ( sec_a_Z == targ_Z && sec_a_A == targ_A && sec_b_pd == proj_pd ) )
		{
		  elasticLike_system = true;
		} 
	    }
	  else
	    {
	      
	      sec_a_pd = system->GetParticipant( 0 )->GetDefinition();
	      sec_b_pd = system->GetParticipant( 1 )->GetDefinition();
	      
	      if ( ( sec_a_pd == proj_pd && sec_b_pd == targ_pd ) 
		   || ( sec_a_pd == targ_pd && sec_b_pd == proj_pd ) ) 
		{
		  elasticLike_system = true;
		  //G4cout << "elasticLike_system = false " << G4endl;
		  
		  if ( (proj_pd->GetParticleName() == "proton" && targ_pd->GetParticleName()  == "proton")
		       || (proj_pd->GetParticleName() == "neutron" && targ_pd->GetParticleName()  == "proton")
		       || (proj_pd->GetParticleName() == "proton" && targ_pd->GetParticleName()  == "neutron")
		       || (proj_pd->GetParticleName() == "pi+" && targ_pd->GetParticleName()  == "proton")
		       || (proj_pd->GetParticleName() == "pi-" && targ_pd->GetParticleName()  == "proton")
		       || (proj_pd->GetParticleName() == "pi0" && targ_pd->GetParticleName()  == "proton"))
		    {
		      elasticLike_system = false;
		      //G4cout << "elasticLike_system = false proton NOCollision " << system->GetNOCollision() << G4endl;
		      if ( system->GetNOCollision() == 1 || icounter+900 > icounter_max) elastic = false;
		    }
		} 
	    }
	  
	  if ( elasticLike_system == true )
	    {
	      
	      G4bool elasticLike_energy = true;
	      //    Cal ExcitationEnergy 
	      for ( G4int i = 0 ; i < int ( nucleuses.size() ) ; i++ )
		{
		  //meanField->SetSystem( nucleuses[i] );
		  meanField->SetNucleus( nucleuses[i] );
		  //nucleuses[i]->SetTotalPotential( meanField->GetTotalPotential() );
		  //nucleuses[i]->CalEnergyAndAngularMomentumInCM();
		  
		  if ( nucleuses[i]->GetExcitationEnergy()*GeV > 1.0*MeV ) elasticLike_energy = false;
		  //G4cout << "excitation energy " << nucleuses[i]->GetExcitationEnergy() << G4endl;
		}
	      //    Check Collision
	      G4bool withCollision = true;
	      if ( system->GetNOCollision() == 0 ) withCollision = false;
	      
	      //    Final judegement for Inelasitc or Elastic;
	      //
	      //       ElasticLike without Collision 
	      //if ( elasticLike_energy == true && withCollision == false ) elastic = true;  // ielst = 0
	      //       ElasticLike with Collision 
	      //if ( elasticLike_energy == true && withCollision == true ) elastic = true;   // ielst = 1 
	      //       InelasticLike without Collision 
	      //if ( elasticLike_energy == false ) elastic = false;                          // ielst = 2                
	      if ( frag == true )
		if ( elasticLike_energy == false ) elastic = false;
	      //       InelasticLike with Collision
	      if ( elasticLike_energy == false && withCollision == true ) elastic = false; // ielst = 3
	      //elastic = false;
	    }
	  
	  // 20240713 particle is droped if elastic = true and particle-nucleus reaction
	  if ((elastic) && int ( nucleuses.size() ) == 1)
	    {
	      for ( G4int iii = 0; iii < int ( nucleuses.size()); ++iii)
		{
		  meanField->SetNucleus( nucleuses[iii] );
		  G4int nnn = nucleuses[iii]->GetTotalNumberOfParticipant();
		  G4ThreeVector r_nuc = nucleuses[iii]->GetNucleusPosition();
		  //G4cout << iii << " n " << nnn << " " << r_nuc << G4endl;
		  G4double rmax_par = 0.0;
		  G4int rmax_i = nnn+1;
		  G4ThreeVector p_maxp = G4ThreeVector( 0.0 );
		  G4ThreeVector r_maxp = G4ThreeVector( 0.0 );
		  for ( G4int iiii = 0; iiii < nnn; ++iiii)
		    {
		      G4ThreeVector r_par =nucleuses[iii]->GetParticipant( iiii )->GetPosition();
		      G4ThreeVector p_par =nucleuses[iii]->GetParticipant( iiii )->GetMomentum();
		      //G4cout << iiii << " " << r_par << " " << nucleuses[iii]->GetParticipant( iiii )->GetDefinition() <<G4endl;
		      G4double rdiff = (r_nuc - r_par)*(r_nuc - r_par);
		      if(rmax_par < rdiff)
			{
			  rmax_par = rdiff;
			  rmax_i = iiii;
			  p_maxp = p_par;
			  r_maxp = r_par;
			}
		    }
		  if(nucleuses[iii]->GetMassNumber() != 2)
		    {
		      LocalQMDNucleus* test_nucleus = new LocalQMDNucleus();
		      for ( G4int iiii = 0; iiii < nnn; ++iiii)
			{
			  if(iiii == rmax_i)
			    {
			      system->SetParticipant(  new LocalQMDParticipant(nucleuses[iii]->GetParticipant(iiii)->GetDefinition() , p_maxp , r_maxp) );
			    }
			  else
			    {
			      test_nucleus->SetParticipant( nucleuses[iii]->GetParticipant(iiii));
			    }
			}
		      nucleuses[iii] = test_nucleus;
		      //G4cout << icounter << " " << bvalue << " " << iii << " n " << nnn << " (rmax_par,i) " << rmax_par << "," << rmax_i << G4endl;
		      //G4cout << " nucl.size " << int ( nucleuses.size() ) << " system.participants " << system->GetTotalNumberOfParticipant() << std::endl;
		    }
		}
	      //exit(0);
	      elastic = false;
	    } // drop  --end
	  
	  //G4cout << "Collision NO: " << system->GetNOCollision() << " elastic: " << elastic << " frag: " << frag << G4endl;
	  for ( G4int i = 0 ; i < int ( nucleuses.size() ) ; i++ )
	    {
	      meanField->SetNucleus( nucleuses[i] );
	      //G4cout << "i " << i << " " << nucleuses[i]->GetAtomicNumber() << " " << nucleuses[i]->GetMassNumber() << " excitation energy " << nucleuses[i]->GetExcitationEnergy()*1000 << G4endl;
	    }
	  
	} // elasticLike_system == true
      else
	{
	  
	  //       numberOfSecondary != 2 
	  elastic = false;
	  /*
	    for ( G4int i = 0 ; i < int ( nucleuses.size() ) ; i++ )
	    {
	    meanField->SetNucleus( nucleuses[i] );
	    G4cout << "i " << i << " excitation energy " << nucleuses[i]->GetExcitationEnergy()<< G4endl;
	    nucleuses[i]->CalEnergyAndAngularMomentumInCM();
	    G4cout << "numberOfSecondary != 2 "
	    << nucleuses[i]->GetAtomicNumber()
	    << " "
	    << nucleuses[i]->GetMassNumber()
	    //<< " "
	    //<< nucleuses[i]->Get4Momentum()
	    //<< nucleuses[i]->Get4Momentum()
	    << " "
	    << nucleuses[i]->Get4Momentum().vect().mag()
	    //<< " "
	    //<< nucleuses[i]->Get4Momentum().restMass()
	    //<< " "
	    //<< nucleuses[i]->GetNuclearMass()/GeV
	    << " "
	    << nucleuses[i]->GetNucleusPosition()
	    << G4endl;
	    }
	    exit(0);
	  */
	}
      
      //071115
      //G4cout << elastic << G4endl;
      // if elastic is true try again from sampling of impact parameter 
      
      //ofs << bvalue << "," << elastic <<endl; //yoshi
      //elastic = true; //yoshi force loop


      if ( elastic == true )
	{
	  for ( std::vector< LocalQMDNucleus* >::iterator
		  it = nucleuses.begin() ; it != nucleuses.end() ; it++ )
	    {
	      delete *it;
	    }
	  nucleuses.clear();
	  //nucpote_allsystem.clear();
	  //coulomb_repulsion.clear();
	  //coulomb_value.clear();
	  system->Clear();
	  system->ResetCollisionCounter();
	}
    } // while(elastic)
  //exit(0);

  // random rotation
  G4double randAzimuthAngle = 2.0 * pi * G4UniformRand();
  G4LorentzRotation randRotZ;
  randRotZ.rotateZ( randAzimuthAngle );
  ///////////////////////////////////////////////////////////
  // Statical Decay Phase
  ///////////////////////////////////////////////////////////
  G4int itj = 0;
  for ( std::vector< LocalQMDNucleus* >::iterator it
	  = nucleuses.begin() ; it != nucleuses.end() ; it++ )
    {
      
      meanField->SetNucleus ( *it );
 
      G4int ia = (*it)->GetMassNumber();
      G4int iz = (*it)->GetAtomicNumber();
      
      G4double excitationE = (*it)->GetExcitationEnergy()*GeV;  // added by A. H.
      //G4double it_mass = (*it)->GetNuclearMass();
      G4double it_mass = G4IonTable::GetIonTable()->GetIonMass( iz , ia );
      G4LorentzVector it_p4 = (*it)->Get4Momentum()*GeV;
      //G4ThreeVector crep = coulomb_repulsion[itj]*GeV;
      
      G4ThreeVector itpp = it_p4.vect();// + crep;
      G4double itpp_mag = std::sqrt (itpp*itpp);
      G4double nucleus_e = std::sqrt (it_mass*it_mass+itpp*itpp)/GeV;
      G4LorentzVector nucleus_p4CM ( itpp/GeV , nucleus_e );
      //std::cout << excitationE << " z:" << iz << " a:" << ia << " coulmb: " << crep <<std::endl;  ///////////////// 2022.03.22
      if(excitationE < 0.0) // added by A. H.
        {
	  if ( (nucleus_e*GeV + excitationE) > it_mass)
            {
	      G4double ratio_p = std::sqrt ( (nucleus_e*GeV + excitationE)*(nucleus_e*GeV + excitationE)-it_mass*it_mass)/(itpp_mag);
            
	      nucleus_e = std::sqrt (it_mass*it_mass+itpp*itpp*ratio_p*ratio_p)/GeV;
	      G4LorentzVector nucleus_p4CM_mod ( itpp*ratio_p/GeV , nucleus_e );
	      nucleus_p4CM = nucleus_p4CM_mod;
	      //nucleus_e = std::sqrt (it_mass*it_mass+removed_p3*removed_p3)/GeV;
	      //G4LorentzVector nucleus_p4CM ( removed_p3/GeV , nucleus_e );
	      //std::cout << "Ratio_p " << ratio_p << " " << nucleus_e*GeV - std::sqrt (it_mass*it_mass+itpp*itpp) << " " << it_mass << " " << it_p4.vect().mag() << " coulmb " << crep << std::endl; ///////////////// 2022.03.22
	      excitationE = 0.0;
            }
	  
	  else
            {
	      nucleus_e = it_mass/GeV;
	      G4LorentzVector nucleus_p4CM_mod ( itpp*0.0/GeV , nucleus_e );
	      nucleus_p4CM = nucleus_p4CM_mod;
	      excitationE = 0.0;
            }
             
	  excitationE = 0.0;
        }
      //std::cout << nucleus_p4CM <<std::endl;
      nucleus_p4CM = randRotZ * nucleus_p4CM; // random rotation
      //std::cout << randRotZ <<std::endl;
      //std::cout << nucleus_p4CM <<std::endl;

      //G4double rotation = CLHEP::twopi*G4UniformRand();
      //G4ThreeVector rit(0.,0.,1.);
      //nucleus_p4CM.rotate(rotation,rit);
      //std::cout << nucleus_p4CM <<std::endl;
      //exit(0);

      //p40_afterdecay_NN += nucleus_p4CM;
      //std::cout << excitationE << " " << it_mass << " " << " location: " << (*it)->GetNucleusPosition() << " p4 " << p40_afterdecay_NN << " itp4 "<< it_p4.vect().mag() << " coulmb " << crep <<std::endl;
      G4LorentzVector lv ( G4ThreeVector( 0.0 ) , excitationE + it_mass);
      
      /*
      // original
      if ( (*it)->GetAtomicNumber() == 0  // neutron cluster
      || (*it)->GetAtomicNumber() == (*it)->GetMassNumber() ) // proton cluster
      {
      // push back system
      for ( G4int i = 0 ; i < (*it)->GetTotalNumberOfParticipant() ; i++ )
      {
      LocalQMDParticipant* aP = new LocalQMDParticipant( ( (*it)->GetParticipant( i ) )->GetDefinition() , ( (*it)->GetParticipant( i ) )->GetMomentum() , ( (*it)->GetParticipant( i ) )->GetPosition() );
      system->SetParticipant ( aP );
      }
      continue;
      }
      G4double nucleus_e = std::sqrt ( G4Pow::GetInstance()->powN ( (*it)->GetNuclearMass()/GeV , 2 ) + G4Pow::GetInstance()->powN ( (*it)->Get4Momentum().vect().mag() , 2 ) );
      G4LorentzVector nucleus_p4CM ( (*it)->Get4Momentum().vect() , nucleus_e );
      G4LorentzVector lv ( G4ThreeVector( 0.0 ) , (*it)->GetExcitationEnergy()*GeV + G4IonTable::GetIonTable()->GetIonMass( iz , ia ) );
      // -- end
      */
            
      G4Fragment* aFragment = new G4Fragment( ia , iz , lv );
      //std::cout << "Z, A: " << iz << " " << ia << std::endl;
      //excitationHandler->SetDeexChannelsType( fEvaporation );
      //evaporation->SetDefaultChannel();
      G4ReactionProductVector* rv;
      rv = excitationHandler->BreakItUp( *aFragment );
        
      G4bool notBreak = true;
      for ( G4ReactionProductVector::iterator itt
	      = rv->begin() ; itt != rv->end() ; itt++ )
        {
	  notBreak = false;
	  // Secondary from this nucleus (*it)
	  const G4ParticleDefinition* pd = (*itt)->GetDefinition();
                
	  G4LorentzVector p4 ( (*itt)->GetMomentum()/GeV , (*itt)->GetTotalEnergy()/GeV );  //in nucleus(*it) rest system
	  G4LorentzVector p4_CM = CLHEP::boostOf( p4 , -nucleus_p4CM.findBoostToCM() );  // Back to CM
	  G4LorentzVector p4_LAB = CLHEP::boostOf( p4_CM , boostBackToLAB ); // Back to LAB
	  //std::cout << "Particle Name " << pd->GetParticleName() << std::endl;
	  //exit(0);
	  //std::cout << "p4 " << p4 << std::endl;
	  //std::cout << "p4_CM " << p4_CM << std::endl;
	  //std::cout << "p4_LAB " << p4_LAB << std::endl;
	  //totale_afterdecay_NN += p4_CM.e();
	  //totalp4_afterdecay_NN += p4_CM;
	  //090122
	  //theParticleChange.AddSecondary( dp );
	  if ( !( pd->GetAtomicNumber() == 4 && pd->GetAtomicMass() == 8 ) )
            {
	      //G4cout << "pd out of notBreak loop : " << pd->GetParticleName() << G4endl;
	      G4DynamicParticle* dp = new G4DynamicParticle( pd , p4_LAB*GeV );
	      theParticleChange.AddSecondary( dp );
            }
	  else
            {
	      //Be8 -> Alpha + Alpha + Q
	      G4ThreeVector randomized_direction( G4UniformRand() , G4UniformRand() , G4UniformRand() );
	      randomized_direction = randomized_direction.unit();
	      G4double q_decay = (*itt)->GetMass() - 2*G4Alpha::Alpha()->GetPDGMass();
	      G4double p_decay = std::sqrt ( G4Pow::GetInstance()->powN(G4Alpha::Alpha()->GetPDGMass()+q_decay/2,2) - G4Pow::GetInstance()->powN(G4Alpha::Alpha()->GetPDGMass() , 2 ) );
	      G4LorentzVector p4_a1 ( p_decay*randomized_direction , G4Alpha::Alpha()->GetPDGMass()+q_decay/2 );  //in Be8 rest system
              
	      G4LorentzVector p4_a1_Be8 = CLHEP::boostOf ( p4_a1/GeV , -p4.findBoostToCM() );
	      G4LorentzVector p4_a1_CM = CLHEP::boostOf ( p4_a1_Be8 , -nucleus_p4CM.findBoostToCM() );
	      G4LorentzVector p4_a1_LAB = CLHEP::boostOf ( p4_a1_CM , boostBackToLAB );
              
	      G4LorentzVector p4_a2 ( -p_decay*randomized_direction , G4Alpha::Alpha()->GetPDGMass()+q_decay/2 );  //in Be8 rest system
              
	      G4LorentzVector p4_a2_Be8 = CLHEP::boostOf ( p4_a2/GeV , -p4.findBoostToCM() );
	      G4LorentzVector p4_a2_CM = CLHEP::boostOf ( p4_a2_Be8 , -nucleus_p4CM.findBoostToCM() );
	      G4LorentzVector p4_a2_LAB = CLHEP::boostOf ( p4_a2_CM , boostBackToLAB );
              
	      G4DynamicParticle* dp1 = new G4DynamicParticle( G4Alpha::Alpha() , p4_a1_LAB*GeV );
	      G4DynamicParticle* dp2 = new G4DynamicParticle( G4Alpha::Alpha() , p4_a2_LAB*GeV );
	      theParticleChange.AddSecondary( dp1 );
	      theParticleChange.AddSecondary( dp2 );
            }
            //090122
            //G4cout
            //<< "Regist Secondary "
            //<< (*itt)->GetDefinition()->GetParticleName()<< G4endl;
            /*
                G4cout
                 << "Regist Secondary "
                 << (*itt)->GetDefinition()->GetParticleName()
                 << " "
                 << (*itt)->GetMomentum()/GeV
                 << " "
                 << (*itt)->GetKineticEnergy()/GeV
                 << " "
                 << (*itt)->GetMass()/GeV
                 << " "
                 << (*itt)->GetTotalEnergy()/GeV
                 << " "
                 << (*itt)->GetTotalEnergy()/GeV * (*itt)->GetTotalEnergy()/GeV
                 - (*itt)->GetMomentum()/GeV * (*itt)->GetMomentum()/GeV
                 << " "
                 << nucleus_p4CM.findBoostToCM()
                 << " "
                 << p4
                 << " "
                 << p4_CM
                 << " "
                 << p4_LAB
                 << G4endl;
            */
                
        }
      if ( notBreak == true )
        {
                
	  const G4ParticleDefinition* pd = G4IonTable::GetIonTable()->GetIon( (*it)->GetAtomicNumber() , (*it)->GetMassNumber(), (*it)->GetExcitationEnergy()*GeV );
	  G4cout << "pd in notBreak loop : " << pd->GetParticleName() << G4endl;
	  G4LorentzVector p4_CM = nucleus_p4CM;
	  G4LorentzVector p4_LAB = CLHEP::boostOf( p4_CM , boostBackToLAB ); // Back to LAB
	  G4DynamicParticle* dp = new G4DynamicParticle( pd , p4_LAB*GeV );
	  theParticleChange.AddSecondary( dp );
          
        }
      
      for ( G4ReactionProductVector::iterator itt
	      = rv->begin() ; itt != rv->end() ; itt++ )
        {
	  delete *itt;
        }
      delete rv;
      delete aFragment;
      itj += 1;
    }
    
    
    G4int nn = system->GetTotalNumberOfParticipant();
    
    for ( G4int i = 0 ; i < nn ; i++ )
      {
	// Secondary particles 
      
	const G4ParticleDefinition* pd = system->GetParticipant( i )->GetDefinition();
	G4LorentzVector p4_CM0 = system->GetParticipant( i )->Get4Momentum();
	
	//G4ThreeVector crep = coulomb_repulsion[itj];
	G4ThreeVector itpp = p4_CM0.vect();//+crep;
	G4double itpp_ener = std::sqrt (itpp*itpp+p4_CM0.m()*p4_CM0.m());
	//G4LorentzVector p4_CM (p4_CM0.vect()+crep,itpp_ener);
	G4LorentzVector p4_CM (p4_CM0.vect(),itpp_ener);
	p4_CM = randRotZ * p4_CM; // random rotation
	//G4ThreeVector itpp = it_p4.vect() + crep;
	//G4double itpp_mag = std::sqrt (itpp*itpp);
	
	//totale_afterdecay_NN += p4_CM.e();
	//totale_beforedecay_NN += p4_CM.e();
	//totalp4_afterdecay_NN += p4_CM;
	//p40_afterdecay_NN += p4_CM;
	//if (i == system->GetTotalNumberOfParticipant()-1)
	//{
	//    p4_CM.vect() = p4_CM.vect() - (totalp4_afterdecay_NN.vect()-p40_before.vect());
	//}
	G4LorentzVector p4_LAB = CLHEP::boostOf( p4_CM , boostBackToLAB );
	G4DynamicParticle* dp = new G4DynamicParticle( pd , p4_LAB*GeV );  
	theParticleChange.AddSecondary( dp ); 
	//G4cout << "In the last theParticleChange loop : " << pd->GetParticleName() << " p4CM " << p4_CM << G4endl;
	/*
	  G4cout << "LocalQMDRESULT "
	  << "r" << i << " " << system->GetParticipant ( i ) -> GetPosition() << " "
	  << "p" << i << " " << system->GetParticipant ( i ) -> Get4Momentum()
	  << G4endl;
	*/
	//G4cout << "Energy conservation : " << totale-totale_afterdecay_NN << " totale_afterdecay_NN " << totale_afterdecay_NN << G4endl;
	//G4cout << "eEnergy conservation : " << (totale_afterdecay_NN-ebefore)*1000 << G4endl; ///////////////// 2022.03.22
	//G4cout << "momumtum conservation : " << totalp4_afterdecay_NN-p40_before << G4endl;
	//G4cout << "momumtum conservation : " << totalp4_afterdecay_NN-p40_beforedecay_NN << G4endl;
	//G4cout << "momumtum conservation : " << p40_afterdecay_NN-p40_beforedecay_NN << G4endl;
	//G4cout << "p_beforedecay_NN : " << totale_beforedecay_NN << " p_afterdecay_NN: " << totale_afterdecay_NN << G4endl;
	itj += 1;
      }
    
    for ( std::vector< LocalQMDNucleus* >::iterator it
	    = nucleuses.begin() ; it != nucleuses.end() ; it++ )
      {
	//meanField->SetNucleus( *it );
	//G4cout << "it excitation energy " << (*it)->GetExcitationEnergy() << G4endl;
	delete *it;  // delete nulceuse
      }
    
    nucleuses.clear();
    //nucpote_allsystem.clear();
    //coulomb_repulsion.clear();
    //coulomb_value.clear();
    system->Clear();
    delete system; 
    
    theParticleChange.SetStatusChange( stopAndKill );
    
    G4int n = theParticleChange.GetNumberOfSecondaries();
    for (G4int i = 0; i < n; i++)
      {      
	//theParticleChange.GetSecondary(i)->SetCreatorModelID(1111);
	//theParticleChange.GetSecondary(i)->SetCreatorModelType(1111);
	theParticleChange.GetSecondary(i)->SetCreatorModelID(secID);
      }
    
    return &theParticleChange;
    
}



void LocalQMDReaction::calcOffSetOfCollision( G4double b ,
					      const G4ParticleDefinition* pd_proj ,
					      const G4ParticleDefinition* pd_targ ,
					      G4double ptot , G4double etot , G4double bmax , G4ThreeVector boostToCM, G4double rmax_from_bnn )
{
  
  G4double mass_proj = pd_proj->GetPDGMass()/GeV;
  G4double mass_targ = pd_targ->GetPDGMass()/GeV;
  
  G4double stot = std::sqrt ( etot*etot - ptot*ptot );
  
  G4double pstt = std::sqrt ( ( stot*stot - ( mass_proj + mass_targ ) * ( mass_proj + mass_targ ) 
				) * ( stot*stot - ( mass_proj - mass_targ ) * ( mass_proj - mass_targ ) ) ) 
    / ( 2.0 * stot );
  
   G4double pzcc = pstt;
   G4double eccm = stot - ( mass_proj + mass_targ );
   //G4cout << "eccm " << eccm << " etot " << etot << " stot " << stot << " mtot " << mass_proj + mass_targ <<  " pzcc " << pzcc <<G4endl;
   
   G4int zp = 1;
   G4int ap = 1;
   if ( pd_proj->GetParticleType() == "nucleus" )
   {
     zp = pd_proj->GetAtomicNumber();
     ap = pd_proj->GetAtomicMass();
   }
   else 
     {
       // proton, neutron, mesons
       //zp = int ( pd_proj->GetPDGCharge()/eplus + 0.5 ); // wrong for negative charge (pi- etc.)
       zp = (int)( pd_proj->GetPDGCharge()/eplus ); //
       //G4cout << zp << pd_proj->GetParticleName() << G4endl;
       // ap = 1;
     }
   
   
   G4int zt = pd_targ->GetAtomicNumber();
   G4int at = pd_targ->GetAtomicMass();


   // Check the ramx0 value
   //G4double rmax0 = 8.0;  // T.K dicide parameter value  // for low energy
   //G4double rmax0 = bmax + 4.0;
   G4double rmax0 = rmax_from_bnn * 2.0;
   G4double rmax = std::sqrt( rmax0*rmax0 + b*b );

   G4double ccoul = 0.001439767; // alpha hbar c in GeV fm
   G4double pcca = 1.0 - double ( zp * zt ) * ccoul / eccm / rmax - ( b / rmax )*( b / rmax );

   G4double pccf = std::sqrt( pcca );

   //Fix for neutral particles
   G4double aas1 = 0.0;
   G4double bbs = 0.0;

   if ( zp != 0 )
     {
       G4double aas = 2.0 * eccm * b / double ( zp * zt ) / ccoul;
       bbs = 1.0 / std::sqrt ( 1.0 + aas*aas );
       aas1 = ( 1.0 + aas * b / rmax ) * bbs;
     }

   G4double cost = 0.0;
   G4double sint = 0.0;
   G4double thet1 = 0.0;
   G4double thet2 = 0.0;
   if ( 1.0 - aas1*aas1 <= 0 || 1.0 - bbs*bbs <= 0.0 )   
     {
       cost = 1.0;
       sint = 0.0;
     } 
   else 
     {
       G4double aat1 = aas1 / std::sqrt ( 1.0 - aas1*aas1 );
       G4double aat2 = bbs / std::sqrt ( 1.0 - bbs*bbs );
       
       thet1 = std::atan ( aat1 );
       thet2 = std::atan ( aat2 );

//    TK enter to else block  
       G4double theta = thet1 - thet2;
       cost = std::cos( theta );
       sint = std::sin( theta );
     }

   //G4double rzpr = -rmax * cost * ( mass_targ ) / ( mass_proj + mass_targ );
   //G4double rzta =  rmax * cost * ( mass_proj ) / ( mass_proj + mass_targ );
   G4double rzpr = -rmax * cost /2.0;
   G4double rzta =  rmax * cost /2.0;
   
   G4double rxpr = rmax / 2.0 * sint;
   
   G4double rxta = -rxpr;


   G4double pzpc = pzcc * (  cost * pccf + sint * b / rmax );
   G4double pxpr = pzcc * ( -sint * pccf + cost * b / rmax );

   G4double pztc = - pzpc;
   G4double pxta = - pxpr;

   G4double epc = std::sqrt ( pzpc*pzpc + pxpr*pxpr + mass_proj*mass_proj );
   G4double etc = std::sqrt ( pztc*pztc + pxta*pxta + mass_targ*mass_targ );

   G4double pzpr = pzpc;
   G4double pzta = pztc;
   G4double epr = epc;
   G4double eta = etc;

// CM -> NN
   G4double gammacm = boostToCM.gamma();
   //G4double betacm = -boostToCM.beta();
   G4double betacm = boostToCM.z();
   pzpr = pzpc + betacm * gammacm * ( gammacm / ( 1. + gammacm ) * pzpc * betacm + epc );
   pzta = pztc + betacm * gammacm * ( gammacm / ( 1. + gammacm ) * pztc * betacm + etc );
   epr = gammacm * ( epc + betacm * pzpc );
   eta = gammacm * ( etc + betacm * pztc );
   //G4cout << "betacm " << boostToCM << G4endl;
   //exit(0);
   //G4double betpr = pzpr / epr;
   //G4double betta = pzta / eta;

   G4double gammpr = epr / ( mass_proj );
   G4double gammta = eta / ( mass_targ );
   //G4cout << "gammpr " << gammpr << " gammta " << gammta << G4endl;
   pzta = pzta / double ( at );
   pxta = pxta / double ( at );
      
   pzpr = pzpr / double ( ap );
   pxpr = pxpr / double ( ap );

   G4double zeroz = 0.0; 

   rzpr = rzpr -zeroz;
   rzta = rzta -zeroz;

   // Set results 
   coulomb_collision_gamma_proj = gammpr;
   coulomb_collision_rx_proj = rxpr;
   coulomb_collision_rz_proj = rzpr;
   coulomb_collision_px_proj = pxpr;
   coulomb_collision_pz_proj = pzpr;

   coulomb_collision_gamma_targ = gammta;
   coulomb_collision_rx_targ = rxta;
   coulomb_collision_rz_targ = rzta;
   coulomb_collision_px_targ = pxta;
   coulomb_collision_pz_targ = pzta;

}



void LocalQMDReaction::setEvaporationCh()
{

   if ( gem == true )
      evaporation->SetGEMChannel();
   else
      evaporation->SetDefaultChannel();
}

void LocalQMDReaction::ModelDescription(std::ostream& outFile) const
{
   outFile << "Lorentz covarianted Quantum Molecular Dynamics model for nucleus (particle) vs nucleus reactions\n";
}
