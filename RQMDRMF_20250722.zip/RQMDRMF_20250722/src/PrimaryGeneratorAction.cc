#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <time.h>

#include "PrimaryGeneratorAction.hh"
#include "DetectorConstruction.hh"

#include "G4RunManager.hh"
#include "G4Event.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ChargedGeantino.hh"
#include "G4IonTable.hh"
#include "G4ParticleDefinition.hh"
#include "Randomize.hh"

using namespace std;
using namespace CLHEP;
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PrimaryGeneratorAction::PrimaryGeneratorAction()
{
    G4int n_particle = 1;
    particleGun  = new G4ParticleGun(n_particle);
    Detector = (DetectorConstruction*)

    G4RunManager::GetRunManager()->GetUserDetectorConstruction();

    // default particle kinematic
    G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
    //G4IonTable* ionTable = G4IonTable::GetIonTable();
    G4String particleName;
    G4ParticleDefinition* particle = particleTable->FindParticle("chargedgeantino");
    particleGun->SetParticleDefinition(particle);
    //G4int Z=6, A=12;
    //G4double ionCharge = 6.*eplus;
    //G4double excitEnergy= 0.*keV;
    //G4ParticleDefinition* ion = ionTable->GetIon(Z,A,excitEnergy,0);
    //particleGun->SetParticleDefinition(ion);
    //particleGun->SetParticleCharge(ionCharge);
    particleGun->SetParticleMomentumDirection(G4ThreeVector(0.,-1.,0.));
    particleGun->SetParticleEnergy(400.*MeV);
    G4double xposition = 0.*mm;
    G4double yposition = 0.*mm;
    particleGun->SetParticlePosition(G4ThreeVector(xposition,yposition,0.*mm));

    //rndmFlag = "off";
    rndmFlag = "on";

    ifstream fene("PhaseSpaceFile_XVI_Energy.txt");
    double e0,e1,e2;
    while(fene >> e0 >> e1 >> e2){
        Emin  .push_back(e0);
        Emax  .push_back(e1);
        EneFra.push_back(e2);
    }
    ifstream fpos("PhaseSpaceFile_XVI_Position.txt");
    double p0,p1,p2,p3;
    while(fpos >> p0 >> p1 >> p2 >> p3){
        Pmin  .push_back(p0);
        Pmax  .push_back(p1);
        PosxFr.push_back(p2);
        PoszFr.push_back(p3);
        //cout<< p0 <<" "<< p1<<" "<<p2<<" "<<p3<<endl;
    }
    ifstream fang("PhaseSpaceFile_XVI_Angle.txt");
    double a0,a1,a2,a3;
    while(fang >> a0 >> a1 >> a2 >> a3){
        PX.push_back(a0);
        PX.push_back(a1);
        PZ.push_back(a2);
        PZ.push_back(a3);
    }

    long seed = time(NULL);
    CLHEP::HepRandom::setTheSeed(seed);
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
    delete particleGun;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
    /*
    //this function is called at the begining of event
    G4double pi = 3.14159265358979323846;
    G4double Energy =   -1.  *keV;
    G4double PosX   =   -999.*cm;
    G4double PosZ   =   -999.*cm;
    G4double MomX   =   -999.;
    G4double MomZ   =   -999.;
    G4double MomY   =   -1.;

    if (rndmFlag == "on"){ //for random
        bool    isE=false,isX=false,isZ=false;
        while(!isE){
            Energy   = G4UniformRand()*(Emax.back()-Emin.front())+Emin.front();
            for(int i=0;i<EneFra.size();i++){
                if((Emin.at(i)<Energy)&&(Energy<Emax.at(i))){
                    double fraction = G4UniformRand();
                    if(fraction<EneFra.at(i)){
                        isE=true;
                    }
                }
            }
        }
        while(!isX){
            PosX   = G4UniformRand()*(Pmax.back()-Pmin.front())+Pmin.front();
            for(int i=0;i<PosxFr.size();i++){
                if((Pmin.at(i)<PosX)&&(PosX<Pmax.at(i))){
                    double fraction = G4UniformRand();
                    if(fraction<PosxFr.at(i)){
                        isX=true;
                        MomX = -1*tan((PX.at(0)+PX.at(1)*PosX)*pi/180.);
                    }
                }
            }
        }
        while(!isZ){
            PosZ   = G4UniformRand()*(Pmax.back()-Pmin.front())+Pmin.front();
            for(int i=0;i<PoszFr.size();i++){
                if((Pmin.at(i)<PosZ)&&(PosZ<Pmax.at(i))){
                    double fraction = G4UniformRand();
                    if(fraction<PoszFr.at(i)){
                        isZ=true;
                        MomZ = -1*tan((PZ.at(0)+PZ.at(1)*PosZ)*pi/180.);
                    }
                }
            }
        }
    }
    */
    
    G4double Energy =   400.  *MeV;
    G4double PosX   =   0.*cm;
    G4double PosY   =   -70*cm;
    G4double PosZ   =   0.*cm;
    G4double MomX   =   0.;
    G4double MomZ   =   0.;
    G4double MomY   =   -1.;
    
    G4double momentum = sqrt(pow(MomX,2)+pow(MomY,2)+pow(MomZ,2));

    G4ParticleDefinition* particle = particleGun->GetParticleDefinition();
    
    G4int Z = 6, A = 12;
    G4double ionCharge   = 6.*eplus;
    G4double excitEnergy = 0.*keV;
    if (particle == G4ChargedGeantino::ChargedGeantino()) {
        //Carbon
        G4ParticleDefinition* ion
        = G4IonTable::GetIonTable()->GetIon(Z,A,excitEnergy);
        particleGun->SetParticleDefinition(ion);
        particleGun->SetParticleCharge(ionCharge);
        G4cout << "Projectile Charge = " << Z << ", Mass = " << A << G4endl;
    }
    
    /*
    G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
    //G4GenericIon::GenericIon();
    G4IonTable* ionTable = G4IonTable::GetIonTable();
    //G4String particleName;
    //G4ParticleDefinition* particle = particleTable->FindParticle(particleName="e-");
    //particleGun->SetParticleDefinition(particle);

    G4int Z=6, A=12;
    G4double ionCharge = 6.*eplus;
    G4double excitEnergy= 0.*keV;
    G4ParticleDefinition* ion = ionTable->GetIon(Z,A,excitEnergy,0);
    particleGun->SetParticleDefinition(ion);
    particleGun->SetParticleCharge(ionCharge);
     */
    particleGun->SetParticlePosition(G4ThreeVector(PosX,PosY,PosZ));
    particleGun->SetParticleMomentumDirection(
                G4ThreeVector(MomX/momentum,MomY/momentum,MomZ/momentum));
    
    //particleGun->SetParticleEnergy(120.*keV);
    particleGun->SetParticleEnergy    (Energy*A*MeV);

    particleGun->GeneratePrimaryVertex(anEvent);

}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

