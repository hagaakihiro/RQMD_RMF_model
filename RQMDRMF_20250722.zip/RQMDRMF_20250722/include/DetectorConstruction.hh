//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
// $Id: DetectorConstruction.hh,v 1.1 2010-10-18 15:56:17 maire Exp $
// GEANT4 tag $Name: not supported by cvs2svn $
//
// 

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#ifndef DetectorConstruction_h
#define DetectorConstruction_h 1

#include "G4VUserDetectorConstruction.hh"
#include "globals.hh"

class G4Box;
class G4Cons;
class G4Tubs;
class G4UnionSolid;
class G4SubtractionSolid;
class G4LogicalVolume;
class G4VPhysicalVolume;
class G4Material;
class G4UniformMagField;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class DetectorConstruction : public G4VUserDetectorConstruction
{
  public:
  
    DetectorConstruction();
   ~DetectorConstruction();

  public:
     
	   void SetTargetFilmMaterial       (G4String);
	   void SetTargetMountMaterial      (G4String);
	   void SetTargetBaseMaterial       (G4String);
	   void SetLeadConeMaterial         (G4String);
	   void SetFilter1Material          (G4String);
	   void SetFilter2Material          (G4String);
	   void SetFilter3Material          (G4String);
	   void SetClampRingMaterial        (G4String);
	   void SetPrimColMaterial          (G4String);
	   void SetShieldingLeadMaterial    (G4String);
	   void SetShieldingBracketMaterial (G4String);
	   void SetLeadCollimeterMaterial   (G4String);
	   void SetCassettleWindowMaterial  (G4String);
	   void SetBowtieFilterMaterial  (G4String);
	   void SetDetectorMaterial         (G4String);
	   void SetPhantomMaterial          (G4String);
		 void GetPhantomPosandSize        (G4double& ix, G4double& iy, G4double& iz)const{ ix=Phantomposition; iy = PhantomSizeXY; iz = PhantomSizeZ;}
		 void GetNumberOfSegmentsInPhantom(G4int   & nx, G4int   & ny, G4int   & nz)const{ nx=PhantomXCells;   ny = PhantomYCells; nz = PhantomZCells;}

     void SetMagField(G4double);
     
     G4VPhysicalVolume* Construct();

     void UpdateGeometry();
     
  public:
  
     G4double GetWorldSizeZX()                    {return WorldSizeZX;}; 
     G4double GetWorldSizeY()                     {return WorldSizeY;};
     
		 const G4VPhysicalVolume* GetVirtualDetector(){return physiVirtualDetector;};
		 const G4VPhysicalVolume* GetWaterPhantom()   {return physiWaterPhantom;};
                 
  private:
		 G4double SSD;
		 G4double PhantomSizeXY  ;
		 G4double PhantomSizeZ   ;
		 G4double Phantomposition;
		 G4double PhantomXCells;
		 G4double PhantomYCells;
		 G4double PhantomZCells;

		 G4Material*        TargetFilmMaterial;
		 G4Material*        TargetMountMaterial;
		 G4Material*        TargetBaseMaterial;
		 G4Material*        LeadConeMaterial;
		 G4Material*        Filter1Material;
		 G4Material*        Filter2Material;
		 G4Material*        Filter3Material;
		 G4Material*        ClampRingMaterial;
		 G4Material*        PrimColMaterial;
		 G4Material*        ShieldingLeadMaterial;
		 G4Material*        ShieldingBracketMaterial;
		 G4Material*        LeadCollimeterMaterial;
		 G4Material*        CassettleWindowMaterial;
		 G4Material*        BowtieFilterMaterial;
		 G4Material*        DetectorMaterial;
		 G4Material*        PhantomMaterial;
     
     G4Material*        defaultMaterial;
     G4double           WorldSizeZX;
		 G4double           WorldSizeY;

		 G4Box*             solidWorld;                    //pointer to the solid    World 
		 G4LogicalVolume*   logicWorld;                    //pointer to the logical  World
		 G4VPhysicalVolume* physiWorld;                    //pointer to the physical World

		 ////////////////////// Target ///////////////////////////
		 G4Box*             solidTarget;                   //pointer to the solid    Target 
		 G4LogicalVolume*   logicTarget;                   //pointer to the logical  Target
		 G4VPhysicalVolume* physiTarget;                   //pointer to the physical Target
		 G4Cons*            solidTargetFilm;               //pointer to the solid    Target 
		 G4LogicalVolume*   logicTargetFilm;               //pointer to the logical  Target
		 G4VPhysicalVolume* physiTargetFilm;               //pointer to the physical Target
		 G4Cons*            solidTargetMount1;             //pointer to the solid    Target 
		 G4LogicalVolume*   logicTargetMount1;             //pointer to the logical  Target
		 G4VPhysicalVolume* physiTargetMount1;             //pointer to the physical Target
		 G4Tubs*            solidTargetMount2;             //pointer to the solid    Target 
		 G4LogicalVolume*   logicTargetMount2;             //pointer to the logical  Target
		 G4VPhysicalVolume* physiTargetMount2;             //pointer to the physical Target
		 G4Tubs*            solidTargetBase;               //pointer to the solid    Target 
		 G4LogicalVolume*   logicTargetBase;               //pointer to the logical  Target
		 G4VPhysicalVolume* physiTargetBase;               //pointer to the physical Target
		 ////////////////////// LeadConeFilter ///////////////////////////
		 G4Box*              solidConeFilter;              //pointer to the solid    ConeFilter 
		 G4LogicalVolume*    logicConeFilter;              //pointer to the logical  ConeFilter
		 G4VPhysicalVolume*  physiConeFilter;              //pointer to the physical ConeFilter
		 G4Tubs*             solidFilter1;                 //pointer to the solid    ConeFilter 
		 G4LogicalVolume*    logicFilter1;                 //pointer to the logical  ConeFilter
		 G4VPhysicalVolume*  physiFilter1;                 //pointer to the physical ConeFilter
		 G4Tubs*             solidFilter2;                 //pointer to the solid    ConeFilter 
		 G4LogicalVolume*    logicFilter2;                 //pointer to the logical  ConeFilter
		 G4VPhysicalVolume*  physiFilter2;                 //pointer to the physical ConeFilter
		 G4Tubs*             solidFilter3;                 //pointer to the solid    ConeFilter 
		 G4LogicalVolume*    logicFilter3;                 //pointer to the logical  ConeFilter
		 G4VPhysicalVolume*  physiFilter3;                 //pointer to the physical ConeFilter
		 G4Cons*             solidLCone1;                  //pointer to the solid    ConeFilter 
		 G4SubtractionSolid* solidLCone2;                  //pointer to the solid    ConeFilter 
		 G4Tubs*             solidLCone3;                  //pointer to the solid    ConeFilter 
		 G4UnionSolid*       solidLCone4;                  //pointer to the solid    ConeFilter 
		 G4Box*              solidLConeWindow;             //pointer to the solid    ConeFilter 
		 G4Tubs*             solidLConeBase;               //pointer to the solid    ConeFilter 
		 G4UnionSolid*       solidLCone;                   //pointer to the solid    ConeFilter 
		 G4LogicalVolume*    logicLCone;                   //pointer to the logical  ConeFilter
		 G4VPhysicalVolume*  physiLCone;                   //pointer to the physical ConeFilter
		 ////////////////////// Primary Collimeter ///////////////////////////
		 G4Box*              solidClampRingWindow;         //pointer to the solid    ClampRing 
		 G4Tubs*             solidClampRingBase;           //pointer to the solid    ClampRing 
		 G4SubtractionSolid* solidClampRing ;              //pointer to the solid    ClampRing 
		 G4LogicalVolume*    logicClampRing ;              //pointer to the logical  ClampRing
		 G4VPhysicalVolume*  physiClampRing ;              //pointer to the physical ClampRing
		 G4Box*              solidPrimColWindow;           //pointer to the solid    PrimaryCollimeter 
		 G4Tubs*             solidPrimColBase;             //pointer to the solid    PrimaryCollimeter 
		 G4SubtractionSolid* solidPrimCol ;                //pointer to the solid    PrimaryCollimeter 
		 G4LogicalVolume*    logicPrimCol ;                //pointer to the logical  PrimaryCollimeter
		 G4VPhysicalVolume*  physiPrimCol ;                //pointer to the physical PrimaryCollimeter
		 ////////////////////// Collimeters //////////////////////////////////
		 G4Box*             solidCollimeter;               //pointer to the solid    Collimeter 
		 G4LogicalVolume*   logicCollimeter;               //pointer to the logical  Collimeter
		 G4VPhysicalVolume* physiCollimeter;               //pointer to the physical Collimeter
		 G4Box*              solidShieldingLeadWindow;     //pointer to the solid    Collimeter 
		 G4Box*              solidShieldingLeadBase;       //pointer to the solid    Collimeter 
		 G4SubtractionSolid* solidShieldingLead ;          //pointer to the solid    Collimeter 
		 G4LogicalVolume*    logicShieldingLead ;          //pointer to the logical  Collimeter
		 G4VPhysicalVolume*  physiShieldingLead ;          //pointer to the physical Collimeter
		 G4Box*              solidShieldingBracketWindow;  //pointer to the solid    Collimeter 
		 G4Box*              solidShieldingBracketBase;    //pointer to the solid    Collimeter 
		 G4SubtractionSolid* solidShieldingBracket ;       //pointer to the solid    Collimeter 
		 G4LogicalVolume*    logicShieldingBracket ;       //pointer to the logical  Collimeter
		 G4VPhysicalVolume*  physiShieldingBracket ;       //pointer to the physical Collimeter
		 G4Box*              solidLeadCollimeterWindow;    //pointer to the solid    Collimeter 
		 G4Box*              solidLeadCollimeterBase;      //pointer to the solid    Collimeter 
		 G4SubtractionSolid* solidLeadCollimeter ;         //pointer to the solid    Collimeter 
		 G4LogicalVolume*    logicLeadCollimeter ;         //pointer to the logical  Collimeter
		 G4VPhysicalVolume*  physiLeadCollimeter ;         //pointer to the physical Collimeter
		 G4Box*              solidCassettleWindow1;        //pointer to the solid    Collimeter 
		 G4LogicalVolume*    logicCassettleWindow1;        //pointer to the logical  Collimeter
		 G4VPhysicalVolume*  physiCassettleWindow1;        //pointer to the physical Collimeter
		 G4Box*              solidCassettleWindow2;        //pointer to the solid    Collimeter 
		 G4LogicalVolume*    logicCassettleWindow2;        //pointer to the logical  Collimeter
		 G4VPhysicalVolume*  physiCassettleWindow2;        //pointer to the physical Collimeter
		 G4Box*              solidCassettleWindow3;        //pointer to the solid    Collimeter 
		 G4LogicalVolume*    logicCassettleWindow3;        //pointer to the logical  Collimeter
		 G4VPhysicalVolume*  physiCassettleWindow3;        //pointer to the physical Collimeter
		 G4Box*              solidCassettleWindow4;        //pointer to the solid    Collimeter 
		 G4LogicalVolume*    logicCassettleWindow4;        //pointer to the logical  Collimeter
		 G4VPhysicalVolume*  physiCassettleWindow4;        //pointer to the physical Collimeter
		 G4Box*              solidBowtieFilter;            //pointer to the solid    Collimeter 
		 G4LogicalVolume*    logicBowtieFilter;            //pointer to the logical  Collimeter
		 G4VPhysicalVolume*  physiBowtieFilter;            //pointer to the physical Collimeter

		 ////////////////////// Phantom //////////////////////////////////
		 G4Box*              solidVirtualDetector;         //pointer to the solid    Phantom 
		 G4LogicalVolume*    logicVirtualDetector;         //pointer to the logical  Phantom
		 G4VPhysicalVolume*  physiVirtualDetector;         //pointer to the physical Phantom
		 G4Box*              solidWaterPhantom;            //pointer to the solid    Phantom 
		 G4LogicalVolume*    logicWaterPhantom;            //pointer to the logical  Phantom
		 G4VPhysicalVolume*  physiWaterPhantom;            //pointer to the physical Phantom

     
		 /////////////////////////////////////////////////////////////////
     G4UniformMagField* magField;           //pointer to the magnetic field
  private:
    
     void DefineMaterials();
     G4VPhysicalVolume* ConstructCalorimeter();     
};

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......


#endif

