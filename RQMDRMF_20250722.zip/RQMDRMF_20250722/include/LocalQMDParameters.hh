//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// -------------------------------------------------------------------
//      GEANT4 Class file
//      File name:    LocalQMDParameters.hh
//      Author: Koi, Tatsumi (tkoi@slac.stanford.edu)
//      Creation date: 12 May 2007
//      Modification
//      Author: Akihiro Haga
//      Jan. 2 2022
// -----------------------------------------------------------------------------

#ifndef LocalQMDParameters_hh
#define LocalQMDParameters_hh

#include "globals.hh"

class LocalQMDParameters
{
    static G4ThreadLocal LocalQMDParameters* parameters;
     
    LocalQMDParameters();
    public:
        ~LocalQMDParameters();
        static LocalQMDParameters* GetInstance()
        {
            if ( parameters == NULL ) parameters = new LocalQMDParameters();
            return parameters;
        }


        // GroundStateNucleus
        G4double Get_wl() { return wl; };
        G4double Get_cl() { return cl; };
        G4double Get_hbc() { return hbc; };
        G4double Get_rho0() { return rho0; };
        G4double Get_gamm() { return gamm; };
        G4double Get_cpw() { return cpw; };
        G4double Get_cph() { return cph; };
        G4double Get_epsx() { return epsx; };
        G4double Get_cpc() { return cpc; };
        G4double Get_cs() { return cs; };
        G4double Get_c0() { return c0; };
        G4double Get_c0p() { return c0p; };
        G4double Get_clp() { return clp; };
        G4double Get_c3() { return c3; };
        G4double Get_c3p() { return c3p; };
        G4double Get_csp() { return csp; };
        G4double Get_cdp() { return cdp; };
    
        G4double Get_g0p() { return g0p; }; // Skyrme-QMD
        G4double Get_g0isop() { return g0isop; }; // Skyrme-QMD
        G4double Get_gtau0p() { return gtau0p; };// Skyrme-QMD
    
        G4double Get_eta() { return eta; }; // Skyrme-QMD
        G4double Get_kappas() { return kappas; }; // Skyrme-QMD
        G4double Get_g0() { return g0; }; // Skyrme-QMD
        G4double Get_g0iso() { return g0iso; }; // Skyrme-QMD
        G4double Get_gtau0() { return gtau0; }; // Skyrme-QMD
    
        // as a sensitive parameter
        //isoR ver. yoshi 20230103
        //G4double Get_cluster_radius() { return cluster_radius; };
        G4double Get_cluster_radius_pn() { return cluster_radius_pn; };
        G4double Get_cluster_radius_pp() { return cluster_radius_pp; };
        G4double Get_cluster_radius_nn() { return cluster_radius_nn; };
        G4double Get_alpha_cluster_parameter_a() { return alpha_cluster_parameter_a; };
        G4double Get_alpha_cluster_parameter_b() { return alpha_cluster_parameter_b; };
        G4double Get_maxT_parameter() { return maxT_parameter; };
        G4double Get_delT_parameter() { return delT_parameter; };
        G4double Get_env_parameter() { return env_parameter; };
        // RMF model
        G4double Get_cutoff_s() { return cutoff_s; };
        G4double Get_g_sigma() { return g_sigma; };
        G4double Get_g_sigma2() { return g_sigma2; };
        G4double Get_g_sigma3() { return g_sigma3; };
        G4double Get_g_sigma_bar() { return g_sigma_bar; };
        G4double Get_m_sigma() { return m_sigma; };
        G4double Get_cutoff_v() { return cutoff_v; };
        G4double Get_g_omega() { return g_omega; };
        G4double Get_g_omega_bar() { return g_omega_bar; };
        G4double Get_m_omega() { return m_omega; };
    
        G4double Get_cutoff_r() { return cutoff_r; };
        G4double Get_g_rho() { return g_rho; };
        G4double Get_g_rho_bar() { return g_rho_bar; };
        G4double Get_m_rho() { return m_rho; };
    
        G4bool Get_RMF() {return RMF; };
    
   protected:
        G4double wl;
        G4double cl;
        G4double hbc;
        G4double rho0;
        G4double gamm;

        // as a sensitive parameter
        //isoR ver. yoshi 20230103
        //G4double cluster_radius;
        G4double cluster_radius_pn;
        G4double cluster_radius_pp;
        G4double cluster_radius_nn;
        G4double alpha_cluster_parameter_a;
        G4double alpha_cluster_parameter_b;
        G4double maxT_parameter;
        G4double delT_parameter;
        G4double env_parameter;
/*
      G4double rho0;
      G4double t0;

      G4double aaa;

*/
        // Skyrme-QMD
        G4double gtau0;
        G4double g0;
        G4double g0iso;
        G4double eta;
        G4double kappas;
    
        G4double g0p;
        G4double g0isop;
        G4double gtau0p;
        // MeanField
        G4double c0, c3, cs;

        // GroundStateNucleus
        G4double cpw;
        G4double cph;
        G4double epsx;
        G4double cpc;
        G4double c0p , clp , c3p , csp , cdp;

        G4bool RMF;
        // RMF-QMD
        G4double cutoff_s;
        G4double g_sigma;
        G4double g_sigma2;
        G4double g_sigma3;
        G4double g_sigma_bar;
        G4double m_sigma;
        G4double cutoff_v;
        G4double g_omega;
        G4double g_omega_bar;
        G4double m_omega;
    
        G4double cutoff_r;
        G4double g_rho;
        G4double g_rho_bar;
        G4double m_rho;
};

#endif
