//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <time.h>
#include <omp.h>
#include "G4RunManager.hh"
#include "G4UImanager.hh"

#include "Randomize.hh"
#include "DetectorConstruction.hh"
#include "PhysicsList.hh"
#include "PrimaryGeneratorAction.hh"
#include "RunAction.hh"
#include "EventAction.hh"
#include "SteppingAction.hh"


// For G4QMD
//#include "G4LightIonQMDCollision.hh"
//#include "G4LightIonQMDGroundStateNucleus.hh"
//#include "G4LightIonQMDMeanField.hh"
//#include "G4LightIonQMDNucleus.hh"
//#include "G4LightIonQMDParameters.hh"
//#include "G4QMDParticipant.hh"
//#include "G4LightIonQMDReaction.hh"
//#include "G4QMDSystem.hh"
// For QMD local
#include "LocalQMDCollision.hh"
#include "LocalQMDGroundStateNucleus.hh"
#include "LocalQMDMeanField.hh"
#include "LocalQMDNucleus.hh"
#include "LocalQMDParameters.hh"
#include "LocalQMDParticipant.hh"
#include "LocalQMDReaction.hh"
#include "LocalQMDSystem.hh"

// For BIC for light nuclei
#include "G4BinaryCascade.hh"
#include "G4BinaryLightIonReaction.hh"
#include "G4PreCompoundModel.hh"
#include "G4HadronicInteractionRegistry.hh"

// For INCL
#include "G4INCLXXInterface.hh"

//#include "DicomRegularDetectorConstruction.hh"

#ifdef G4VIS_USE
#include "G4VisExecutive.hh"
#endif

#ifdef G4UI_USE
#include "G4UIExecutive.hh"
#endif

using namespace std;
using namespace CLHEP;

// crosssection.csv
#include <iostream>
#include <fstream>
using std::endl;
using std::ofstream;
// -- crosssection.csv
using std::ifstream;
// -- QMD_input.csv
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

int main(int argc,char** argv)
{
    
    // QMD_input
    G4double read_E;
    G4double read_E0;
    G4double read_VE;
    G4int read_Zp, read_Ap, read_Zt, read_At;
    char nuclemodel[128];
    FILE    *fp;
    if((fp=fopen("QMD_input.csv","r")) == NULL) {
        printf("OPEN FAILED QMD_input.csv \n");
        exit(0);
    }
    fscanf(fp,"%lf,%lf,%d,%d,%d,%d,%s",&read_E0,&read_VE,&read_Zp,&read_Ap,&read_Zt,&read_At,nuclemodel);
    fclose(fp);

    // Choose the Random engine
    CLHEP::HepRandom::setTheEngine(new CLHEP::RanecuEngine);
    CLHEP::HepRandom::setTheSeed(time(NULL));

    read_E = G4RandGauss::shoot(read_E0,read_VE);
    //read_E = ;
    //G4cout << read_E << " " << read_Zp << G4endl;
    //exit(0);

    // Construct the default run manager
    G4RunManager* runManager = new G4RunManager;

    // Set mandatory initialization classes
    runManager->SetUserInitialization(new PhysicsList);
    //G4VUserPhysicsList* physics = new PhysicsList();
    //runManager->SetUserInitialization(physics);
    runManager->SetUserInitialization(new DetectorConstruction);
    //runManager->SetUserInitialization(new DicomRegularDetectorConstruction);
  
    
    //G4cout << "Test runing QMD " << G4endl;
    // Set user action classes
    runManager->SetUserAction(new PrimaryGeneratorAction);
    runManager->SetUserAction(new RunAction  );
    runManager->SetUserAction(new EventAction);
    runManager->SetUserAction(new SteppingAction);
  
    //G4cout << "Test runing QMD " << G4endl;
    // Initialize G4 kernel
    runManager->Initialize();

    G4cout << "Test runing QMD " << G4endl;
    // for static member
    //LocalQMDParameters* parameters = LocalQMDParameters::GetInstance();
    //G4double hbc = parameters->Get_hbc();
    //G4cout << hbc << G4endl;
    
    G4int z = read_Zt;
    G4int a = read_At;
    G4Nucleus targetNucleus( a, z);
    G4cout << "Test runing QMD - target nucleus "  << G4endl;
    G4cout << "number of n: " << targetNucleus.GetN_asInt() << G4endl;
    G4cout << "number of p: " << targetNucleus.GetZ_asInt() << G4endl;
    
    // projectile particle name
    G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
    /*
    G4String particleName="alpha";
    G4cout << "test particle: " << particleName << G4endl;
    G4ParticleDefinition* particle0 = particleTable->FindParticle(particleName);
    G4double pmass = particle0->GetPDGMass();
    G4int Z = particle0->GetAtomicNumber(), A = particle0->GetBaryonNumber();
    G4cout << "Projectile Charge = " << Z << ", Mass = " << A << G4endl;
    */
    /*
    G4String particleName="pi-";
    G4cout << "test particle: " << particleName << G4endl;
    G4ParticleDefinition* particle0 = particleTable->FindParticle(particleName);
    G4double pmass = particle0->GetPDGMass();
    G4int Z = (int)( particle0->GetPDGCharge()/eplus ), A = 1;
    G4cout << "Projectile Charge = " << Z << ", Mass = " << A << G4endl;
    */
    
    //--
    //G4ParticleDefinition* particle0 = particleTable->FindParticle("chargedgeantino");
    //G4int Z = 1, A = 3;
    G4int Z = read_Zp, A = read_Ap;
    G4double ionCharge   = Z *eplus;
    G4double excitEnergy = 0.*keV;
    G4ParticleDefinition* particle0
    = G4IonTable::GetIonTable()->GetIon(Z,A,excitEnergy);
    G4cout << "Projectile Charge = " << Z << ", Mass = " << A << G4endl;
    G4double pmass = particle0->GetPDGMass();
    G4cout << "test ion: " << pmass << " name "<< particle0->GetParticleName() << G4endl;
    
    //exit(0);
    //--
    //G4ParticleDefinition* particle0 = IonTable->FindIon(a, z, 0.0);
    //G4cout << particle0 << G4endl;
    //G4cout << "table " << particleTable << " particle " << particle0 << G4endl;
    
    //
    G4DynamicParticle particle_projectile;
    //particle_projectile = new G4DynamicParticle();
    G4double KineticEnergy = A*read_E*MeV;
    G4double Etot = KineticEnergy+pmass;
    G4double pzz = std::sqrt(Etot*Etot-pmass*pmass);
    G4cout << "pz = " << pzz << ", Etotal = " << Etot << G4endl;
    G4cout << "KineticEnergy = " << KineticEnergy << G4endl;
    //G4LorentzVector proj4pCM( G4ThreeVector(0,0,1) , 0 );
    //particle_projectile.Set4Momentum(proj4pCM);
    //particle_projectile.Set4Momentum(G4LorentzVector(0.,0.,pzz,Etot));
    //G4cout << "KineticEnergy = " << KineticEnergy << G4endl;
    particle_projectile.SetKineticEnergy(KineticEnergy);
    particle_projectile.SetDefinition(particle0);
    
    G4cout << particle_projectile.GetKineticEnergy() << G4endl;
    G4cout << particle_projectile.GetTotalMomentum() << G4endl;
    //exit(0);
    //
    //
    //
    
    //G4DynamicParticle (const G4ParticleDefinition *aParticleDefinition, const G4ThreeVector &aMomentumDirection, G4double aKineticEnergy);
    const G4ParticleDefinition* proj_pd = ( const G4ParticleDefinition* ) particle_projectile.GetDefinition();
    G4cout << "Test runing QMD - projectile type: " << proj_pd->GetParticleType() << G4endl;
    
    G4HadProjectile projectile(particle_projectile);
    G4cout << "Test runing QMD - G4HadProjectile: " << G4endl;
    G4cout << projectile.GetTotalEnergy() << " " << projectile.GetTotalMomentum() << G4endl;
    G4cout << projectile.Get4Momentum() << G4endl;
    
    
    ofstream ofs("crosssection.csv");
    ofs << "event" << "," << "ParticleNO" << "," << "particleName" << "," << "z" << "," << "a" << "," << "px" << ","<< "py" << "," << "pz" << "," << "angle" << "," << "phi" << "," << "kenergy" << "," << "mass" << endl;
    
    
    // For BIC
    G4HadronicInteraction* p =
    G4HadronicInteractionRegistry::Instance()->FindModel("PRECO");
    G4PreCompoundModel* thePreCompound = static_cast<G4PreCompoundModel*>(p);
    if(!thePreCompound) { thePreCompound = new G4PreCompoundModel; }
    G4BinaryLightIonReaction* theIonBC = NULL;
    theIonBC = new G4BinaryLightIonReaction(thePreCompound);
    //G4BinaryCascade* theIonBC = NULL;
    //theIonBC = new G4BinaryCascade(thePreCompound);
    // end
    
    // For INCLXX
    G4INCLXXInterface* theINCL = NULL;
    theINCL = new G4INCLXXInterface(thePreCompound);
    
    LocalQMDReaction* reaction = NULL;
    reaction = new LocalQMDReaction();
    //G4LightIonQMDReaction* reaction = NULL;
    //reaction = new G4LightIonQMDReaction();
    //reaction->UnUseGEM();
    const G4ParticleDefinition* targ_pd = G4IonTable::GetIonTable()->GetIon( z , a , 0.0 );
    int ipmax = 100000;
    clock_t start = clock();
    double startTime = omp_get_wtime();
    for (int ip = 0; ip < ipmax; ip++)
    {
        G4HadFinalState *theParticleChange = reaction->ApplyYourself(projectile, targetNucleus);
        //G4HadFinalState *theParticleChange = theIonBC->ApplyYourself(projectile, targetNucleus);
        //G4HadFinalState *theParticleChange = theINCL->ApplyYourself(projectile, targetNucleus);
        //G4cout << "ip = " << ip <<
        //" number of secondaries " <<
        //theParticleChange->GetNumberOfSecondaries() <<
        //" Energy Change " <<
        //theParticleChange->GetEnergyChange() <<
        //G4endl;
        
        G4double init_elab = projectile.GetTotalEnergy()+targ_pd->GetPDGMass();
        G4double esum = 0.0;
        for (G4int i = 0; i < G4int(theParticleChange->GetNumberOfSecondaries() ); i++)
        {
            G4String particlename = theParticleChange->GetSecondary(i)->GetParticle()->GetParticleDefinition()->GetParticleName();
            G4LorentzVector p4i = theParticleChange->GetSecondary(i)->GetParticle()->Get4Momentum();
            G4int zip = theParticleChange->GetSecondary(i)->GetParticle()->GetParticleDefinition()->GetAtomicNumber();
            G4int aip = theParticleChange->GetSecondary(i)->GetParticle()->GetParticleDefinition()->GetBaryonNumber();
            G4ThreeVector beta_i = p4i.v()/p4i.e();
            G4double pxy = std::sqrt(p4i.v()[0]*p4i.v()[0]+p4i.v()[1]*p4i.v()[1]);
            G4double actan = std::atan(pxy/p4i.v()[2])*180/pi;
	    G4double actan_phi = std::atan(p4i.v()[1]/p4i.v()[0])*180/pi;
            //G4double vxy = std::sqrt(beta_i[0]*beta_i[0]+beta_i[1]*beta_i[1]);
            //G4double actan = std::atan(vxy/beta_i[2])*180/pi;
            G4double emass = theParticleChange->GetSecondary(i)->GetParticle()->GetMass();
            //G4cout << "event" << ip << " Particle : " << particlename << " z " << zip << " a " << aip << " angle " << actan << " ke " << p4i.e()-emass << " mass " << emass << G4endl;
            ofs << ip << "," << i << "," << particlename << "," << zip << "," << aip << "," << p4i.v()[0] << "," << p4i.v()[1] << "," << p4i.v()[2] << "," << actan << "," << actan_phi << "," << p4i.e()-emass << "," << emass << endl;
            esum += p4i.e();
            //G4cout << "KEnergy : " << theParticleChange.GetSecondary(i)->GetParticle()->GetKineticEnergy() << G4endl;
            //G4cout << "KEnergy : " << theParticleChange.GetSecondary(i)->GetCreatorModelType() << G4endl;
            //theParticleChange->GetSecondary(i)->SetCreatorModelType(1111);
            //G4cout << "KEnergy : " << theParticleChange.GetSecondary(i)->GetCreatorModelType() << G4endl;
            //G4double rather = read_Zp*read_Zt*197.3/137.0/(2.0*read_E*20);
            //rather = 2.0*std::atan(rather)*180/pi;
            //G4cout << particlename << " p4 " << p4i << " angle: " << actan <<G4endl;
        }
        if (ip/100*100==ip)
        G4cout << ip << " TotalEnergy, " << esum << ", elab, " << init_elab << ", Diff, " << esum - init_elab  << G4endl;
        //delete reaction;
    }
    clock_t end = clock();
    double endTime = omp_get_wtime();
    G4cout << "time: " << (double)(end - start) / CLOCKS_PER_SEC << "sec." << G4endl;
    G4cout << "real time: " << (double)(endTime - startTime) << "sec." << G4endl;
    //G4cout << "test " << G4endl;
    //theParticleChange =
    //G4HadFinalState* LocalQMDReaction::ApplyYourself( const G4HadProjectile & projectile , G4Nucleus & target )
    //delete particle_projectile;
    delete reaction;
    delete theIonBC;
    //delete theINCL;
    
    #ifdef G4VIS_USE
    // Initialize visualization
    G4VisManager* visManager = new G4VisExecutive;
    visManager->Initialize();
    #endif

    // Get the pointer to the User Interface manager
    G4UImanager* UImanager = G4UImanager::GetUIpointer();

    if (argc!=1)   // batch mode
    {
        G4String command = "/control/execute ";
        G4String fileName = argv[1];
        UImanager->ApplyCommand(command+fileName);
    }
    else
    {  // interactive mode : define UI session
    #ifdef G4UI_USE
        G4UIExecutive* ui = new G4UIExecutive(argc, argv);
    #ifdef G4VIS_USE
        G4cout << "vis.mac" << G4endl;
        UImanager->ApplyCommand("/control/execute vis.mac");
    #endif
    if (ui->IsGUI())
        G4cout << "gui.mac" << G4endl;
    	UImanager->ApplyCommand("/control/execute gui.mac");
        ui->SessionStart();
        delete ui;
    #endif
    }
#ifdef G4VIS_USE
  delete visManager;
#endif
  delete runManager;

  return 0;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo.....
