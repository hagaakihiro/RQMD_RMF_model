#import optuna
import pandas as pd
import matplotlib.pyplot as plt
import sys
import numpy as np
import csv
import subprocess as subpro



#L_prm = {'Skyrme-JQMD'  :[.26, .71],
#         'ImQMD-SkMstar':[.14, .87],
#         'ImQMD-SIII'   :[.21, .85],
#         'ImQMD-SLy4'   :[.14, .87],}
L_prm = {'ImQMD-SkMstar':[0.038370529165031905, 0.8851898147067387],
         'ImQMD-SLy4'   :[0.037956923701846945, 0.8942586065122018],
         'NL3star'      :[0.03906817264154093,  0.8276708612082979],
#         'NS2'      :[0.03,  1.3],
         'NS2'      :[0.035,  0.9],
         'NLC'      :[0.037,  1.1],
         'NL1'      :[0.037,  1.1],
}
# 'NS2'      :[0.03,  1.3], for NS2L
# 'NS2'      :[0.035,  0.9], for NS2R

#db_prm = {'Skyrme-JQMD'  :[-.05, 2.18,  .79, 2.38, .32],
#          'ImQMD-SkMstar':[ .09, 2.35, 0.28, 2.25, .27],
#          'ImQMD-SIII'   :[ .11, 1.74,  .81, 2.19, .35],
#          'ImQMD-SLy4'   :[ .06, 2.50,  .23, 2.35, .59],}
db_prm = {'ImQMD-SkMstar':3.0,
          'ImQMD-SLy4'   :3.0,
          'NL3star'      :3.4,
          'NS2'      :3.0,
          'NLC'      :3.0,
          'NL1'      :3.0,
          
}

#da_prm = {'Skyrme-JQMD'  :.60,
#          'ImQMD-SkMstar':.66,
#          'ImQMD-SIII'   :.47,
#          'ImQMD-SLy4'   :.67,}
da_prm = {'ImQMD-SkMstar':0.7,
          'ImQMD-SLy4'   :0.7,
          'NL3star'      :0.8,
          'NS2'      :0.7,
          'NLC'      :0.7,
          'NL1'      :0.7,
}


with open('model_name.csv') as f:
    reader = csv.reader(f)
    r0 = [row for row in reader][0]
    model = str(r0[0])

with open('QMD_input.csv') as f:
    reader = csv.reader(f)
    r0 = [row for row in reader][0]
    #print(r0)

    
#with open('current_proj.csv') as f:
#    reader = csv.reader(f)
#    r0 = [row for row in reader][0]
    Ek = float(r0[0])
    Ap = float(r0[3])

#with open('current_targ.csv') as f:
#    reader = csv.reader(f)
#    r0 = [row for row in reader][0]
    At = float(r0[5])

def L_opt(A,model):
    x = A**(1/3)
    a, b = L_prm[model]
    #c = np.random.uniform(-0.1,0.1)
    c = 0
    #L = (a*x+b+c)**2
    L = a*(A**(2/3))+b
    return L
    

#def db_opt(A,model):
    #x = A**(1/3)
    #a, b, c, m, s = db_prm[model]
    #d = np.random.uniform(-0.2,0.2)
    #d = 0
    #db = a*x + b - c*np.exp(-((x-m)*(x-m))/(s*s)) + d
    #return db

def db_opt(model):
    a = db_prm[model]
    #b = np.random.uniform(-0.2,0.2)
    b = 0
    db = a + b
    return db

def da_opt(model):
    a = da_prm[model]
    #b = np.random.uniform(-0.2,0.2)
    b = 0
    da = a + b
    return da

def proton_data(projectile,nucl_proj,target,nucl_targ):
    nAb = []
    Ab = []
    Tm30 = []
    Tm50 = []
    Tm100 = []
    Tm150 = []
    Tm250 = []
    Tm300 = []
    Tm400 = []
    for proj, nproj in zip(projectile,nucl_proj):
        for targ, ntarg in zip(target,nucl_targ):
            strnucl = "%s-%s" % (nproj,ntarg)
            nucl = targ
            nAb.append(strnucl)
            Ab.append(nucl)
        
            t30 = 1.5
            if nucl > 31:
                t30 = 1.7
            t50 = 1.7
            if nucl < 35:
                t50 = 1.6
            if nucl < 18 and nucl > 13:
                t50 = 1.7
            if nucl <= 13:
                t50 = 1.6
        
            t100 = 1.05
            if nucl < 35:
                t100 = 1.3
            if nucl < 18 and nucl > 13:
                t100 = 1.5
            if nucl <= 13:
                t100 = 1.7
            
            t150 = 1.05
            if nucl < 35:
                t150 = 1.1
            if nucl < 18 and nucl > 13:
                t150 = 1.3
            if nucl <= 13:
                t150 = 1.6
            
            t250 = 1.0
            if nucl < 18 and nucl > 13:
                t250 = 1.1
            if nucl <= 13:
                t250 = 1.3

            t300 = 1.0
            t400 = 1.0
            if nucl < 13:
                t300 = 1.05
            Tm30.append(t30)
            Tm50.append(t50)
            Tm100.append(t100)
            Tm150.append(t150)
            Tm250.append(t250)
            Tm300.append(t300)
            Tm400.append(t400)
            #print(strnucl, nucl, t30, t50, t100, t150, t250, t300, t400)
    df0 = pd.DataFrame([nAb, Ab, Tm30, Tm50, Tm100, Tm150, Tm250, Tm300, Tm400]).T
    df0.columns = ["proj-targ","Abar","30MeV","50MeV","100MeV","150MeV","250MeV","300MeV","400MeV"]
    #df = df0.sort_values("Abar", ignore_index=True)
    df = df0.sort_values("Abar")
    return df

def proton_bval(AA,EE,df):
    if (AA > 11 and AA < 66) and (EE < 400):
        for i in range(len(df)):
            if AA < df["Abar"].iloc[i]:
                AAmat = df["Abar"].iloc[i]
                iAmat = i
                break
        AAmat0 = df["Abar"].iloc[iAmat-1]
        #print(iAmat, AAmat, AAmat-AA)
        #print(iAmat-1, AAmat0, AA-AAmat0)

        wA0 = (AAmat-AA)/(AAmat-AAmat0)
        wA1 = (AA-AAmat0)/(AAmat-AAmat0)
        #print(wA0, wA1)

        Elist = [30, 50, 100, 150, 250, 300, 400]
        for i in range(len(Elist)):
            if EE < Elist[i]:
                EEmat = Elist[i]
                iEmat = i
                break
        EEmat0 = Elist[iEmat-1]
        #print(iEmat, EEmat, EEmat-EE)
        #print(iEmat-1, EEmat0, EE-EEmat0)

        wE0 = (EEmat-EE)/(EEmat-EEmat0)
        wE1 = (EE-EEmat0)/(EEmat-EEmat0)
        #print(wE0, wE1)

        val00 = df.iloc[iAmat-1,iEmat+1]
        val10 = df.iloc[iAmat,iEmat+1]
        val01 = df.iloc[iAmat-1,iEmat+2]
        val11 = df.iloc[iAmat,iEmat+2]

        valA0 = wA0*val00 + wA1*val10
        valA1 = wA0*val01 + wA1*val11

        bval = wE0*valA0 + wE1*valA1
    else:
        if AA > 65:
            bval = 1.0
            if EE < 60:
                bval = 1.5

        if EE >=400:
            bval = 1.0
    return bval
        
L  = (At*L_opt(At,model) + Ap*L_opt(Ap,model))/(Ap+At)
da = da_opt(model)
#db = (At*db_opt(At,model) + Ap*db_opt(Ap,model))/(Ap+At)
db = db_opt(model)
print(L)

### dt is set as 2 in 150 MeV proton, maximum = 3
mp = 938.2
beta = np.sqrt((2*mp*Ek+Ek*Ek)/(mp+Ek)**2)
beta150 = np.sqrt((2*mp*150+150*150)/(mp+150)**2)
dt = beta150/beta*2
if dt > 3.0:
    dt = 3.0
if Ek < 50:
    dt = 2.0

# Tmax factor
w0 = 0.00874369
w1 = 0.00424739
abar = (At+Ap)/2
tm = 4.0/(1.0 + np.exp((-w0*abar - w1*Ek)))

# Rpn
w = [1.05608421e+01,-3.30988665e-03,1.63606243e-04,-1.08987761e-01,4.75697386e-04,-5.84726684e-07,1.14249807e-04]
ek = Ek
val = w[0] + w[1]*abar + w[2]*abar**2 + w[3]*ek + w[4]*ek**2 + w[5]*ek**3 + w[6]*abar*ek
if ek > 400:
    val = w[0] + w[1]*abar + w[2]*abar**2 + w[3]*400 + w[4]*400**2 + w[5]*400**3 + w[6]*abar*400    
if abar > 35:
    val = w[0] + w[1]*35 + w[2]*35**2 + w[3]*ek + w[4]*ek**2 + w[5]*ek**3 + w[6]*35*ek        
if abar > 35 and ek > 400:
    val = w[0] + w[1]*35 + w[2]*35**2 + w[3]*400 + w[4]*400**2 + w[5]*400**3 + w[6]*35*400
if val > 7.0:
    val = 7.0
elif val < 4.0:
    val = 4.0
rpn = val

# Rpp
rpp = 4.0

# b-value
#bval = 1.05
#if At < 40:
#    bval = 1.1
#elif At < 20:
#    bval = 1.2
bval = 1.2
if At > 40:
    bval = 1.1

# For proton projectile / proton target
if Ap == 1 or At == 1:
    projectile = [1]
    nucl_proj = ["H"]
    target = [12,16,31,40,63]
    nucl_targ = ["C","O","P","Ca","Cu"]
    df = proton_data(projectile,nucl_proj,target,nucl_targ)
    if Ap == 1:
        AA = At
    if At == 1:
        AA = Ap
    if AA < 12:
        AA = 12
    EE = Ek
    bval = proton_bval(AA,EE,df)
        
if abar < 20:
    bval = 1.2
else:
    bval = 1.05
#for i in pEner:
#df = pd.DataFrame([Cbval,Obval,Pbval,Cabval,Cubval])

# write values to parameters.txt
parameters = ['L', 'Rpn', 'Rpp', 'Rnn','cluster_a', 'cluster_b', 'T', 'dt', 'b_env']
fix = [2., 4., 4., 4., 0., 0., 5., 1., 1.05]

def making_params(req):
    mginput = [req.get(prm) if prm in req.keys() else np.array([f]) for prm,f in zip(parameters, fix)]
    mesh    = np.meshgrid(*mginput)
    df      = pd.DataFrame({prm: np.ravel(m) for prm, m in zip(parameters, mesh)})
    return df


#req = {'L':[L], 'cluster_a':[da], 'cluster_b':[db], 'T':[3], 'dt':[dt],
#       'b_env':[1.5, 2., 2.5, 3.], 'Rpn':[3.], 'Rpp':[3.], 'Rnn':[3.],}
       #'b_env':[1., 1.05, 1.1, 1.15, 1.2, 1.25, 1.3, 1.35, 1.4, 1.45, 1.5],}
#req = {'L':[L], 'cluster_a':[da], 'cluster_b':[db], 'T':[3], 'dt':[dt],
#       'b_env':[1.2], 'Rpn':[6.], 'Rpp':[6.], 'Rnn':[6.],}
req = {'L':[L], 'cluster_a':[da], 'cluster_b':[db], 'T':[3.0], 'dt':[dt],
       'b_env':[bval], 'Rpn':[4.0], 'Rpp':[rpp],}
       
df = making_params(req)
df['Rnn'] = df['Rpp']
df0 = df[df['Rpn']>=df['Rpp']]
#df0 = df[(df['Rpn']==df['Rpp'])]
#df.to_csv('parameters.txt', index = False, header= False)
df0.to_csv('parameters.txt', index = False, header= False)


"""
prms = [L, 4., 4., 4., da, db, 5., 1., 1.05]
with open('parameters.txt', 'w') as f:
    writer = csv.writer(f,  lineterminator='\n')
    writer.writerow(prms)
"""
